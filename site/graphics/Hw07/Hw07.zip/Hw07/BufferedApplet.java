// Ken Perlin 2011-2012. All Rights Reserved.
//
// THIS CLASS HANDLES DOUBLE BUFFERING FOR YOU, SO THAT THE IMAGE
// DOESN'T FLICKER WHILE YOU'RE RENDERING IT.  YOU DON'T REALLY
// NEED TO WORRY ABOUT THIS TOO MUCH, AND YOU'LL PROBABLY NEVER NEED
// TO CHANGE IT.  IT'S REALLY JUST USEFUL LOW LEVEL PLUMBING.

import java.awt.*;
import java.awt.image.*;

public abstract class BufferedApplet extends java.applet.Applet implements Runnable
{
  // YOU MUST DEFINE A METHOD TO RENDER THE APPLET

  public void computeImage(double t) {};
  public void initialize() {};

  // A BACKGROUND THREAD CALLS REPAINT EVERY 30 MILLISECONDS,

  public void init() {
    setLayout(new BorderLayout());
    // FIND THE RESOLUTION OF THE JAVA APPLET
    width = getBounds().width;
    height = getBounds().height;
    // ALLOCATE A FRAME BUFFER IMAGE
    pixels = new int[width * height];
    mis = new MemoryImageSource(width, height, pixels, 0, width);
    mis.setAnimated(true);
    // MAKE MEMORY IMAGE SOURCE FOR FRAME BUFFER
    image = createImage(mis);
    // CALL USER INITIALIZE
    initialize();
    // START RENDER THREAD
    new Thread(this).start();
  }

  public void run() {
    try {
      while (true) {
        mis.newPixels(0, 0, width, height, true);
        computeImage(getTime());
        repaint(); // This is NOT synchronous.
        Thread.sleep(sleepMs);
      }
    }
    catch(Exception e){ }
  }

  // THE IMAGE YOU'VE RENDERED IS THEN COPIED TO THE SCREEN.

  public void update(Graphics g) {
    g.drawImage(image, 0, 0, null);
  }

  /// <summary>Get time in seconds since this instance was created.</summary>
  public double getTime() {
    return (System.currentTimeMillis() / 1000.0) - startTime;
  }

  public int pack(int red, int grn, int blu) {
    return 255 << 24 | (red & 255) << 16
                     | (grn & 255) <<  8
                     | (blu & 255)     ;
  }

  public int unpack(int packedRGB, int component) {
    return packedRGB >> 8*(2-component) & 255;
  }


  protected int[] pixels;
  protected MemoryImageSource mis;
  protected Image image;
  protected int width = 0;
  protected int height = 0; 

  private final double startTime = System.currentTimeMillis() / 1000.0;

  private final int fpsTarget = 9999;
  private final double tFrame = 1.0 / (double)fpsTarget;
  private final int sleepMs = (int)(tFrame * 1000.0);
}

