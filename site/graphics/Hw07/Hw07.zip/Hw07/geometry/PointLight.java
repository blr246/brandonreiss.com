/*
 * PointLight.java
 *
 * A light that emits from a single point in space with no attenuation.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.geometry;
import com.brandonreiss.math.*;

public class PointLight extends Light {
  public Vector3 i = new Vector3(1, 1, 1);

  public double getDirectionAtPoint(Vector3 p, Vector3 dir) {
    dir.set(transform.m[0][3], transform.m[1][3], transform.m[2][3]).sub(p);
    final double lightDistSq = dir.lengthSq();
    dir.normalize();
    return lightDistSq;
  }
  public void getIntensity(Vector3 p, Vector3 dir, Vector3 iPt) {
    iPt.set(i);
  }
}

