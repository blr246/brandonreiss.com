/*
 * DirectionalLight.java
 *
 * A light with direction only and infinite position.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.geometry;
import com.brandonreiss.math.*;

///<summary>A simulated light.</summary>
public class DirectionalLight extends Light {
  public Vector3 i = new Vector3(1, 1, 1);

  public double getDirectionAtPoint(Vector3 p, Vector3 dir) {
    dir.set(transform.m[0][2], transform.m[1][2], transform.m[2][2]).mul(-1);
    return 1.0e6;
  }
  public void getIntensity(Vector3 p, Vector3 dir, Vector3 iPt) {
    iPt.set(i);
  }
}

