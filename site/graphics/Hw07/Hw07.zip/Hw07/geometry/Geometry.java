/*
 * Geometry.java
 *
 * Second order surface with a material.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.geometry;

import com.brandonreiss.math.*;
import com.brandonreiss.util.*;
import java.util.ArrayList;
import java.util.Arrays;

public class Geometry extends SceneObject {

  ///<summary>Phong shading material.</summary>
  public class Material {
    ///<summary>Ambient constants.</summary>
    public Vector3 kA = new Vector3(1, 1, 1);
    ///<summary>Diffuse constants.</summary>
    public Vector3 kD = new Vector3(1, 1, 1);
    ///<summary>Specular constants.</summary>
    public Vector3 kS = new Vector3(1, 1, 1);
    ///<summary>Specular exponent.</summary>
    public double alphaS = 5.0;
    ///<summary>Reflection coefficient.</summary>
    public double reflectivity = 0;
    ///<summary>Surface opacity.</summary>
    public double opacity = 1.0;
    ///<summary>Material refraction index.</summary>
    public double refractionIndex = 1.0;
  }

  public int intersect(Ray ray,
                       ArrayPtr.Double intervalPtr,
                       ArrayPtr.Vector3 pointPtr,
                       ArrayPtr.Vector3 normalPtr)
  {
    // Look for the last in and the first out.
    double lastIn = Double.NEGATIVE_INFINITY;
    int lastInIdx = 0;
    double firstOut = Double.NEGATIVE_INFINITY;
    int firstOutIdx = 0;
    int storeIdx = 0;
    for (HalfSpace h : halfSpaces) {
      final int numHits = h.intersect(ray, storeIdx, intervalPtr, pointPtr, normalPtr);
      // Check always outside.
      if (numHits < 0) {
        return 0;
      }
      // Find last in/first out.
      for (int i = 0; i < numHits; ++i) {
        final int idx = storeIdx + i;
        final double intervalIdx = intervalPtr.get()[idx];
        // Last in.
        if ((intervalIdx > 0) && (intervalIdx > lastIn)) {
          lastIn = intervalIdx;
          lastInIdx = idx;
        }
        // First out.
        if ((intervalIdx < 0) && (intervalIdx > firstOut)) {
          firstOut = intervalIdx;
          firstOutIdx = idx;
        }
      }
      storeIdx += numHits;
    }

    if (storeIdx > 0) {
      // Get this shape arrays.
      double[] interval = intervalPtr.get();
      Vector3[] point = pointPtr.get();
      Vector3[] normal = normalPtr.get();

//      // DEBUG interval
//      for (int i = storeIdx; i < interval.length; ++i) {
//        interval[i] = -999;
//      }
//      System.out.println("interval = " + Arrays.toString(interval));
//      System.out.println("lastIn = " + lastIn + "," +
//                         "firstOut = " + firstOut);
//      // DEBUG interval

      if (Math.abs(lastIn) < Math.abs(firstOut)) {
        interval[0] = lastIn;
        interval[1] = firstOut;
        point[0].set(point[lastInIdx]);
        point[1].set(point[firstOutIdx]);
        normal[0].set(normal[lastInIdx]);
        normal[1].set(normal[firstOutIdx]);
        return 2;
      }
    }
    return 0;
  }

  public abstract class HalfSpace extends SceneObject {
    public abstract int intersect(Ray ray, int storeIdx,
                                  ArrayPtr.Double intervalPtr,
                                  ArrayPtr.Vector3 pointPtr,
                                  ArrayPtr.Vector3 normalPtr);
  }

  public class Plane extends HalfSpace {
    private Vector4 plane = new Vector4(0, 0, 1, 0);
    private Vector4 planeTform = new Vector4();
    private Matrix4x4 transformInvT = new Matrix4x4();

    public void onTransformUpdated() {
      //planeTform.set(plane).transformNormal(transform).normalize();
      transformInvT.set(transform).inverse().transpose();
      planeTform.set(plane).mul(transformInvT);
      double normalLengthSq  = (planeTform.x * planeTform.x) +
                               (planeTform.y * planeTform.y) +
                               (planeTform.z * planeTform.z);
      planeTform.mul(1.0 / Math.sqrt(normalLengthSq));
    }
    
    public int intersect(Ray ray, int storeIdx,
                         ArrayPtr.Double intervalPtr,
                         ArrayPtr.Vector3 pointPtr,
                         ArrayPtr.Vector3 normalPtr) {
      // Grow arrays?
      final int numRoots = 1;
      final int maxPtIdx = storeIdx + numRoots;
      if (intervalPtr.get().length < maxPtIdx) {
        intervalPtr.resize(maxPtIdx);
      }
      if (pointPtr.get().length < maxPtIdx) {
        pointPtr.resize(maxPtIdx);
      }
      if (normalPtr.get().length < maxPtIdx) {
        normalPtr.resize(maxPtIdx);
      }
      double[] interval = intervalPtr.get();
      Vector3[] point = pointPtr.get();
      Vector3[] normal = normalPtr.get();
      // Get ray-plane distance. Positive interval is entering the suface.
      double ptDotPlane  = planeTform.dot(ray.pt);
      double dirDotPlane = planeTform.dot(ray.dir);
      double dist = ptDotPlane + planeTform.w;
      boolean inside = dist < 0;
      int retNoHits = inside ? 0 : -1;
      // Are we not facing the plant and not inside?
      if ((dirDotPlane >= 0) && !inside) {
        return retNoHits;
      }
      double t = -dist / dirDotPlane;
      // Are we not hitting the plane?
      if (t < 0) {
        return retNoHits;
      }
      int sign = inside ? -1 : 1;
      interval[storeIdx] = sign * t;
      // Save point, normal.
      point[storeIdx].set(ray.dir).mul(Math.abs(interval[storeIdx])).add(ray.pt);
      normal[storeIdx].set(planeTform);
      return 1;
    }
  }

  public class Quadratic extends HalfSpace {
    private Matrix4x4 transformInv = new Matrix4x4();
    private Matrix4x4 q = Matrix4x4.createMatrixIdentity();
    private Matrix4x4 qTform = new Matrix4x4();
    private Matrix4x4 qTform_p = new Matrix4x4();

    public Quadratic(double a, double b, double c, double d, double e,
                     double f, double g, double h, double i, double j) {
      // Assign upper-triagular matrix of quadratic coefficients.
      double[][] qm = q.m;
      qm[0][0] = a; qm[0][1] = f; qm[0][2] = e; qm[0][3] = g;
                    qm[1][1] = b; qm[1][2] = d; qm[1][3] = h;
                                  qm[2][2] = c; qm[2][3] = i;
                                                qm[3][3] = j;
    }

    public void onTransformUpdated() {
      transformInv.set(transform).inverse();
      // Setup qTform.
      qTform.set(transformInv).transpose().mul(q).mul(transformInv);
      {
        double[][] m = qTform.m;
        /*        */ m[0][1] *= 2; m[0][2] *= 2; m[0][3] *= 2;
        m[1][0] = 0; /*         */ m[1][2] *= 2; m[1][3] *= 2;
        m[2][0] = 0; m[2][1]  = 0; /*         */ m[2][3] *= 2;
        m[3][0] = 0; m[3][1]  = 0; m[3][2]  = 0; /*         */
      }
      // Setup gradient.
      qTform_p.set(qTform);
      // Scale diagonal.
      qTform_p.m[0][0] *= 2; qTform_p.m[1][1] *= 2; qTform_p.m[2][2] *= 2;
      qTform_p.m[3][3] = 0;
      // Reflect entries.
      qTform_p.m[1][0] = qTform_p.m[0][1];
      qTform_p.m[2][0] = qTform_p.m[0][2];
      qTform_p.m[2][1] = qTform_p.m[1][2];
    }
    
    public int intersect(Ray ray, int storeIdx,
                         ArrayPtr.Double intervalPtr,
                         ArrayPtr.Vector3 pointPtr,
                         ArrayPtr.Vector3 normalPtr) {
      // Grow arrays?
      final int numRoots = 2;
      final int maxPtIdx = storeIdx + numRoots + 1;
      if (intervalPtr.get().length < maxPtIdx) {
        intervalPtr.resize(maxPtIdx);
      }
      if (pointPtr.get().length < maxPtIdx) {
        pointPtr.resize(maxPtIdx);
      }
      if (normalPtr.get().length < maxPtIdx) {
        normalPtr.resize(maxPtIdx);
      }
      double[] interval = intervalPtr.get();
      Vector3[] point = pointPtr.get();
      Vector3[] normal = normalPtr.get();
      // Compute quadratic coefficients.
      double c_1, c_2, c_3;
      double a, b, c, d, e, f, g, h, i, j;
      {
        // Load coefficients.
        double[][] qm = qTform.m;
        a = qm[0][0]; f = qm[0][1]; e = qm[0][2]; g = qm[0][3];
                      b = qm[1][1]; d = qm[1][2]; h = qm[1][3];
                                    c = qm[2][2]; i = qm[2][3];
                                                  j = qm[3][3];
        // t^2((a * d_x^2) + (b * d_y^2) + (c * d_z^2) +
        //     (e * d_x * d_z) + (f * d_y * d_z) + (g * d_x * d_y))
        c_1 = (a * ray.dir.x * ray.dir.x) +
              (b * ray.dir.y * ray.dir.y) +
              (c * ray.dir.z * ray.dir.z) +
              (d * ray.dir.y * ray.dir.z) +
              (e * ray.dir.x * ray.dir.z) +
              (f * ray.dir.x * ray.dir.y);
        // t((a * 2 * p_x * d_x) + (b * 2 * p_y * d_y) + (c * 2 * p_z * d_z) +
        //   (d * ((p_z * d_y) + (p_y * d_z))) +
        //   (e * ((p_x * d_z) + (p_z * d_x))) +
        //   (f * ((p_x * d_y) + (p_y * d_x))) +
        //   (g * d_x) + (h * d_y) + (i * d_z))
        c_2 = (a * 2 * ray.dir.x * ray.pt.x) +
              (b * 2 * ray.dir.y * ray.pt.y) +
              (c * 2 * ray.dir.z * ray.pt.z) +
              (d * ((ray.pt.z * ray.dir.y) + (ray.pt.y * ray.dir.z))) +
              (e * ((ray.pt.x * ray.dir.z) + (ray.pt.z * ray.dir.x))) +
              (f * ((ray.pt.x * ray.dir.y) + (ray.pt.y * ray.dir.x))) +
              (g * ray.dir.x) +
              (h * ray.dir.y) +
              (i * ray.dir.z);
        // Standard point xT Q x multiply.
        // (a * p_x^2) + (b * p_y^2) + (c * p_z^2) +
        // (d * p_y * p_z) + (e * p_x * p_z) + (f * p_x * p_y) +
        // (g * p_x) + (h * p_y) + (i * p_z) + j
        c_3 = normal[storeIdx].set(ray.pt).transform(qTform).dot(ray.pt) + j;
      }
      // Solve quadratic equation.
      // t = (-c_2 +/- sqrt(c_2^2 - (4 * c_1 * c_3))) / (2 * c_1)
      final double radPart = (c_2 * c_2) - (4 * c_1 * c_3);
      // Check no intersection possible.
      final int noIntersectionRes = (c_3 <= 0) ? 0 : -1;
      if (radPart < 0) {
        return noIntersectionRes;
      }
      final double twoC1 = (2 * c_1);
      final double offset = Math.sqrt(radPart) / twoC1;
      final double negC2DivTwoC1 = -c_2 / twoC1;
      final double t_enter = negC2DivTwoC1 - offset;
      final double t_exit  = negC2DivTwoC1 + offset;
      // Set points, intervals, normals.
      final int state = ((t_enter > 0) ? 2 : 0) + ((t_exit > 0) ? 1 : 0);
      final double sign = (c_3 < 0) ? -1 : 1;
      int ptIdx = storeIdx;
      switch (state) {
        case 3:
        case 2:
          interval[ptIdx] =  sign * t_enter;
          point[ptIdx].set(ray.dir).mul(t_enter).add(ray.pt);
          normal[ptIdx].set(point[ptIdx]).transform(qTform_p).normalize();
          ++ptIdx;
        case 1:
          interval[ptIdx] = -sign * t_exit;
          point[ptIdx].set(ray.dir).mul(t_exit).add(ray.pt);
          normal[ptIdx].set(point[ptIdx]).transform(qTform_p).normalize();
          ++ptIdx;
          break;
        case 0: // ray not in proper direction
        default: return noIntersectionRes;
      }
      return ptIdx;
    }
  }
  
  public Plane addPlane() {
    Plane p = new Plane();
    halfSpaces.add(p);
    p.setParent(this);
    return p;
  }

  public Quadratic addQuadratic(double a, double b, double c, double d, double e,
                                double f, double g, double h, double i, double j) {
    Quadratic q = new Quadratic(a, b, c, d, e, f, g, h, i, j);
    halfSpaces.add(q);
    q.setParent(this);
    return q;
  }

  public Material material = new Material();
  private ArrayList<HalfSpace> halfSpaces = new ArrayList<HalfSpace>();

  /*
   * Static creation methods.
   */

  ///<summary>Create a new infinte plane.</summary>
  public static Geometry newPlane() {
    Geometry g = new Geometry();
    g.addPlane();
    return g;
  }

  ///<summary>Create a new unit cube.</summary>
  public static Geometry newCube() {
    Geometry g = new Geometry();
    // X
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.rotateY( Math.PI * 0.5);
      p.transformLocal.translate(0, 0, 1);
    }
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.rotateY(-Math.PI * 0.5);
      p.transformLocal.translate(0, 0, 1);
    }
    // Y
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.rotateX( Math.PI * 0.5);
      p.transformLocal.translate(0, 0, 1);
    }
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.rotateX(-Math.PI * 0.5);
      p.transformLocal.translate(0, 0, 1);
    }
    // Z
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.translate(0, 0, 1);
    }
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.rotateY(Math.PI);
      p.transformLocal.translate(0, 0, 1);
    }
    return g;
  }

  ///<summary>Create a new unit sphere.</summary>
  public static Geometry newSphere() {
    Geometry g = new Geometry();
    g.addQuadratic(1, 1, 1, 0, 0, 0, 0, 0, 0,-1);
    return g;
  }

  ///<summary>Create a new unit cylinder.</summary>
  public static Geometry newCylinder() {
    Geometry g = new Geometry();
    int hsIdx = 0;
    {
      g.addQuadratic(1, 1, 0, 0, 0, 0, 0, 0, 0,-1);
    }
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.translate(0, 0, 1);
    }
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.rotateY(Math.PI);
      p.transformLocal.translate(0, 0, 1);
    }
    return g;
  }
}

