/*
 * CompoundGeometry.java
 *
 * Boolean geometry.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.geometry;

import com.brandonreiss.math.*;
import com.brandonreiss.util.*;
import java.util.ArrayList;

public class CompoundGeometry extends Geometry {
  ArrayList<Geometry> unionList;
  ArrayList<Geometry> intersectList;
  ArrayList<Geometry> subtractList;

  public int intersect(Ray ray,
                       ArrayPtr.Double intervalPtr,
                       ArrayPtr.Vector3 pointPtr,
                       ArrayPtr.Vector3 normalPtr)
  {
    return 0;
  }
}

