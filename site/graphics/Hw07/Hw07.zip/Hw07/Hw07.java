/*
 * Hw07.java
 *
 * Ray tracing with reflections.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
import com.brandonreiss.math.*;
import com.brandonreiss.geometry.*;
import com.brandonreiss.util.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.concurrent.*;
import java.util.Random;

public class Hw07 extends BufferedApplet implements KeyListener {

  ///<summary>Ambient light intensity.</summary>
  private Vector3 iA = new Vector3(0.07, 0.07, 0.07);

  ///<summary>View matrix (WORLD ==> CAMERA).</summary>
  private Matrix4x4 viewMat = Matrix4x4.createMatrixIdentity();
  ///<summary>View matrix inverse (CAMERA ==> WORLD).</summary>
  private Matrix4x4 viewMatInv = Matrix4x4.createMatrixIdentity();
  ///<summary>Camera focal length.</summary>
  double focalLength;

  // Scene elements.
  private Light[] lights = null;
  private Geometry[] shapes = null;
  private Dummy[] shapeControllers = null;
  private SceneGraph scene = new SceneGraph();

  public void keyPressed(KeyEvent e) { }
  public void keyReleased(KeyEvent e) { }
  public void keyTyped(KeyEvent e) {
    final char c = e.getKeyChar();
    switch (c) {
      case 'f':
      case 'F':
        showDepthMap = false;
        showFiringPattern = !showFiringPattern;
        break;
      case 'd':
      case 'D':
        showDepthMap = !showDepthMap;
        showFiringPattern = false;
        break;
      case 'm':
        depthEdgeThreshScale = Math.min(depthEdgeThreshScale + 0.01, 1.0);
        System.out.println("depthEdgeThreshScale = " + depthEdgeThreshScale);
        break;
      case 'M':
        depthEdgeThreshScale = Math.max(depthEdgeThreshScale - 0.01, 0.0);
        System.out.println("depthEdgeThreshScale = " + depthEdgeThreshScale);
        break;
      case 'i':
        edgeThresh = Math.max(edgeThresh - 0.005, 0.0);
        System.out.println("edgeThresh = " + edgeThresh);
        break;
      case 'I':
        edgeThresh = Math.min(edgeThresh + 0.005, 0.4);
        System.out.println("edgeThresh = " + edgeThresh);
        break;
      default:
        break;
    }
  }

  public Hw07() {
    addKeyListener(this);
    // Setup tasks.
    {
      numProcessors = Runtime.getRuntime().availableProcessors();
      numTasks = 4 * numProcessors;
      tasks = new ArrayList<RaytraceTask>(numTasks);
      for (int i = 0; i < numTasks; ++i) {
        tasks.add(new RaytraceTask());
      }
      pool = Executors.newFixedThreadPool(numProcessors, new TaggedThreadFactory());
      renderContexts = new RaytraceRenderContext[numProcessors];
      for (int i = 0; i < numProcessors; ++i) {
        renderContexts[i] = new RaytraceRenderContext();
      }
    }
  }

  public enum ShapeId {
    GROUND(),
    GOLD_BOX(),
    GOLD_SPHERE(),
    GLASS_ELLIPSOID(),
    CYL_BASE(),
    CYL_SPIRE(),
    PLASTIC_CYL_LONG_0(),
    PLASTIC_CYL_LONG_1(),
    ;

    private int idx;
    ShapeId() { this.idx = Count.next(); }
    public int idx() { return idx; }
    public static int count() { return Count.count; }
    private static class Count {
      private static int count = 0;
      public static int next() { return count++; }
    }
  }

  ///<summary>Initialization after applet is setup.</summary>
  public void initialize() {
    // Setup camera matrix.
    {
      viewMatInv.identity();
      viewMatInv.rotateX(Math.PI * 0.35);
      viewMatInv.translate(0, 1, 12);
    }
    // Setup projection.
    focalLength = 1.0 / Math.tan(Math.PI * 0.15);
    // Compute view and projection inverses.
    viewMat.set(viewMatInv).inverse();
    scene.root = viewMat;

    // Geometry and materials.
    shapes = new Geometry[ShapeId.count()];
    shapeControllers = new Dummy[ShapeId.count()];
    for (int i = 0; i < shapeControllers.length; ++i) {
      shapeControllers[i] = new Dummy();
    }
    // Ground plane.
    {
      int idx = ShapeId.GROUND.idx();
      Geometry g = Geometry.newCube();
      Geometry.Material m = g.material;
      m.kA.set(0.2, 0.6, 0.2);
      m.kD.set(0.2, 0.6, 0.2);
      m.kS.set(0.2, 0.6, 0.2);
      m.alphaS = 2.0;
      g.transformLocal.translate(0, 0,-0.1);
      g.transformLocal.scale(8, 4, 0.1);
      shapes[idx] = g;
      // Model.
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }
    // Gold box.
    {
      int idx = ShapeId.GOLD_BOX.idx();
      Geometry g = Geometry.newCube();
      Geometry.Material m = g.material;
      m.kA.set(1.0, 0.8, 0.4);
      m.kD.set(0.6, 0.4, 0.2);
      m.kS.set(0.7, 0.5, 0.25);
      m.alphaS = 3.0;
      m.reflectivity = 0.15;
      shapes[idx] = g;
      // Model.
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }
    {
      int idx = ShapeId.GOLD_SPHERE.idx();
      Geometry g = Geometry.newSphere();
      g.material = shapes[ShapeId.GOLD_BOX.idx()].material;
      shapes[idx] = g;
      // Model.
      g.transformLocal.translate(0, 0, 2);
      shapeControllers[idx].addChild(g);
      shapeControllers[ShapeId.GOLD_BOX.idx()].addChild(shapeControllers[idx]);
    }
    {
      int idx = ShapeId.GLASS_ELLIPSOID.idx();
      Geometry g = Geometry.newSphere();
      Geometry.Material m = g.material;
      m.kA.set(0.3, 0.2, 0.2);
      m.kD.set(0.3, 0.2, 0.2);
      m.kS.set(0.9, 0.9, 0.9);
      m.alphaS = 100.0;
      m.reflectivity = 0.1;
      m.opacity = 0.6;
      m.refractionIndex = 1.4;
      shapes[idx] = g;
      // Model ellipsoid.
      g.transformLocal.scale(2.5, 0.75, 1.3);
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }
    {
      int idx = ShapeId.CYL_BASE.idx();
      Geometry g = Geometry.newCylinder();
      Geometry.Material m = g.material;
      m.kA.set(0.2, 0.9, 0.2);
      m.kD.set(0.2, 0.9, 0.2);
      m.kS.set(0.9, 0.9, 0.9);
      m.alphaS = 10.0;
      shapes[idx] = g;
      // Model.
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }
    {
      int idx = ShapeId.CYL_SPIRE.idx();
      Geometry g = Geometry.newCylinder();
      Geometry.Material m = g.material;
      m.kA.set(0.2, 0.9, 0.2);
      m.kD.set(0.2, 0.9, 0.2);
      m.kS.set(0.9, 0.9, 0.9);
      m.alphaS = 10.0;
      shapes[idx] = g;
      // Model.
      g.transformLocal.translate(0, 0, 3);
      g.transformLocal.scale(0.2, 0.2, 2);
      shapeControllers[idx].addChild(g);
      shapeControllers[ShapeId.CYL_BASE.idx()].addChild(shapeControllers[idx]);
    }
    {
      int idx = ShapeId.PLASTIC_CYL_LONG_0.idx();
      Geometry g = Geometry.newCylinder();
      Geometry.Material m = g.material;
      m.kA.set(0.3, 0.3, 1.0);
      m.kD.set(0.4, 0.4, 0.9);
      m.kS.set(0.8, 0.8, 0.8);
      m.alphaS = 50.0;
      shapes[idx] = g;
      // Model.
      g.transformLocal.scale(0.1, 0.1, 8);
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }
    {
      int idx = ShapeId.PLASTIC_CYL_LONG_1.idx();
      Geometry g = Geometry.newCylinder();
      Geometry.Material m = g.material;
      m.kA.set(1.0, 0.3, 0.3);
      m.kD.set(0.9, 0.4, 0.4);
      m.kS.set(0.8, 0.8, 0.8);
      m.alphaS = 50.0;
      shapes[idx] = g;
      // Model.
      g.transformLocal.scale(0.2, 0.2, 10);
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }

    // Lights.
    lights = new Light[4];
    int lightIdx = 0;
    // Overhead points.
    {
      PointLight l = new PointLight();
      l.i.set(0.4, 0.4, 0.4);
      l.transformLocal.translate(-5.6, 0, 10);
      lights[lightIdx++] = l;
      scene.addChild(l);
    }
    {
      PointLight l = new PointLight();
      l.i.set(0.2, 0.2, 0.2);
      l.transformLocal.translate( 0, 0, 10);
      lights[lightIdx++] = l;
      scene.addChild(l);
    }
    {
      PointLight l = new PointLight();
      l.i.set(0.4, 0.4, 0.4);
      l.transformLocal.translate( 5.6, 0, 10);
      lights[lightIdx++] = l;
      scene.addChild(l);
    }
    // Hard spot.
    {
      SpotLight l = new SpotLight();
      l.exp = 40.0;
      l.i.set(1.5, 1.5, 1.5);
      l.transformLocal.translate(0, 0, 10);
      lights[lightIdx++] = l;
      scene.addChild(l);
    }

    // Initialize maps.
    firingPattern = new byte[pixels.length];
    depthMap = new float[pixels.length];
  }

  ///<summary>Project a ray from the camera into the scene.</summary>
  private Ray projectRay(int w, int h, int x, int y, Ray ray) {
    final double halfScreenX = (double)w / 2.0;
    final double halfScreenY = (double)h / 2.0;
    final double ptNdcX =  ((double)x - halfScreenX) / halfScreenX;
    final double ptNdcY = -((double)y - halfScreenY) / halfScreenX;
    // Initialize ray direction to far clip plane projection.
    ray.dir.set(ptNdcX, ptNdcY, -focalLength).normalize();
    ray.pt.zero();
    return ray;
  }

  private final int MAX_BOUNCE = 60;
  private final double BOUNCE_EPSILON = 1.0e-10;

  ///<summary>Compute Phong shading at surface point p.</summary>
  private double traceRay(int depth, Ray ray, Geometry[] shapes,
                          Light[] lights, Vector3 iA,
                          ArrayPool.Vector3 vector3Pool,
                          ArrayPool.Ray rayPool,
                          RayTester rayTester,
                          Vector3 color) {
    if (depth >= MAX_BOUNCE) {
      return Double.POSITIVE_INFINITY;
    }

    // Find intersection to closest shape.
    rayTester.run(ray, shapes);
    // If nothing intersects, then the color is background.
    if (rayTester.hitIdx < 0) {
      color.set(bgColor);
      return Double.POSITIVE_INFINITY;
    }

    // Phong shade the intersected shape.
    final int hitIdx = rayTester.hitIdx;
    Geometry s = shapes[hitIdx];
    Geometry.Material m = s.material;

    // Allocate from pooled memory.
    final int VECTOR3_ALLOC_COUNT = 12;
    Vector3 p, N, diffuse, specular, lightDir,
            reflectPt, reflectDir, reflectColor,
            refractPt, refractDir, refractColor,
            iTmp;
    {
      int poolIdx = vector3Pool.alloc(VECTOR3_ALLOC_COUNT);
      Vector3[] pool = vector3Pool.get();
      p = pool[poolIdx++];
      N = pool[poolIdx++];
      diffuse = pool[poolIdx++].zero();
      specular = pool[poolIdx++].zero();
      lightDir = pool[poolIdx++];
      reflectPt = pool[poolIdx++];
      reflectDir = pool[poolIdx++];
      reflectColor = pool[poolIdx++].zero();
      refractPt = pool[poolIdx++];
      refractDir = pool[poolIdx++];
      refractColor = pool[poolIdx++].zero();
      iTmp = pool[poolIdx++];
    }
    final int RAY_ALLOC_COUNT = 3;
    Ray rayShadow, rayReflect, rayRefract;
    {
      int poolIdx = rayPool.alloc(RAY_ALLOC_COUNT);
      Ray[] pool = rayPool.get();
      rayShadow = pool[poolIdx++];
      rayShadow.pt = iTmp;
      rayShadow.dir = lightDir;
      rayReflect = pool[poolIdx++];
      rayReflect.pt = reflectPt;
      rayReflect.dir = reflectDir;
      rayRefract = pool[poolIdx++];
      rayRefract.pt = refractPt;
      rayRefract.dir = refractDir;
    }
    // Initialize point and normal.
    final double pxDepth = rayTester.intervals[hitIdx].get()[0];
    p.set(rayTester.points[hitIdx].get()[0]);
    N.set(rayTester.normals[hitIdx].get()[0]);
    final double rayDirDotN = ray.dir.dot(N);
    // Initialize refraction.
    refractDir.set(ray.dir);
    refractPt.set(refractDir).mul(BOUNCE_EPSILON);
    refractPt.add(rayTester.points[hitIdx].get()[rayTester.hits - 1]);

    // Spawn transmission ray when transparent.
    if (m.opacity < 1) {
      // Compute sin(theta) for reflection dir.
      if (1 != m.refractionIndex) {
        // Get sin(theta).
        refractDir.set(N).mul(-rayDirDotN).add(ray.dir);
        refractDir.mul(1.0 / m.refractionIndex);
        // Offset cos(theta) for refractDir.
        refractPt.set(N).mul(rayDirDotN);
        refractDir.add(refractPt).normalize();
        // Shoot refraction ray to find the new exit point.
        refractPt.set(refractDir).mul(-BOUNCE_EPSILON).add(p);
        rayTester.run(rayRefract, s);
        // TODO(reissb) -- 20120409 -- Check for total internal reflection.
        // Bend back on exit.
        final int exitIdx = rayTester.hits - 1;
        final int exitHitIdx = rayTester.hitIdx;
        Vector3 refractExitDir = rayTester.normals[exitHitIdx].get()[exitIdx];
        final double refactDirDotExitDir = -refractDir.dot(refractExitDir);
        iTmp.set(refractExitDir).mul(-refactDirDotExitDir).add(refractDir);
        iTmp.mul(m.refractionIndex);
        // Offset cos(theta) for refractDir.
        refractPt.set(refractExitDir).mul(refactDirDotExitDir);
        refractDir.set(iTmp).add(refractPt).normalize();
        // Get exit point.
        refractPt.set(refractDir).mul(BOUNCE_EPSILON);
        refractPt.add(rayTester.points[exitHitIdx].get()[exitIdx]);
      }
      // Shoot refraction ray to get refracted color.
      traceRay(depth + 1, rayRefract, shapes, lights, iA,
               vector3Pool, rayPool, rayTester, refractColor);
    }

    // Spawn reflection ray with slight epsilon offset.
    if (m.reflectivity > 0) {
      reflectDir.set(N).mul(-rayDirDotN).mul(2).add(ray.dir);
      // Move by small epsilon away from surface.
      reflectPt.set(reflectDir).mul(BOUNCE_EPSILON).add(p);
      traceRay(depth + 1, rayReflect, shapes, lights, iA,
               vector3Pool, rayPool, rayTester, reflectColor);
    }

    // Compute diffuse, specular color.
    for (Light l : lights) {
      final double lightDistSq = l.getDirectionAtPoint(p, lightDir);
      // Shadow ray test. Check transparency.
      double shadowMix = 1.0;
      if (l.castShadows) {
        iTmp.set(lightDir).mul(BOUNCE_EPSILON).add(p);
        rayTester.run(rayShadow, shapes);
        final int shadowHitIdx = rayTester.hitIdx;
        if (shadowHitIdx >= 0) {
          final double d = rayTester.intervals[shadowHitIdx].get()[0];
          if ((d * d) < (lightDistSq)) {
            // Mix color in shadow!
            final double shadowOpacity = 1.0 - shapes[shadowHitIdx].material.opacity;
            if (0 == shadowOpacity) {
              continue;
            }
            else {
              shadowMix = shadowOpacity;
              iTmp.set(shapes[shadowHitIdx].material.kA).mul(iA).mul(1.0 - shadowMix);
              diffuse.add(iTmp);
            }
          }
        }
      }
      // Light is visible?
      final double lightDirDotN = lightDir.dot(N);
      if (lightDirDotN > 0) {
        // Diffuse part.
        l.getIntensity(p, lightDir, iTmp);
        iTmp.mul(lightDirDotN).mul(m.kD).mul(shadowMix);
        diffuse.add(iTmp);
        // Specular part.
        reflectDir.set(N).mul(lightDirDotN).mul(2).sub(lightDir);
        final double reflectDirDotV = -reflectDir.dot(ray.dir);
        if (reflectDirDotV > 0) {
          final double specularAttenuation = Math.pow(reflectDirDotV, m.alphaS);
          l.getIntensity(p, lightDir, iTmp);
          iTmp.mul(specularAttenuation).mul(m.kS).mul(shadowMix);
          specular.add(iTmp);
        }
      }
    }

    // Compute final color.
    color.set(iA).mul(m.kA).mul(m.opacity);
    color.add(specular.mul(m.opacity));
    color.add(diffuse.mul(m.opacity));
    color.add(reflectColor.mul(m.reflectivity));
    color.add(refractColor.mul(1.0 - m.opacity));
    color.clip(0, 1);

    // Return pooled variables.
    vector3Pool.free(VECTOR3_ALLOC_COUNT);
    rayPool.free(RAY_ALLOC_COUNT);

    return pxDepth;
  }

  // Rendering variables.
  private Vector3 bgColor = new Vector3(0.25, 0.25, 1);

  private float[] depthMap = null;
  private final double depthPerChannel = 20;
  // Depth map edge threshold.
  private double depthEdgeThreshScale = 0.2;
  private boolean showDepthMap = false;

  private byte[] firingPattern = null;
  private boolean showFiringPattern = false;

  // Image space edge threshold.
  double edgeThresh = 0.065;

  Random randGen = new Random(System.currentTimeMillis());

  // Interpolation types.
  public enum Interpolation { None, BlerpBox, BlerpCross, }

  ///<summary>Raytracing render environment.</summary>
  class RaytraceRenderContext {
    private RayTester rayTester = new RayTester();
    private ArrayPool.Vector3 vector3Pool = new ArrayPool.Vector3();
    private ArrayPool.Ray rayPool = new ArrayPool.Ray();
  }

  ///<summary>A raytracting task.</summary>
  class RaytraceTask implements Callable<Integer> {
    // Rendering variables.
    public int l = 0, r = 0, t = 0, b = 0;
    private Ray rayProject = Ray.createZero();
    private Vector3 pxColor = Vector3.vectorZero();
    public int sampleGrid = 1;
    public int stepX = 0;
    public int stepY = 0;

    // Inerpolation variables.
    public Interpolation interpolation = Interpolation.None;
    private Vector3 tl = Vector3.vectorZero();
    private Vector3 tr = Vector3.vectorZero();
    private Vector3 bl = Vector3.vectorZero();
    private Vector3 br = Vector3.vectorZero();

    ///<summary>Invoke render task.</summary>
    public Integer call() {
      // Check scaline mode.
      if ((Interpolation.None == interpolation) || (1 == sampleGrid)) {
        return render();
      }
      else {
        return interpolation();
      }
    }

    ///<summary>Render with interpolation.</summary>
    private int interpolation() {
      final int tag = ((TaggedThreadFactory.ThreadWithTag)Thread.currentThread()).tag;
      RaytraceRenderContext renderContext = renderContexts[tag];
      ArrayPool.Vector3 vector3Pool = renderContext.vector3Pool;
      ArrayPool.Ray rayPool = renderContext.rayPool;
      RayTester rayTester = renderContext.rayTester;
      // Scan in a grid using blerp.
      final int sampleGridPitch = sampleGrid * width;
      // Use "X" pattern to optimize blerp?
      final boolean useXBlerp = ((sampleGrid / 2) == stepY) &&
                                ((sampleGrid / 2) == stepX);
      int px = 0;
      int rays = 0;
      final int stepYPitch = stepY * width;
      // Initialize interpolation pivot indices.
      int tlIdx = 0, trIdx = 0, blIdx = 0, brIdx = 0;
      if (Interpolation.BlerpBox == interpolation) {
        tlIdx = (t * width) + l;
        trIdx = tlIdx + sampleGrid;
        blIdx = tlIdx + sampleGridPitch;
        brIdx = blIdx + sampleGrid;
      }
      else if (Interpolation.BlerpCross == interpolation) {
        // l, r, t, b
        tlIdx = ((t + stepY) * width) + l;
        trIdx = tlIdx + sampleGrid;
        blIdx = tlIdx - (stepY * width) + stepX;
        brIdx = tlIdx + sampleGridPitch;
      }
      int y = t + stepY;
      int pxIdx = (y * width);
      for (; y < b; y += sampleGrid) {
        final int pxIdxNext = pxIdx + sampleGridPitch;
        final int tlIdxNext = tlIdx + sampleGridPitch;
        final int trIdxNext = trIdx + sampleGridPitch;
        final int blIdxNext = blIdx + sampleGridPitch;
        final int brIdxNext = brIdx + sampleGridPitch;
        // Unpack left-hand interpolation pivots.
        final int ySteps = y - t;
        final double lerpY = (double)(ySteps % sampleGrid) / (double)sampleGrid;
        int x = l + stepX;
        unpackRgb(pixels[tlIdx], tl);
        unpackRgb(pixels[blIdx], bl);
        double tlDepth = depthMap[tlIdx];
        double blDepth = depthMap[blIdx];

        for (pxIdx += x; x < r; x += sampleGrid, pxIdx += sampleGrid,
                                tlIdx += sampleGrid, blIdx += sampleGrid,
                                trIdx += sampleGrid, brIdx += sampleGrid) {
          // Unpack right-hand interpolation pivots.
          unpackRgb(pixels[trIdx], tr);
          unpackRgb(pixels[brIdx], br);
          double trDepth = depthMap[trIdx];
          double brDepth = depthMap[brIdx];
          final double depthSampleMin = Math.min(Math.min(Math.min(tlDepth, trDepth),
                                                          blDepth), brDepth);

          final int xSteps = x - l;
          final double lerpX = (double)(xSteps % sampleGrid) / (double)sampleGrid;
          final double dEdgeThresh = depthEdgeThreshScale * depthSampleMin;
          boolean edge = false;
          if (Interpolation.BlerpBox == interpolation) {
            edge = Edge.edgeBox(tl, tr, bl, br, edgeThresh) ||
                   Edge.depthEdgeBox(tlDepth, trDepth, blDepth, brDepth, dEdgeThresh);
          }
          else if (Interpolation.BlerpCross == interpolation) {
            edge = Edge.edgeCross(tl, tr, bl, br, edgeThresh) ||
                   Edge.depthEdgeCross(tlDepth, trDepth, blDepth, brDepth, dEdgeThresh);
          }
          // Edge?
          if (edge) {
            // Get 3d ray in the scene.
            projectRay(width, height, x, y, rayProject);
            final double d = traceRay(0, rayProject, shapes, lights, iA,
                                      vector3Pool, rayPool, rayTester, pxColor);
            depthMap[pxIdx] = (float)d;
            ++rays;
            firingPattern[pxIdx] = 1;
          }
          else {
            if (Interpolation.BlerpBox == interpolation) {
              // X pattern speedup.
              if (useXBlerp) {
                pxColor.set(tl).add(tr).add(bl).add(br).mul(0.25);
              }
              else {
                Util.blerpBox(tl, tr, bl, br, lerpX, lerpY, pxColor);
              }
              final double depthBlerp = Util.blerpBox(tlDepth, trDepth, blDepth, brDepth,
                                                      lerpX, lerpY);
              depthMap[pxIdx] = (float)depthBlerp;
            }
            else if (Interpolation.BlerpCross == interpolation) {
              Util.blerpCross(tl, tr, bl, br, lerpX, lerpY, pxColor);
              final double depthBlerp = Util.blerpCross(tlDepth, trDepth, blDepth, brDepth,
                                                        lerpX, lerpY);
              depthMap[pxIdx] = (float)depthBlerp;
            }
            firingPattern[pxIdx] = 0;
          }
          ++px;
          // Set the color!
          final int r = (int)(pxColor.x * 255);
          final int g = (int)(pxColor.y * 255);
          final int b = (int)(pxColor.z * 255);
          pixels[pxIdx] = pack(r, g, b);
          // Load next interpolation pivots.
          {
            // swap(tl, tr);
            { Vector3 tmp = tl; tl = tr; tr = tmp; }
            tlDepth = trDepth;
            // swap(bl, br);
            { Vector3 tmp = bl; bl = br; br = tmp; }
            blDepth = brDepth;
          }
        }
        pxIdx = pxIdxNext;
        tlIdx = tlIdxNext; trIdx = trIdxNext;
        blIdx = blIdxNext; brIdx = brIdxNext;
      }
      return px;
    }

    ///<summary>Render without interpoltion.</summary>
    private int render() {
      final int tag = ((TaggedThreadFactory.ThreadWithTag)Thread.currentThread()).tag;
      RaytraceRenderContext renderContext = renderContexts[tag];
      ArrayPool.Vector3 vector3Pool = renderContext.vector3Pool;
      ArrayPool.Ray rayPool = renderContext.rayPool;
      RayTester rayTester = renderContext.rayTester;
      int pxIdx = (t * width) + l;
      final int sampleGridPitch = sampleGrid * width;
      for (int y = t; y < b; y += sampleGrid) {
        final int pxIdxNext = pxIdx + sampleGridPitch;
        for (int  x = l; x < r; x += sampleGrid, pxIdx += sampleGrid) {
          // Get 3d ray in the scene.
          firingPattern[pxIdx] = 1;
          projectRay(width, height, x, y, rayProject);
          final double d = traceRay(0, rayProject, shapes, lights, iA,
                                    vector3Pool, rayPool, rayTester, pxColor);
          depthMap[pxIdx] = (float)d;
          final int r = Math.max(0, Math.min(255, (int)(pxColor.x * 255)));
          final int g = Math.max(0, Math.min(255, (int)(pxColor.y * 255)));
          final int b = Math.max(0, Math.min(255, (int)(pxColor.z * 255)));
          pixels[pxIdx] = pack(r, g, b);
        }
        pxIdx = pxIdxNext;
      }
      return b;
    }
  }

  // Concurrency objects.
  private int numProcessors = 0;
  private int numTasks = 0;
  private ArrayList<RaytraceTask> tasks = null;
  private ExecutorService pool = null;
  class TaggedThreadFactory implements ThreadFactory {
    private int nextTag = 0;
    public class ThreadWithTag extends Thread {
      public int tag;
      ThreadWithTag(Runnable r, int tag_) {
        super(r);
        tag = tag_;
      }
    }
    public Thread newThread(Runnable r) {
      return new ThreadWithTag(r, nextTag++);
    }
  }
  private RaytraceRenderContext[] renderContexts = null;

  public void unpackRgb(int c, Vector3 v) {
    v.x = (double)unpack(c, 0) / 255.0;
    v.y = (double)unpack(c, 1) / 255.0;
    v.z = (double)unpack(c, 2) / 255.0;
  }

  ///<summary>Perform gamma compression.</summary>
  public int gammaCompression(int color) {
    final double x = (double)unpack(color, 0) / 255.0;
    final double y = (double)unpack(color, 1) / 255.0;
    final double z = (double)unpack(color, 2) / 255.0;
    final int r = (int)(Math.sqrt(x) * 255.0);
    final int g = (int)(Math.sqrt(y) * 255.0);
    final int b = (int)(Math.sqrt(z) * 255.0);
    return pack(r, g, b);
  }

  ///<summary>Configure render tasks to render a rectangle.</summary>
  void setupRenderTasks(int l, int r, int t, int b,
                        int sampleGrid, int stepX, int stepY,
                        int firstIdx, int numTasks, Interpolation mode) {
    final int numGridLines = (b - t) / sampleGrid;
    final int numScanlinesPerTask = sampleGrid * (numGridLines / numTasks);
    // All vertical scanline stacks.
    final int iEnd = firstIdx + numTasks;
    for (int i = firstIdx; i < iEnd; ++i) {
      RaytraceTask task = tasks.get(i);
      task.l = l;
      task.r = r;
      task.t = t + (i * numScanlinesPerTask);
      task.b = task.t + numScanlinesPerTask;
      task.sampleGrid = sampleGrid;
      task.interpolation = mode;
      task.stepX = stepX;
      task.stepY = stepY;
    }
    tasks.get(iEnd - 1).b = b;
  }

  ///<summary>Render the raytraced scene.</summary>
  public void computeImage(double t) {
    final int pixelsLength = pixels.length;

    // Perform animation updates.
    {
      SceneObject glassEllipsoid = shapeControllers[ShapeId.GLASS_ELLIPSOID.idx()];
      glassEllipsoid.transformLocal.identity();
      glassEllipsoid.transformLocal.translate(0,-2, 1.8);
      glassEllipsoid.transformLocal.rotateZ(0.5 * t);

      shapeControllers[ShapeId.GROUND.idx()].transformLocal.identity();

      shapeControllers[ShapeId.GOLD_BOX.idx()].transformLocal.identity();
      shapeControllers[ShapeId.GOLD_BOX.idx()].transformLocal.translate( 3, 2, 1);

      shapeControllers[ShapeId.CYL_BASE.idx()].transformLocal.identity();
      shapeControllers[ShapeId.CYL_BASE.idx()].transformLocal.translate(-3.5, 2, 1);

      SceneObject plasticCyl0 = shapeControllers[ShapeId.PLASTIC_CYL_LONG_0.idx()];
      plasticCyl0.transformLocal.identity();
      plasticCyl0.transformLocal.translate(-0.4, 2, 0.1);
      plasticCyl0.transformLocal.rotateX(Math.PI * 0.5);
      plasticCyl0.transformLocal.rotateY(Math.PI * 0.16);

      SceneObject plasticCyl1 = shapeControllers[ShapeId.PLASTIC_CYL_LONG_1.idx()];
      plasticCyl1.transformLocal.identity();
      plasticCyl1.transformLocal.translate(-6, 4, 0.2);
      plasticCyl1.transformLocal.rotateX(Math.PI * 0.5);
      plasticCyl1.transformLocal.rotateY(Math.PI * 0.12);
    }
    scene.updateTransform();

    int sampleGrid = 4;
    int step = sampleGrid / 2;

    final int imgW = ((width - sampleGrid + 1) / sampleGrid) * sampleGrid;
    final int imgH = ((height - sampleGrid + 1) / sampleGrid) * sampleGrid;
    // Render every 4x4, right column, and bottom row.
    {
      setupRenderTasks(0, width, 0, height, sampleGrid, 0, 0,
                       0, numTasks - 2, Interpolation.None);
      final int lastTaskIdx = numTasks - 3;
      // Right.
      {
        RaytraceTask task = tasks.get(lastTaskIdx + 1);
        task.l = imgW;
        task.r = imgW + 1;
        task.t = 0;
        task.b = imgH;
        task.sampleGrid = 1;
        task.interpolation = Interpolation.None;
      }
      // Bottom.
      {
        RaytraceTask task = tasks.get(lastTaskIdx + 2);
        task.l = 0;
        task.r = imgW;
        task.t = imgH;
        task.b = imgH + 1;
        task.sampleGrid = 1;
        task.interpolation = Interpolation.None;
      }
      try { pool.invokeAll(tasks); } catch (InterruptedException e) { }
    }
    // Interpolate 4x4 box.
    setupRenderTasks(0, imgW, 0, imgH, sampleGrid, step, step,
                     0, numTasks, Interpolation.BlerpBox);
    try { pool.invokeAll(tasks); } catch (InterruptedException e) { }
    // Interpolate 4x4 cross.
    setupRenderTasks(step, imgW, 0, imgH, sampleGrid, step, step,
                     0, numTasks, Interpolation.BlerpCross);
    try { pool.invokeAll(tasks); } catch (InterruptedException e) { }
    // Interpolate 4x4 cross.
    setupRenderTasks(0, imgW, step, imgH, sampleGrid, step, step,
                     0, numTasks, Interpolation.BlerpCross);
    try { pool.invokeAll(tasks); } catch (InterruptedException e) { }
    // Level up to 2x2.
    sampleGrid = 2;
    step = sampleGrid / 2;
    // Interpolate 2x2 box.
    setupRenderTasks(sampleGrid, imgW, sampleGrid, imgH,
                     sampleGrid, step, step,
                     0, numTasks, Interpolation.BlerpBox);
    try { pool.invokeAll(tasks); } catch (InterruptedException e) { }
    // Interpolate 2x2 cross.
    setupRenderTasks(sampleGrid + step, imgW, sampleGrid, imgH,
                     sampleGrid, step, step,
                     0, numTasks, Interpolation.BlerpCross);
    try { pool.invokeAll(tasks); } catch (InterruptedException e) { }
    // Interpolate 2x2 cross.
    setupRenderTasks(sampleGrid, imgW, sampleGrid + step, imgH,
                     sampleGrid, step, step,
                     0, numTasks, Interpolation.BlerpCross);
    try { pool.invokeAll(tasks); } catch (InterruptedException e) { }

    final int border = 4;
    // Blackout borders.
    {
      final int black = pack(0, 0, 0);;
      int pxIdx = 0;
      // Top.
      pxIdx = 0;
      for (int y = 0; y < border; ++y) {
        for (int x = 0; x < width; ++x, ++pxIdx) {
          pixels[pxIdx] = black;
        }
      }
      // Bottom.
      pxIdx = (height - border) * width;;
      for (int y = height - border; y < height; ++y) {
        for (int x = 0; x < width; ++x, ++pxIdx) {
          pixels[pxIdx] = black;
        }
      }
      // Left.
      for (int x = 0; x < border; ++x) {
        pxIdx = x;
        for (int y = 0; y < height; ++y, pxIdx += width) {
          pixels[pxIdx] = black;
        }
      }
      // Right.
      for (int x = width - border; x < width; ++x) {
        pxIdx = x;
        for (int y = 0; y < height; ++y, pxIdx += width) {
          pixels[pxIdx] = black;
        }
      }
    }
    // TODO(reissb) -- Parallelize gamma.
    // Gamma correction inside.
    {
      int pxIdx = border * width;
      for (int y = border; y < imgH; ++y) {
        pxIdx += border;
        for (int x = border; x < imgW; ++x, ++pxIdx) {
          pixels[pxIdx] = gammaCompression(pixels[pxIdx]);
        }
        pxIdx += width - imgW;
      }
    }
    // Show firing pattern.
    for (int pxIdx = 0; pxIdx < pixelsLength; ++pxIdx) {
      int x = pxIdx % width;
      int y = pxIdx / width;
      if (showFiringPattern) {
        if (0 != firingPattern[pxIdx]) {
          pixels[pxIdx] = pack(255, 0, 0);
        }
      }
      else if (showDepthMap) {
        final double depth = (double)depthMap[pxIdx];
        if (Double.POSITIVE_INFINITY == depth) {
          pixels[pxIdx] = pack(0, 0, 0);
        }
        else {
          double depthScaled = (depth - 2) / depthPerChannel;
          double depthClipped = Math.max(0, Math.min(1, depthScaled));
          int r = (int)(255.0 * Math.sqrt(1.0 - depthClipped));
          int g = (int)(255.0 * Math.sqrt(depthClipped));
          pixels[pxIdx] = pack(r, g, 0);
        }
      }
    }
  }
}

