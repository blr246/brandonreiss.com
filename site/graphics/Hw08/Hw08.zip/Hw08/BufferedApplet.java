// Ken Perlin 2011-2012. All Rights Reserved.
//
// THIS CLASS HANDLES DOUBLE BUFFERING FOR YOU, SO THAT THE IMAGE
// DOESN'T FLICKER WHILE YOU'RE RENDERING IT.  YOU DON'T REALLY
// NEED TO WORRY ABOUT THIS TOO MUCH, AND YOU'LL PROBABLY NEVER NEED
// TO CHANGE IT.  IT'S REALLY JUST USEFUL LOW LEVEL PLUMBING.

import javax.swing.*;
import java.awt.*;
import java.awt.image.*;

public abstract class BufferedApplet extends JApplet implements Runnable
{
  protected int[] pixels;
  protected MemoryImageSource mis;
  protected Image image;
  protected int width = 0;
  protected int height = 0; 

  private Thread anim = null;
  private final double startTime = System.currentTimeMillis() / 1000.0;
  private final int fpsTarget = 30;
  private final double tFrame = 1.0 / (double)fpsTarget;
  private final int sleepMs = (int)(tFrame * 1000.0);
  ImagePanel panel = new ImagePanel();

  // YOU MUST DEFINE A METHOD TO RENDER THE APPLET
  public void animate(double t) {}
  public void computeImage(double t, int[] pixels) {}
  public void initialize() {}

  public void init() {
    setLayout(new BorderLayout());
    Container contentPane = getContentPane();
    contentPane.add(panel);
  }

  public void start() {
    // START RENDER THREAD
    panel.init();
    anim = new Thread(this);
    anim.start();
  }

  private static Object lock = new Object();

  public void stop() {
    anim = null;
    synchronized (lock) {
      lock.notifyAll();
    }
  }

  // A BACKGROUND THREAD CALLS REPAINT EVERY sleepMs MILLISECONDS,
  public void run() {
    try { 
      synchronized (lock) {
        while (Thread.currentThread() == anim) {
          double tNow = 0, tElapsedMs = 0;
          double t = getTime();

          panel.updateFrame(t);

          tNow = getTime();
          tElapsedMs = (tNow - t) * 1000.0;
          if (tElapsedMs < sleepMs) {
            final long ms = (long)(sleepMs - tElapsedMs);
//            lock.wait(ms);
            Thread.sleep(ms);
          }

//          tNow = getTime();
//          tElapsedMs = (tNow - t) * 1000.0;
//          System.out.println("tElapsedMs = " + tElapsedMs);
        }
      }
    } catch (InterruptedException e) { return; }
  }

//  public boolean imageUpdate(Image img, int infoflags,
//                                          int x, int y, int width, int height)
//  {
//    System.out.println("imageUpdate -- infoflags = " + infoflags);
//    if (0 != (ImageObserver.FRAMEBITS & infoflags)) {
//      synchronized (lock) {
//        lock.notifyAll();
//      }
//      return false;
//    }
//    return true;
//  }

  // THE IMAGE YOU'VE RENDERED IS THEN COPIED TO THE SCREEN.

//  public void update(Graphics g) {
//    paint(g);
//  }
//
//  public void paint(Graphics g) {
//    g.drawImage(image, 0, 0, null);
////    g.drawImage(image, 0, 0, this);
//    synchronized (lock) {
//      lock.notifyAll();
//    }
//  }

  public class ImagePanel extends JPanel {

    void init () {
      width = getBounds().width;
      height = getBounds().height;
      {
        // FIND THE RESOLUTION OF THE JAVA APPLET
        // ALLOCATE A FRAME BUFFER IMAGE
        pixels = new int[width * height];
        mis = new MemoryImageSource(width, height, pixels, 0, width);
        mis.setAnimated(true);
        // MAKE MEMORY IMAGE SOURCE FOR FRAME BUFFER
        image = createImage(mis);
        // CALL USER INITIALIZE
        initialize();
      }
    }

    public void updateFrame(double t) {
      animate(t);

      computeImage(t, pixels);

//     image.flush();
      mis.newPixels();
//     repaint(); // This is NOT synchronous.
//     lock.wait();
    }

    public void paintComponent (Graphics g) {
      g.drawImage(image, 0, 0, this);
    }
  }

  /// <summary>Get time in seconds since this instance was created.</summary>
  public double getTime() {
    return (System.currentTimeMillis() / 1000.0) - startTime;
  }

  public int pack(int red, int grn, int blu) {
    return 255 << 24 | (red & 255) << 16
                     | (grn & 255) <<  8
                     | (blu & 255)     ;
  }

  public int unpack(int packedRGB, int component) {
    return packedRGB >> 8*(2-component) & 255;
  }
}

