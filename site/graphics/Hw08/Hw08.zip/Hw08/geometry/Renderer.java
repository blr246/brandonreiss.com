/*
 * Renderer.java
 *
 * A scene renderer. Transforms vertices and may apply a special vertex
 * transformation program.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.geometry;

import com.brandonreiss.math.*;
import com.brandonreiss.util.*;
import java.awt.*;
import java.util.EnumSet;
import java.util.ArrayList;
import java.util.Arrays;

///<summary>A z-buffer renderer.</summary>
public class Renderer { 

  ///<summary>The default vertex shader.</summary>
  private VertexProgram defaultVertexProgram = new ModelViewTransform();

  ///<summary>The view matrix inverse.</summary>
  public Matrix4x4 viewMat = Matrix4x4.newMatrixIdentity();
  ///<summary>The view matrix inverse.</summary>
  public Matrix4x4 viewMatInv = Matrix4x4.newMatrixIdentity();
  ///<symmary>The projection matrix.</summary>
  public Matrix4x4 projMat = Matrix4x4.newMatrixIdentity();
  ///<summary>Projection * view * model transform.</summary>
  private Matrix4x4 modelViewProjMat = Matrix4x4.newMatrixIdentity();
  ///<summary>Width of target screen.</summary>
  public Vector2 screenSize = new Vector2(640, 480);
  ///<summary>The canvas.</summary>
  public Graphics g = null;
  ///<summary>Set of render flags.</summary>
  public EnumSet<Flags> flags = EnumSet.noneOf(Flags.class);
  ///<summary>Vertex shader program.</summary>
  public VertexProgram vertexProgram = defaultVertexProgram;

  ///<summary>Projected vertices.</summary>
  private ArrayPtr.Vector3 projVertexColorsPtr = new ArrayPtr.Vector3();
  ///<summary>Projected vertices NDC clip status.</summary>
  private boolean[] projClipMask = new boolean[0];
  ///<summary>Face projection coordinates swap A.</summary>
  private ArrayPtr.Vector3 faceVerticesAPtr = new ArrayPtr.Vector3();
  ///<summary>Face projection coordinates swap B.</summary>
  private ArrayPtr.Vector3 faceVerticesBPtr = new ArrayPtr.Vector3();

  // Pixel coordinates.
  int screenPtsCapacity = 0;
  int[] screenPtsX = null;
  int[] screenPtsY = null;

  ///<summary>Camera z-direction used for culling.</summary.
  private Vector3 cameraZDir = new Vector3(0, 0, 1);
  private Vector3 cullEdge0 = new Vector3();
  private Vector3 cullEdge1 = new Vector3();
  private Vector3 cullNormal = new Vector3();

  ///<summary>Set of render states.</summary>
  public enum Flags {
    CULL_BACKFACE,
    ZBUFFER_ENABLE,
    WIRE_TRIANGLES,
    ALPHA_BLEND,
    SHADOW_MAP,
  }

  ///<summary>Vertex processing to occur just before rasterization.</summary>
  public interface VertexProgram {
    public void run(Matrix4x4 modelViewProjMat,
                    Vector3[] in, Vector3[] out);
  }

  ///<summary>The standard modelview vertex program.</summary>
  private class ModelViewTransform implements VertexProgram {
    @Override
    public void run(Matrix4x4 modelViewProjMat,
                    Vector3[] vertexNormals, Vector3[] clipColor) {
      // TODO(reissb) -- Compute lighting.
      final int vertexNormalsLength = vertexNormals.length;
      assert(vertexNormalsLength <= clipColor.length);
      for (int i = 0; i < vertexNormalsLength; i += 2) {
        clipColor[i].set(vertexNormals[i]).transformCoord(modelViewProjMat);
      }
    }
  }


  ///<summary>Restore the default vertex program.</summary>
  public void resetVertexProgram() {
    vertexProgram = defaultVertexProgram;
  }

  ///<summary>Render the mesh.</summary>
  public void render(Mesh mesh) {
    // Transform and light vertices.
    Vector3[] vertexNormals = mesh.vertexNormals;
    assert(null != vertexNormals);
    final int vertexNormalsLength = vertexNormals.length;
    final int verticesLength = vertexNormalsLength >> 1;
    Vector3[] projVertexColors = projVertexColorsPtr.grow(vertexNormalsLength);
    if (projClipMask.length < verticesLength) {
      projClipMask = new boolean[verticesLength];
    }
    // Compute model view matrix for this mesh depending on parent.
    modelViewProjMat.set(projMat).mul(viewMat);
    if (mesh.hasParent()) {
      modelViewProjMat.mul(mesh.transform);
    }
    else {
      modelViewProjMat.mul(mesh.transformLocal);
    }
    // Vector::toArray() will only allocate a new array when the size changes.
    vertexProgram.run(modelViewProjMat, vertexNormals, projVertexColors);

    // Set the color. This will eventually be per-vertex.
    g.setColor(Color.black);

    // Project the vertices and check mesh clip.
    int clipVerticesMesh = 0;
    for (int vIdx = 0; vIdx < vertexNormalsLength; vIdx += 2) {
      Vector3 vProj = projVertexColors[vIdx];
      // Check vertex clip in NDC.
      final boolean clipV = (vProj.min() < -1) || (vProj.max() > 1);
      projClipMask[vIdx >> 1] = clipV;
      clipVerticesMesh += clipV ? 1 : 0;
    }
    // Check clip entire mesh.
    if (verticesLength == clipVerticesMesh) {
      return;
    }

    // Setup screen space transform.
    final double halfScreenW = screenSize.x / 2.0;
    final double halfScreenH = screenSize.y / 2.0;

    // Draw the faces.
    int[][] faces = mesh.faces;
    assert(null != faces);
    for (int[] face : faces) {
      assert(null != face);
      final int faceLength = face.length;
      assert(faceLength >= 3);
      // Check projection buffer length.
      Vector3[] faceVertices = faceVerticesAPtr.grow(faceLength);
      faceVerticesBPtr.grow(faceLength);

      // Get projected face and check clipping.
      int clipVerticesFace = 0;
      for (int fIdx = 0; fIdx < faceLength; ++fIdx) {
        Vector3 v = faceVertices[fIdx];
        v.set(projVertexColors[face[fIdx]]);
        clipVerticesFace += projClipMask[face[fIdx] >> 1] ? 1 : 0;
      }
      if (faceLength == clipVerticesFace) {
        continue;
      }

      // Culling.
      if (flags.contains(Flags.CULL_BACKFACE)) {
        // Assume convex and compute normal.
        cullEdge0.set(faceVertices[1]).sub(faceVertices[0]);
        cullEdge1.set(faceVertices[2]).sub(faceVertices[0]);
        // Cross to get face normal.
        cullNormal.set(cullEdge0).cross(cullEdge1);
        // Backfaces point in same direction as camera.
        final double cullCheck = cameraZDir.dot(cullNormal);
        if (cullCheck < 0) {
          continue;
        }
      }

      // Clip when needed.
      int clippedFaceLength = faceLength;
      if (clipVerticesFace > 0) {
        // Clip to projection NDC cuboid (will result to B).
        clippedFaceLength = clipSutherlandHodgman(faceVerticesAPtr, faceLength,
                                                  faceVerticesBPtr);
        faceVertices = faceVerticesBPtr.get();
      }

      // Increase screen buffer if clipping emits additional lines.
      if (clippedFaceLength > screenPtsCapacity) {
        screenPtsCapacity = clippedFaceLength;
        screenPtsX = new int[screenPtsCapacity];
        screenPtsY = new int[screenPtsCapacity];
      }
      // Screen transformation.
      for (int fIdx = 0; fIdx < clippedFaceLength; ++fIdx) {
        Vector3 v = faceVertices[fIdx];
        screenPtsX[fIdx] = (int)Math.max(Math.min(( v.x * halfScreenW) + halfScreenW,
                                                  screenSize.x - 1), 0);
        screenPtsY[fIdx] = (int)Math.max(Math.min((-v.y * halfScreenH) + halfScreenH,
                                                  screenSize.x - 1), 0);
      }
      if (mesh.wireframe) {
        g.drawPolygon(screenPtsX, screenPtsY, clippedFaceLength);
      }
      else {
        g.fillPolygon(screenPtsX, screenPtsY, clippedFaceLength);
      }
    }
  }

  ///<summary>Temporary used for clipping.</summary>
  private Vector3 clipTmp = new Vector3();
  ///<summary>Temporary used for clipping.</summary>
  private Vector3 clipProjDirTmp = new Vector3();
  ///<summary>Projection cuboid clipped using unit cube.</summary>
  private Vector4[] clipPlanes = {new Vector4( 1, 0, 0,-1),
                                  new Vector4(-1, 0, 0,-1),
                                  new Vector4( 0, 1, 0,-1),
                                  new Vector4( 0,-1, 0,-1),
                                  new Vector4( 0, 0, 1,-1),
                                  new Vector4( 0, 0,-1,-1)};

  ///<summary>Sutherland-Hodgman clip algorithm.</summary>
  ///<remarks>
  ///<para>See
  ///http://en.wikipedia.org/wiki/Sutherland%E2%80%93Hodgman_algorithm
  ///for more information.
  ///</para>
  ///</remarks>
  private int clipSutherlandHodgman(ArrayPtr.Vector3 inputListPtr, int faceLength,
                                    ArrayPtr.Vector3 outputListPtr) {
    int clippedFaceLength = faceLength;
    Vector3[] inputList = inputListPtr.get();
    Vector3[] outputList = outputListPtr.get();
    // Copy input to output.
    for (int i = 0; i < clippedFaceLength; ++i) {
      outputList[i].set(inputList[i]);
    }
    // Loop over clip polygons (X-axis, Y-axis, Z-axis).
    final int clipPlanesLength = clipPlanes.length;
    for (int clipPlaneIdx = 0;
         (clipPlaneIdx < clipPlanesLength) &&
         (clippedFaceLength > 0); ++clipPlaneIdx) {
      Vector4 clipPlane = clipPlanes[clipPlaneIdx];
      // Copy output to input.
      for (int i = 0; i < clippedFaceLength; ++i) {
        inputList[i].set(outputList[i]);
      }
      // Initialize list sizes, point, inside test.
      final int listSize = inputList.length;
      int outputListSize = 0;
      Vector3 s = inputList[clippedFaceLength - 1];
      boolean sInside = Util.PointPlaneDistance(s, clipPlane) <= 0;
      // Test all points in polygon.
      for (int vIdx = 0; vIdx < clippedFaceLength; ++vIdx) {
        Vector3 e = inputList[vIdx];
        final boolean eInside = Util.PointPlaneDistance(e, clipPlane) <= 0;
        if (eInside) {
          if (!sInside) {
            // Project to clip plane.
            clipProjDirTmp.set(e).sub(s).normalize();
            Util.PointProjectPlaneAlongDir(clipTmp.set(s), clipPlane,
                                           clipProjDirTmp);
//            // DEBUG clip error.
//            if ((e.z < 0) && (clipTmp.z > 0))
//            {
//              System.out.println("s = " + s + ", e = " + e + ", clipTmp = " + clipTmp);
//            }
            // Add projected point.
            outputList = outputListPtr.grow(outputListSize + 1);
            outputList[outputListSize].set(clipTmp);
            ++outputListSize;
          }
          // Add original point.
          outputList = outputListPtr.grow(outputListSize + 1);
          outputList[outputListSize].set(e);
          ++outputListSize;
        }
        else if (sInside) {
          // Project to clip plane.
          clipProjDirTmp.set(s).sub(e).normalize();
          Util.PointProjectPlaneAlongDir(clipTmp.set(e), clipPlane,
                                         clipProjDirTmp);
//          // DEBUG clip error.
//          if ((s.z < 0) && (clipTmp.z > 0))
//          {
//              System.out.println("e = " + s + ", s = " + e + ", clipTmp = " + clipTmp);
//          }
          // Add projected point.
          outputList = outputListPtr.grow(outputListSize + 1);
          outputList[outputListSize].set(clipTmp);
          ++outputListSize;
        }
        s = e;
        sInside = eInside;
      }
      // Sync input list size.
      final int numToAdd = outputListSize - listSize;
      inputList = inputListPtr.grow(outputListSize);
      clippedFaceLength = outputListSize;
    }
    // Return length of result.
    return clippedFaceLength;
  }
}

