/*
 * Light.java
 *
 * A light interface.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.geometry;
import com.brandonreiss.math.*;

///<summary>A light used during shading.</summary>
public abstract class Light extends SceneObject {
  public boolean castShadows = true;
  public abstract double getDirectionAtPoint(Vector3 p, Vector3 dir);
  public abstract void getIntensity(Vector3 p, Vector3 dir, Vector3 iPt);
}

