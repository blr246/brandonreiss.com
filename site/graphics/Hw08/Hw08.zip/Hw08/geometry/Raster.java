package com.brandonreiss.geometry;

import com.brandonreiss.math.*;
import com.brandonreiss.util.*;

public class Raster {
  ///<summary>Takes a list of triangles and rasterizes them.<summary>
  ///<remarks>
  ///<para>The triangles are of the form [v0, c0, v1, c1, v2, c2, ...] where
  ///the nth triangle starts at index 6n and each pair vi, ci is the vertex
  ///in clip space followed by the vertex color.
  ///</remarks>
  public static void rasterizeTriangles(Vector3[] triangles,
                                        Vector3 vTmp, Vector3 cTmp,
                                        int w, int h, int[] frameBuffer, int[] zBuffer) {
    // Determine top, middle, bottom vertices.
    final int trianglesLength = triangles.length;
    for (int i = 0; i < trianglesLength; i += 6) {
      // Determine where to split the top and bottom trapezpoids.
      Vector3 v0 = triangles[i];     Vector3 c0 = triangles[i + 1];
      Vector3 v1 = triangles[i + 2]; Vector3 c1 = triangles[i + 3];
      Vector3 v2 = triangles[i + 4]; Vector3 c2 = triangles[i + 5];
      int state = ((v0.y > v1.y) ? 4 : 0) +
                  ((v1.y > v2.y) ? 2 : 0) +
                  ((v0.y > v2.y) ? 1 : 0);
      switch (state) {
        case 7: break;
        case 6:
        case 4:
          // v2 < v0 < v1 ==> rotateLeft(v2, v0, v1)
          { Vector3 tmp = v0; v0 = v2; v2 = v1; v1 = tmp; }
          { Vector3 tmp = c0; c0 = c2; c2 = c1; c1 = tmp; }
          break;
        case 3:
          // v1 < v0 < v2 ==> swap(v1, v0)
          { Vector3 tmp = v1; v1 = v0; v0 = tmp; }
          { Vector3 tmp = c1; c1 = c0; c0 = tmp; }
          break;
        case 2:
          // v1 < v2 < v0 ==> rotateRight(v1, v2, v0)
          { Vector3 tmp = v0; v0 = v1; v1 = v2; v2 = tmp; }
          { Vector3 tmp = c0; c0 = c1; c1 = c2; c2 = tmp; }
          break;
        case 5:
        case 1:
          // v0 < v2 < v1 ==> swap(v2, v1)
          { Vector3 tmp = v2; v2 = v1; v1 = tmp; }
          { Vector3 tmp = c2; c2 = c1; c1 = tmp; }
          break;
        case 0:
          // v2 < v1 < v0 ==> swap(v2, v0)
          { Vector3 tmp = v2; v2 = v0; v0 = tmp; }
          { Vector3 tmp = c2; c2 = c0; c0 = tmp; }
        default: break;
      }
      assert((v0.y < v1.y) && (v1.y < v2.y) && (v2.y < v2.y));
      // Interpolate temporary vertex vTmp = A + (t * (B - A))
      final double t = (v1.y - v0.y) / (v2.y - v0.y);
      vTmp.x = v0.x + (t * (v2.x - v0.x));
      vTmp.y = v1.y;
      vTmp.z = v0.z + (t * (v2.z - v0.z));
      // Interpolate temporary color.
      cTmp.x = c0.x + (t * (c2.x - c0.x));
      cTmp.y = c0.y + (t * (c2.y - c0.y));
      cTmp.z = c0.z + (t * (c2.z - c0.z));
      // Render both trapezoidal parts.
//      System.out.println("v0.y = " + v0.y + ", " +
//                         "v1.y = " + v1.y + ", " +
//                         "vTmp.y = " + vTmp.y + ", " +
//                         "v2.y = " + v2.y);
//      System.out.println("state = " + state + ", " +
//                         "t = " + t + ", " +
//                         "vTmp = " + vTmp + ", " +
//                         "cTmp = " + cTmp);
 
      if (vTmp.x < v1.x) {
        Raster.rasterizeTrapezoid(v0, v0, vTmp, v1,
                                  c0, c0, cTmp, c1, w, h, frameBuffer, zBuffer);
        Raster.rasterizeTrapezoid(vTmp, v1, v2, v2,
                                  cTmp, c1, c2, c2, w, h, frameBuffer, zBuffer);
      }
      else
      {
        Raster.rasterizeTrapezoid(v0, v0, v1, vTmp,
                                  c0, c0, c1, cTmp, w, h, frameBuffer, zBuffer);
        Raster.rasterizeTrapezoid(v1, vTmp, v2, v2,
                                  c1, cTmp, c2, c2, w, h, frameBuffer, zBuffer);
      }
    }
  }

  // Scale all pixels to facilitate iterative interpolation.
  final static int PX_SCALE_SHIFT = 19;
  final static int PX_SCALE = 1 << PX_SCALE_SHIFT;
  final static int PX_SCALE_HALF = PX_SCALE >> 1;
  // Scale all colors to facilitate iterative interpolation.
  final static int COLOR_SCALE_SHIFT = 22;
  final static int COLOR_SCALE = 1 << COLOR_SCALE_SHIFT;
  final static int COLOR_SCALE_HALF = COLOR_SCALE >> 1;
  final static double SQRT_255 = Math.sqrt(255);

  ///<summary>Rasterize a single trapezoid.</summary>
  ///<remarks>
  ///<para>The coordinated incoming are NDC and the colors are normalized
  ///RGB values. In other words, all values are inside [1, -1].</para>
  ///</remarks>
  public static void rasterizeTrapezoid(Vector3 tlV, Vector3 trV, Vector3 blV, Vector3 brV,
                                        Vector3 tlC, Vector3 trC, Vector3 blC, Vector3 brC,
                                        int w, int h, int[] frameBuffer, int[] zBuffer) {

//    System.out.println("rasterizeTrapezoid()");
//    System.out.println("tlV = " + tlV + ", " +
//                       "trV = " + trV + ", " +
//                       "blV = " + blV + ", " +
//                       "brV = " + brV + ", " +
//                       "w = " + w + ", " +
//                       "h = " + h);

    // Compute integer position values for all vertex locations.
    // y0 -- Top should have equal y-coordinates.
    final int y0 = (int)((2 * (-tlV.y + 1) * (h - 2)) + 2) >> 2;
    //final int y0 = (int)(PX_SCALE * ((tlV.y + 1) * (h - 2)) + 0.5) >> 1;
    // y1 -- Bottom should have equal y-coordinates.
    final int y1 = (int)((2 * (-blV.y + 1) * (h - 2)) + 2) >> 2;
    //final int y1 = (int)(PX_SCALE * ((blV.y + 1) * (h - 2)) + 0.5) >> 1;
    // Check infintely thin trapezoid.
    final int ySteps = y1 - y0;
//    System.out.println("y0 = " + y0 + ", " +
//                       "y1 = " + y1 + ", " +
//                       "ySteps = " + ySteps);
    if (0 == ySteps) {
      return;
    }
    // tl
    final int tlVx = (int)(PX_SCALE * (((tlV.x + 1) * (w - 2)) + 1)) >> 1;
    final int tlVz = (int)(PX_SCALE * tlV.z);
    // tr
    final int trVx = (int)(PX_SCALE * (((trV.x + 1) * (w - 2)) + 1)) >> 1;
    final int trVz = (int)(PX_SCALE * trV.z);
    // bl
    final int blVx = (int)(PX_SCALE * (((blV.x + 1) * (w - 2)) + 1)) >> 1;
    final int blVz = (int)(PX_SCALE * blV.z);
    // br
    final int brVx = (int)(PX_SCALE * (((brV.x + 1) * (w - 2)) + 1)) >> 1;
    final int brVz = (int)(PX_SCALE * brV.z);
//    System.out.println("tlVx = " + (tlVx >> PX_SCALE_SHIFT) + ", " +
//                       "tlVz = " + (tlVz >> PX_SCALE_SHIFT) + ", " +
//                       "trVx = " + (trVx >> PX_SCALE_SHIFT) + ", " +
//                       "trVz = " + (trVz >> PX_SCALE_SHIFT) + ", " +
//                       "blVx = " + (blVx >> PX_SCALE_SHIFT) + ", " +
//                       "blVz = " + (blVz >> PX_SCALE_SHIFT) + ", " +
//                       "brVx = " + (brVx >> PX_SCALE_SHIFT) + ", " +
//                       "brVz = " + (brVz >> PX_SCALE_SHIFT));

    // Compute integer color values for all vertex locations.
    // tl
    final int tlCr = (int)(COLOR_SCALE * tlC.x * 255.0);
    final int tlCg = (int)(COLOR_SCALE * tlC.y * 255.0);
    final int tlCb = (int)(COLOR_SCALE * tlC.z * 255.0);
    // tr
    final int trCr = (int)(COLOR_SCALE * trC.x * 255.0);
    final int trCg = (int)(COLOR_SCALE * trC.y * 255.0);
    final int trCb = (int)(COLOR_SCALE * trC.z * 255.0);
    // bl
    final int blCr = (int)(COLOR_SCALE * blC.x * 255.0);
    final int blCg = (int)(COLOR_SCALE * blC.y * 255.0);
    final int blCb = (int)(COLOR_SCALE * blC.z * 255.0);
    // br
    final int brCr = (int)(COLOR_SCALE * brC.x * 255.0);
    final int brCg = (int)(COLOR_SCALE * brC.y * 255.0);
    final int brCb = (int)(COLOR_SCALE * brC.z * 255.0);

    // Compute interpolation steps for L edge.
    final int xStepL = (blVx - tlVx) / ySteps;
    final int zStepL = (blVz - tlVz) / ySteps;
    final int rStepL = (blCr - tlCr) / ySteps;
    final int gStepL = (blCg - tlCg) / ySteps;
    final int bStepL = (blCb - tlCb) / ySteps;
    // Compute interpolation steps for R edge.
    final int xStepR = (brVx - trVx) / ySteps;
    final int zStepR = (brVz - trVz) / ySteps;
    final int rStepR = (brCr - trCr) / ySteps;
    final int gStepR = (brCg - trCg) / ySteps;
    final int bStepR = (brCb - trCb) / ySteps;
    // Initialize all interpolation values.
    int x0 = tlVx; int x1 = trVx;
    int z0 = tlVz; int z1 = trVz;
    int r0 = tlCr; int r1 = trCr;
    int g0 = tlCg; int g1 = trCg;
    int b0 = tlCb; int b1 = trCb;
    int pxIdxY = y0 * w;
    for (int y = y0; y < y1; ++y, pxIdxY += w,
         // Update L, R interpolation edges.
         x0 += xStepL, x1 += xStepR,
         z0 += zStepL, z1 += zStepR,
         r0 += rStepL, r1 += rStepR,
         g0 += gStepL, g1 += gStepR,
         b0 += bStepL, b1 += bStepR) {
      // Compute L, R edge bounds. When scanline has no width, we still want
      // to render 1 pixel or else our triangles will not have sharp points.
      final int xs0 = (x0 + PX_SCALE_HALF) >> PX_SCALE_SHIFT;
      final int xs1 = (x1 + PX_SCALE_HALF) >> PX_SCALE_SHIFT;
      final int xSteps = xs1 - xs0;
      if (0 == xSteps) {
        continue;
      }
      // Compute steps for this scanline.
      final int zStep = (z1 - z0) / xSteps;
      final int rStep = (r1 - r0) / xSteps;
      final int gStep = (g1 - g0) / xSteps;
      final int bStep = (b1 - b0) / xSteps;
      int z = z0;
      int rScaled = r0 + COLOR_SCALE_HALF;
      int gScaled = g0 + COLOR_SCALE_HALF;
      int bScaled = b0 + COLOR_SCALE_HALF;
      // Run across this scanline and set framebuffer when z is closer.
      int pxIdx = pxIdxY + xs0;
//      System.out.println("y = " + y + ", " +
//                         "xs0 = " + xs0 + ", " +
//                         "xs1 = " + xs1);
      for (int x = xs0; x <= xs1; ++x, ++pxIdx,
           z += zStep,
           rScaled += rStep,
           gScaled += gStep,
           bScaled += bStep) {
        // TODO(reissb) -- Try bitmask technique rather than conditional branch.
        if (z < zBuffer[pxIdx]) {
          zBuffer[pxIdx] = z;
          // Gamma correction.
          final int rp = (int)(Math.sqrt((rScaled >> COLOR_SCALE_SHIFT) & 255) * SQRT_255);
          final int gp = (int)(Math.sqrt((gScaled >> COLOR_SCALE_SHIFT) & 255) * SQRT_255);
          final int bp = (int)(Math.sqrt((bScaled >> COLOR_SCALE_SHIFT) & 255) * SQRT_255);
          frameBuffer[pxIdx] =       255  << 24 | // No alpha.
                               (rp & 255) << 16 |
                               (gp & 255) <<  8 |
                               (bp & 255)       ;
        }
      }
    }
  }
}
