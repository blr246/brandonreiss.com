/*
 * Hw07a.java
 *
 * Ray tracing with reflections.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
import com.brandonreiss.math.*;
import com.brandonreiss.geometry.*;
import com.brandonreiss.util.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Hw08 extends BufferedApplet implements KeyListener {

  ///<summary>Ambient light intensity.</summary>
  private Vector3 iA = new Vector3(0.07, 0.07, 0.07);

  private Renderer renderer = new Renderer();
  ///<summary>View matrix (WORLD ==> CAMERA).</summary>
  private Matrix4x4 viewMat = renderer.viewMat;
  ///<summary>View matrix inverse (CAMERA ==> WORLD).</summary>
  private Matrix4x4 viewMatInv = renderer.viewMatInv;
  ///<summary>Projection matrix (CAMERA ==> CLIP).</summary>
  private Matrix4x4 projMat = renderer.projMat;

  // Scene elements.
  private Light[] lights = new Light[0];
  private Geometry[] shapes = new Geometry[0];
  private Dummy[] shapeControllers = new Dummy[0];
  private SceneGraph scene = new SceneGraph();
  private int[] zBuffer = new int[0];

  // Keyboard handlers.
  public void keyPressed(KeyEvent e) { }
  public void keyReleased(KeyEvent e) { }
  public void keyTyped(KeyEvent e) {
    final char c = e.getKeyChar();
    switch (c) {
      default:
        break;
    }
  }

  public Hw08() {
    addKeyListener(this);
    // Geometry and materials.
    shapes = new Geometry[ShapeId.count()];
    shapeControllers = new Dummy[ShapeId.count()];
    for (int i = 0; i < shapeControllers.length; ++i) {
      shapeControllers[i] = new Dummy();
    }
    // Simple sphere mesh.
    {
      int idx = ShapeId.SPHERE.idx();
      Geometry g = Geometry.newSphere(3, 3, 3);
      Material m = g.newMaterial();
      m.kA.set(0.2, 0.6, 0.2);
      m.kD.set(0.2, 0.6, 0.2);
      m.kS.set(0.2, 0.6, 0.2);
      m.alphaS = 2.0;
      shapes[idx] = g;
      // Model.
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }
    // Setup vertices for simple triangle render.
    {
      final int verticesLength = vertices.length;
      vertexProjColor = new Vector3[verticesLength * 2];
      for (int i = 0; i < verticesLength; ++i) {
        vertexProjColor[2 * i] = new Vector3();
        vertexProjColor[(2 * i) + 1] = vertexColors[i];
      }
    }
  }

  ///<summary>Compute Phong shading at surface point V.</summary>
  public void phongShade(Vector3 V, Vector3 N, Material m,
                         Light[] lights, Vector3 iA,
                         ArrayPool.Vector3 vector3Pool, Vector3 color) {

    // Allocate from pooled memory.
    final int VECTOR3_ALLOC_COUNT = 6;
    Vector3 viewDir, diffuse, specular, lightDir, reflectDir, iTmp;
    {
      int poolIdx = vector3Pool.alloc(VECTOR3_ALLOC_COUNT);
      Vector3[] pool = vector3Pool.get();
      viewDir = pool[poolIdx++].zero();
      diffuse = pool[poolIdx++].zero();
      specular = pool[poolIdx++].zero();
      lightDir = pool[poolIdx++];
      reflectDir = pool[poolIdx++];
      iTmp = pool[poolIdx++];
    }
    // Camera is at the origin, so we are viewing along the direction
    // to the point.
    viewDir.set(V).normalize();

    // Compute diffuse, specular color.
    for (Light l : lights) {
      final double lightDistSq = l.getDirectionAtPoint(V, lightDir);
      // Light is visible?
      final double lightDirDotN = lightDir.dot(N);
      if (lightDirDotN > 0) {
        // Diffuse part.
        l.getIntensity(V, lightDir, iTmp);
        iTmp.mul(lightDirDotN).mul(m.kD);
        diffuse.add(iTmp);
        // Specular part.
        reflectDir.set(N).mul(lightDirDotN).mul(2).sub(lightDir);
        final double reflectDirDotV = -reflectDir.dot(viewDir);
        if (reflectDirDotV > 0) {
          final double specularAttenuation = Math.pow(reflectDirDotV, m.alphaS);
          l.getIntensity(V, lightDir, iTmp);
          iTmp.mul(specularAttenuation).mul(m.kS);
          specular.add(iTmp);
        }
      }
    }
    // Compute final color.
    color.set(iA).mul(m.kA);
    color.add(specular);
    color.add(diffuse);
    color.clip(0, 1);

    // Return pooled variables.
    vector3Pool.free(VECTOR3_ALLOC_COUNT);
  }

  // Rendering variables.
  private Vector3 bgColor = new Vector3(0.25, 0.25, 1);

  Random randGen = new Random(System.currentTimeMillis());

  // Interpolation types.
  public enum Interpolation { None, BlerpBox, BlerpCross, }

  ///<summary>Convert from packed RGBA pixel to RGB vector.</summary>
  public void unpackRgb(int c, Vector3 v) {
    v.x = (double)unpack(c, 0) / 255.0;
    v.y = (double)unpack(c, 1) / 255.0;
    v.z = (double)unpack(c, 2) / 255.0;
  }

  ///<summary>Convenient shape index manager.</summary>
  public enum ShapeId {
    SPHERE(),
    ;

    private int idx;
    ShapeId() { this.idx = Count.next(); }
    public int idx() { return idx; }
    public static int count() { return Count.count; }
    private static class Count {
      private static int count = 0;
      public static int next() { return count++; }
    }
  }

  ///<summary>Initialization after applet is setup.</summary>
  public void initialize() {
  }

  ///<summary>Perform animation updates.</summary>
  public void animate(double t) {
    // Setup camera matrix.
    {
      viewMatInv.identity();
      viewMatInv.rotateZ(t * 1.1092);
      viewMatInv.rotateY(t * 1.5073);
      viewMatInv.translate(0, 0, 5);
    }
    // Compute view matrix.
    viewMat.set(viewMatInv).inverse();
//    // Setup projection.
//    final double aspect = (double)width / (double)height;
//    projMat.projectionFovH(Math.PI * 0.3, aspect, 0.5, 10.0);

    scene.updateTransform();
  }

  double fpsInterval = 3.0;
  double fpsTimerBegin = 0;
  int fpsCounter = 0;
  double fpsLastInterval = 0;

  // Simple triangle.
  Vector3[] vertices = new Vector3[] {new Vector3(0.0, 1.0, 0.0),                // Top-middle
                                      new Vector3(-Math.cos(Math.PI / 6),
                                                  -Math.sin(Math.PI / 6), 0.0),  // Bottom-left
                                      new Vector3( Math.cos(Math.PI / 6),
                                                  -Math.sin(Math.PI / 6), 0.0)}; // Bottom-right
  // Simple colors.
  Vector3[] vertexColors = new Vector3[] {new Vector3( 1.0, 0.0, 0.0),  // Red
                                          new Vector3( 0.0, 1.0, 0.0),  // Green
                                          new Vector3( 0.0, 0.0, 1.0)}; // Blue
  // Projected vertices.
  Vector3[] vertexProjColor = new Vector3[0];
  double focalLength = 1 / Math.tan(Math.PI * 0.1);
  // Temporaries for rasterizing.
  Vector3 vTmp = new Vector3();
  Vector3 cTmp = new Vector3();

  ///<summary>Render the scene.</summary>
  public void computeImage(double t, int[] pixels) {
    final int pixelsLength = pixels.length;
    if (zBuffer.length != pixelsLength) {
      zBuffer = new int[pixels.length];
    }
    // Clear zBuffer.
    Arrays.fill(zBuffer, Integer.MAX_VALUE);
    Arrays.fill(pixels, pack(0, 0, 0));

    // Project vertices.
    final double aspect = (double)width / (double)height;
    final int verticesLength = vertices.length;
    for (int i = 0; i < verticesLength; ++i) {
      Vector3 vProj = vertexProjColor[2 * i];
      vProj.set(vertices[i]).mul(viewMat);
      final double zInv = 1.0 / vProj.z;
      vProj.x *= -focalLength * zInv;
      vProj.y *= -focalLength * aspect * zInv;
      vProj.z = 1.0 / vProj.z;
    }

    // Render triangles.
    Raster.rasterizeTriangles(vertexProjColor, vTmp, cTmp, width, height, pixels, zBuffer);

    ++fpsCounter;
    final double tElapsed = t - fpsTimerBegin;
    if (tElapsed > fpsInterval) {
      fpsLastInterval = fpsCounter / tElapsed;
      fpsTimerBegin = t;
      fpsCounter = 0;
    }
  }
}

