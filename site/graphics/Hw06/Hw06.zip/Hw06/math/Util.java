/*
 * Util.java
 *
 * Math utilities.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.math;

import com.brandonreiss.math.*;

public class Util {
  ///<summaryGet the distance from the point to the plane.</summary>
  ///<remarks>
  ///<para> A positive distance indicates that the point is above the
  ///plane while a negative one indicates that it is below.
  ///</para>
  ///</remarks>
  public static double pointPlaneDistance(Vector3 pt, Vector4 plane) {
    return pt.dot(plane) + plane.w;
  }

  ///<summaryProject the point to the given plane.</summary>
  public static Vector3 pointProjectPlane(Vector3 pt, Vector4 plane) {
    final double d = -pointPlaneDistance(pt, plane);
    pt.x += plane.x * d; pt.y += plane.y * d; pt.z += plane.z * d;
    return pt;
  }

  ///<summaryProject the point to the given plane.</summary>
  public static Vector3 pointProjectPlane(Vector3 pt, Vector4 plane, Vector3 res) {
    return pointProjectPlane(res.set(pt), plane);
  }

  ///<summaryProject a point to a plane along the given direction.</summary>
  public static Vector3 pointProjectPlaneAlongDir(Vector3 pt, Vector4 plane, Vector3 dir) {
    final double nDotDir = dir.dot(plane);
    if (0 != Math.abs(nDotDir)) {
      // Get parametric step along light direction to plane.
      final double t = -pointPlaneDistance(pt, plane) / nDotDir;
      if (t > 0) {
        // Add distance along light ray to projection.
        pt.x += dir.x * t; pt.y += dir.y * t; pt.z += dir.z * t;
      }
      return pt;
    }
    else {
      // Direction is parallel to the plane.
      return pt;
    }
  }
}

