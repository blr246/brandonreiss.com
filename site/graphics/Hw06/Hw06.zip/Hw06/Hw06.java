/*
 * Hw06.java
 *
 * Ray tracing with reflections.
*/
import com.brandonreiss.math.*;
import java.awt.*;
import java.awt.image.*;
import java.util.Vector;
import java.util.Stack;
import java.util.concurrent.*;

public class Hw06 extends BufferedApplet {

  ///<summary>Memory for empty Ray pool.</summary>
  private Stack<Ray> emptyRayPool = new Stack<Ray>();
  ///<summary>Create an empty Ray from a pool.</summary>
  private Ray createEmptyRayPooled() {
    if (!emptyRayPool.empty()) {
      return emptyRayPool.pop();
    }
    else {
      return Ray.createEmpty();
    }
  }
  ///<summary>Release a Ray to a pool.</summary>
  private void releaseEmptyRayPooled(Ray r) {
    r.pt = null;
    r.dir = null;
    emptyRayPool.push(r);
  }

  ///<summary>Memory for Vector3 pool.</summary>
  private Stack<Vector3> vector3Pool = new Stack<Vector3>();
  ///<summary>Create a Vector3 from a pool.</summary>
  private Vector3 createVector3Pooled() {
    if (!vector3Pool.empty()) {
      return vector3Pool.pop();
    }
    else {
      return new Vector3();
    }
  }
  ///<summary>Release a Vector3 to a pool.</summary>
  private void releaseVector3Pooled(Vector3 v) {
    vector3Pool.push(v);
  }


  public abstract class Shape {
    public boolean castShadows = true;
    public abstract double intersect(Ray in);
    public abstract void computeNormal(Vector3 pt, Vector3 N); 
  }

  ///<summary>Simple sphere shape for raytracing.</summary>
  private class Sphere extends Shape {
    public double r = 1.0;
    public Vector3 c = Vector3.vectorZero();
    public boolean castShadows;

    public double intersect(Ray in) {
      // Formula for ray-sphere intersection studied from:
      //   http://www.cs.unc.edu/~rademach/xroads-RT/RTarticle.html
      final double rptToCX = c.x - in.pt.x;
      final double rptToCY = c.y - in.pt.y;
      final double rptToCZ = c.z - in.pt.z;
      final double v = (in.dir.x * rptToCX) +
                       (in.dir.y * rptToCY) +
                       (in.dir.z * rptToCZ);
      final double rptToCLengthSq = (rptToCX * rptToCX) +
                                    (rptToCY * rptToCY) +
                                    (rptToCZ * rptToCZ);
      final double disc = (r * r) - (rptToCLengthSq - (v * v));
      if (disc < 0) {
        return -1;
      }
      else {
        return v - Math.sqrt(disc);
      }
    }
    public void computeNormal(Vector3 pt, Vector3 N) {
      N.set(pt).sub(c).normalize();
    }
  }

  ///<summary>Simple plane shape for raytracing.</summary>
  private class Plane extends Shape {
    public Vector4 plane = new Vector4(0, 0, 1, 0);

    public double intersect(Ray in) {
      final double nDotDir = in.dir.dot(plane);
      // Make sure not parallel.
      if (0 != Math.abs(nDotDir)) {
        return -Util.pointPlaneDistance(in.pt, plane) / nDotDir;
      }
      else {
        return -1;
      }
    }
    public void computeNormal(Vector3 pt, Vector3 N) {
      N.set(plane);
    }
  }

  ///<summary>A light used during shading.</summary>
  public interface Light {
    double getDirectionAtPoint(Vector3 p, Vector3 dir);
    void getIntensity(Vector3 p, Vector3 dir, Vector3 iPt);
  }

  ///<summary>A simulated light.</summary>
  public class PointLight implements Light {
    public Vector3 position = Vector3.vectorZero();
    public Vector3 i = new Vector3(1, 1, 1);

    public double getDirectionAtPoint(Vector3 p, Vector3 dir) {
      dir.set(position).sub(p);
      final double lightDistSq = dir.lengthSq();
      dir.normalize();
      return lightDistSq;
    }
    public void getIntensity(Vector3 p, Vector3 dir, Vector3 iPt) {
      iPt.set(i);
    }
  }

  ///<summary>A simulated light.</summary>
  public class DirectionalLight implements Light {
    public Vector3 direction = Vector3.vectorZero();
    public Vector3 i = new Vector3(1, 1, 1);

    public double getDirectionAtPoint(Vector3 p, Vector3 dir) {
      dir.set(direction);
      return 1.0e6;
    }
    public void getIntensity(Vector3 p, Vector3 dir, Vector3 iPt) {
      iPt.set(i);
    }
  }

  ///<summary>A simulated light.</summary>
  public class SpotLight implements Light {
    public Vector3 position = Vector3.vectorZero();
    public Vector3 direction = Vector3.vectorZero();
    public double exp = 1.0;
    public Vector3 i = new Vector3(1, 1, 1);

    public double getDirectionAtPoint(Vector3 p, Vector3 dir) {
      dir.set(position).sub(p);
      final double lightDistSq = dir.lengthSq();
      dir.normalize();
      return lightDistSq;
    }
    public void getIntensity(Vector3 p, Vector3 dir, Vector3 iPt) {
      final double attenuation = Math.pow(dir.dot(direction), exp);
      if (attenuation > 0) {
        iPt.set(i).mul(attenuation);
      }
      else {
        iPt.zero();
      }
    }
  }

  ///<summary>Ambient light intensity.</summary>
  private Vector3 iA = new Vector3(0.01, 0.01, 0.01);

  ///<summary>Phong shading material.</summary>
  private class Material {
    ///<summary>Ambient constants.</summary>
    public Vector3 kA = new Vector3(1, 1, 1);
    ///<summary>Diffuse constants.</summary>
    public Vector3 kD = new Vector3(1, 1, 1);
    ///<summary>Specular constants.</summary>
    public Vector3 kS = new Vector3(1, 1, 1);
    ///<summary>Specular exponent.</summary>
    public double alphaS;
    ///<summary>Reflection coefficient.</summary>
    public double reflectivity = 0;
  }

  ///<summary>View matrix (WORLD ==> CAMERA).</summary>
  private Matrix4x4 viewMat = Matrix4x4.CreateMatrixIdentity();
  ///<summary>View matrix inverse (CAMERA ==> WORLD).</summary>
  private Matrix4x4 viewMatInv = Matrix4x4.CreateMatrixIdentity();
  ///<summary>Projection matrix (CAMERA ==> NDC).</summary>
  private Matrix4x4 projMat = Matrix4x4.CreateMatrixIdentity();
  ///<summary>Projection matrix inverse (NDC ==> CAMERA).</summary>
  private Matrix4x4 projMatInv = Matrix4x4.CreateMatrixIdentity();

  // Scene elements.
  private Light[] lights = null;
  private Shape[] shapes = null;
  private Material[] materials = null;

  final int[] ROOM_BOX_EXTENTS = new int[] { 15, 16, 8, };

  // Concurrency objects.
  private int numProcessors = 0;
  private Vector<RaytraceTask> tasks = null;

  public Hw06() {
    // Setup tasks.
    {
      // reissb -- 20120405 -- Parallel implementation is not faster? We do
      //   not use it for now.
      numProcessors = 1;
      tasks = new Vector<RaytraceTask>(numProcessors);
      for (int i = 0; i < numProcessors; ++i) {
        tasks.add(new RaytraceTask());
      }
    }
    // Geometry and materials.
    final int numShapes = 8;
    shapes = new Shape[numShapes];
    materials = new Material[numShapes];
    int shapeIdx = 0;
    {
      Material m = new Material();
      m.kA.set(0.8, 0.8, 0.8);
      m.kD.set(0.7, 0.7, 0.7);
      m.kS.set(0.1, 0.1, 0.1);
      m.alphaS = 1.0;
      m.reflectivity = 0;
      {
        Plane p = new Plane();
        // Floor.
        p.plane.set(0, 0, 1, 0);
        p.castShadows = false;
        shapes[shapeIdx] = p;
        materials[shapeIdx] = m;
      }
      ++shapeIdx;
      {
        Plane p = new Plane();
        // Ceiling.
        p.plane.set(0, 0,-1, ROOM_BOX_EXTENTS[2] * 2);
        p.castShadows = false;
        shapes[shapeIdx] = p;
        materials[shapeIdx] = m;
      }
      ++shapeIdx;
      {
        Plane p = new Plane();
        // Wall +X.
        p.plane.set(-1, 0, 0, ROOM_BOX_EXTENTS[0]);
        p.castShadows = false;
        shapes[shapeIdx] = p;
        materials[shapeIdx] = m;
      }
      ++shapeIdx;
      {
        Plane p = new Plane();
        // Wall -X.
        p.plane.set( 1, 0, 0, ROOM_BOX_EXTENTS[0]);
        p.castShadows = false;
        shapes[shapeIdx] = p;
        materials[shapeIdx] = m;
      }
      ++shapeIdx;
      {
        Plane p = new Plane();
        // Wall -Y.
        p.plane.set( 0, 1, 0, ROOM_BOX_EXTENTS[1]);
        p.castShadows = false;
        shapes[shapeIdx] = p;
        materials[shapeIdx] = m;
      }
      ++shapeIdx;
    }
    {
      Sphere s = new Sphere();
      s.c.set(0, 0, 2.5);
      Material m = new Material();
      m.kA.set(1.0, 0.8, 0.4);
      m.kD.set(0.6, 0.4, 0.2);
      m.kS.set(0.7, 0.5, 0.25);
      m.alphaS = 3.0;
      m.reflectivity = 0.15;

      shapes[shapeIdx] = s;
      materials[shapeIdx] = m;
    }
    ++shapeIdx;
    {
      Sphere s = new Sphere();
      s.c.set(-2.5, 0, 2.5);
      Material m = new Material();
      m.kA.set(0.5, 0.5, 0.5);
      m.kD.set(0.5, 0.5, 0.5);
      m.kS.set(0.8, 0.8, 0.8);
      m.alphaS = 5.0;
      m.reflectivity = 0;

      shapes[shapeIdx] = s;
      materials[shapeIdx] = m;
    }
    ++shapeIdx;
    {
      Sphere s = new Sphere();
      s.c.set( 2.5, 0, 2.5);
      Material m = new Material();
      m.kA.set(0.3, 0.3, 1.0);
      m.kD.set(0.4, 0.4, 0.9);
      m.kS.set(0.8, 0.8, 0.8);
      m.alphaS = 50.0;
      m.reflectivity = 0.03;

      shapes[shapeIdx] = s;
      materials[shapeIdx] = m;
    }
    ++shapeIdx;

    // Setup camera matrix.
    {
      viewMatInv.identity();
      viewMatInv.translate(0,-14, 4);
      viewMatInv.rotateX(Math.PI * 0.45);
    }
    viewMat.set(viewMatInv).inverse();

    // Lights.
    lights = new Light[6];
    int lightIdx = 0;
    // Keys.
    {
      {
        SpotLight l = new SpotLight();
        l.position.set(-4,-2, 10);
        l.direction.set(0,-2, 10).normalize();
        l.exp = 30.0;
        l.i.set(0.7, 0.7, 0.7);
        lights[lightIdx++] = l;
      }
      {
        SpotLight l = new SpotLight();
        l.position.set( 0,-2, 10);
        l.direction.set(0,-2, 10).normalize();
        l.exp = 30.0;
        l.i.set(0.7, 0.7, 0.7);
        lights[lightIdx++] = l;
      }
      {
        SpotLight l = new SpotLight();
        l.position.set( 4,-2, 10);
        l.direction.set(0,-2, 10).normalize();
        l.exp = 30.0;
        l.i.set(0.7, 0.7, 0.7);
        lights[lightIdx++] = l;
      }
    }
    // Fill.
    {
      PointLight l = new PointLight();
      l.position.set( 0,-32, 7);
      l.i.set(0.3, 0.3, 0.3);
      lights[lightIdx++] = l;
    }
    // Back.
    {
      PointLight l = new PointLight();
      l.position.set( 16, 64, 0.0);
      l.i.set(0.5, 0, 0);
      lights[lightIdx++] = l;
    }
    // Back.
    {
      PointLight l = new PointLight();
      l.position.set(-16, 64, 0.0);
      l.i.set(0.5, 0.5, 0);
      lights[lightIdx++] = l;
    }
  }

  ///<summary>Project a ray from the camera into the scene.</summary>
  private Ray projectRay(int w, int h, int x, int y, Ray ray) {
    final double halfScreenX = (double)w / 2.0;
    final double halfScreenY = (double)h / 2.0;
    final double ptNdcX =  ((double)x - halfScreenX) / halfScreenX;
    final double ptNdcY = -((double)y - halfScreenY) / halfScreenY;
    // Initialize ray direction to far clip plane projection.
    ray.dir.set(ptNdcX, ptNdcY, 1);
    ray.dir.transformCoord(projMatInv);
    ray.dir.transformCoord(viewMatInv);
    // Set camera position and then subtract from far clip to get direction.
    ray.pt.set(viewMatInv.m[0][3], viewMatInv.m[1][3], viewMatInv.m[2][3]);
    ray.dir.sub(ray.pt).normalize();
    return ray;
  }

  ///<summary>Helper test ray intersection.</summary>
  private class IntersectionTester {
    public void run(Ray ray) {
      d = Double.POSITIVE_INFINITY;
      closestIdx = -1;
      final int shapesLength = shapes.length;
      for (int i = 0; i < shapesLength; ++i) {
        Shape s = shapes[i];
        if (shadowTest && !s.castShadows) {
          continue;
        }
        final double d_s = s.intersect(ray);
        if ((d_s >= 0) && (d_s < d)) {
          d = d_s;
          closestIdx = i;
        }
      }
    }
    public boolean shadowTest = false;
    public int closestIdx = -1;
    public double d = Double.POSITIVE_INFINITY;
  }

  private final int MAX_BOUNCE = 5;
  private final double BOUNCE_EPSILON = 1.0e-6;

  ///<summary>Compute Phong shading at surface point p.</summary>
  private void phongShade(int depth, Shape shape, Material m,
                          Vector3 iA, Light[] lights,
                          IntersectionTester intersectionTester,
                          Vector3 p, Vector3 v, Vector3 N,
                          Vector3 color) {
    assert(depth < MAX_BOUNCE);

    // Allocate from pooled memory.
    Vector3 diffuse = createVector3Pooled().zero();
    Vector3 specular = createVector3Pooled().zero();
    Vector3 lightDir = createVector3Pooled();
    Vector3 reflectDir = createVector3Pooled();
    Vector3 reflectColor = createVector3Pooled().zero();
    Vector3 iTmp = createVector3Pooled();
    Ray shadowRay = createEmptyRayPooled();
    shadowRay.pt = iTmp;
    shadowRay.dir = lightDir;

    // Ambient color.
    color.set(iA).mul(m.kA);
    // Compute diffuse, specular color.
    for (Light l : lights) {
      // Shadow ray test.
      final double lightDistSq = l.getDirectionAtPoint(p, lightDir);
      // Setup iTmp for shadow ray.
      iTmp.set(lightDir).mul(BOUNCE_EPSILON).add(p);
      intersectionTester.shadowTest = true;
      intersectionTester.run(shadowRay);
      final int closestIdx = intersectionTester.closestIdx;
      final double d = intersectionTester.d;
      if ((closestIdx >= 0) && ((d * d) < (lightDistSq))) {
        continue;
      }
      // Light is visible?
      final double lightDirDotN = lightDir.dot(N);
      if (lightDirDotN > 0) {
        // Diffuse part.
        l.getIntensity(p, lightDir, iTmp);
        iTmp.mul(lightDirDotN).mul(m.kD);
        diffuse.add(iTmp);
        // Specular part.
        reflectDir.set(N).mul(lightDirDotN).mul(2).sub(lightDir);
        final double reflectDirDotV = -reflectDir.dot(v);
        if (reflectDirDotV > 0) {
          final double specularAttenuation = Math.pow(reflectDirDotV, m.alphaS);
          l.getIntensity(p, lightDir, iTmp);
          iTmp.mul(specularAttenuation).mul(m.kS);
          specular.add(iTmp);
        }
      }
    }
    // Spawn reflection ray with slight epsilon offset.
    if (m.reflectivity > 0) {
      Ray rayReflect = createEmptyRayPooled();
      reflectDir.set(N).mul(-v.dot(N)).mul(2).add(v);
      // Move by small epsilon away from surface.
      p.x += reflectDir.x * BOUNCE_EPSILON;
      p.y += reflectDir.y * BOUNCE_EPSILON;
      p.z += reflectDir.z * BOUNCE_EPSILON;
      rayReflect.pt = p;
      rayReflect.dir = reflectDir;
      traceRay(depth + 1, rayReflect, intersectionTester, reflectColor);
      color.add(reflectColor.mul(m.reflectivity));
      releaseEmptyRayPooled(rayReflect);
    }
    color.add(specular);
    color.add(diffuse);

    // Return pooled variables.
    releaseVector3Pooled(diffuse);
    releaseVector3Pooled(specular);
    releaseVector3Pooled(lightDir);
    releaseVector3Pooled(reflectDir);
    releaseVector3Pooled(reflectColor);
    releaseVector3Pooled(iTmp);
    releaseEmptyRayPooled(shadowRay);
  }

  ///<summary>Recursive function to perform ray tests.</summary>
  private void traceRay(int depth, Ray ray,
                        IntersectionTester intersectionTester, Vector3 color) {
    color.zero();
    if (depth >= MAX_BOUNCE) {
      return;
    }
    // Find intersection to closest shape.
    intersectionTester.shadowTest = false;
    intersectionTester.run(ray);
    final int closestIdx = intersectionTester.closestIdx;
    final double d = intersectionTester.d;
    // If nothing intersects, then the color either background or null.
    if (closestIdx < 0) {
      if (0 == depth) {
        color.set(bgColor);
      }
      return;
    }
    Vector3 point = createVector3Pooled();
    Vector3 normal = createVector3Pooled();
    {
      // Phong shade the intersected shape.
      Shape s = shapes[closestIdx];
      Material m = materials[closestIdx];
      point.set(ray.dir).mul(d).add(ray.pt);
      s.computeNormal(point, normal);
      phongShade(depth, s, m, iA, lights,
                 intersectionTester, point, ray.dir, normal, color);
    }
    releaseVector3Pooled(point);
    releaseVector3Pooled(normal);
  }

  // Rendering variables.
  private Vector3 bgColor = new Vector3(1, 1, 1);
  private int scanIdx = 0;
  private int wLast = 0;
  private int hLast = 0;
  WritableRaster wr = null;
  int w = 0;
  int h = 0;

  ///<summary>A raytracting task.</summary>
  class RaytraceTask implements Callable<Integer> {
    // Rendering variables.
    public int yStart = 0;
    public int yEnd = 0;
    private Ray rayProject = Ray.createZero();
    private Vector3 pxColor = Vector3.vectorZero();
    private int[] intColor = new int[3];
    private IntersectionTester intersectionTester = new IntersectionTester();

    public Integer call() {
      for (int y = yStart; (y < yEnd) && (y < h); ++y) {
        for (int  x = 0; x < w; ++x) {
          // Get 3d ray in the scene.
          projectRay(w, h, x, y, rayProject);
          traceRay(0, rayProject, intersectionTester, pxColor);
          // Gamma compression.
          intColor[0] = Math.max(0, Math.min(255, (int)(Math.sqrt(pxColor.x) * 255)));
          intColor[1] = Math.max(0, Math.min(255, (int)(Math.sqrt(pxColor.y) * 255)));
          intColor[2] = Math.max(0, Math.min(255, (int)(Math.sqrt(pxColor.z) * 255)));
          wr.setPixel(x, y, intColor);
        }
      }
      return yEnd;
    }
  }

  ///<summary>Render the raytraced scene.</summary>
  public void render(Graphics g) {
    w = getWidth();
    h = getHeight();
    if ((w != wLast) || (h != hLast)) {
      scanIdx = 0;
      wLast = w;
      hLast = h;
      // Setup projection matrix.
      final double aspect = (double)w / (double)h;
      projMat.projectionFovH(Math.PI * 0.2, aspect, 1.0, 10.0);
      projMatInv.set(projMat).inverse();
    }
    // Done rendering?
    if (h <= scanIdx) {
      dontSleep = false;
      return;
    }
    wr = image.getRaster();
    // reissb -- 20120405 -- For some reason, the parallel implementation is
    //   both slower to render and also causes strange artifacts where the
    //   computed pixel color is not black but the one displayed is.
    // Single threaded.
    tasks.get(0).yStart = scanIdx;
    tasks.get(0).yEnd = scanIdx + 1;
    ++scanIdx;
    tasks.get(0).call();

    dontSleep = true;
  }
}

