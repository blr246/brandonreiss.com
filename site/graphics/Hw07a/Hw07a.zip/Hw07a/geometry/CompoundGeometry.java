/*
 * CompoundGeometry.java
 *
 * Boolean geometry.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.geometry;

import com.brandonreiss.math.*;
import com.brandonreiss.util.*;
import java.util.ArrayList;

public class CompoundGeometry extends GeometryBase {
  GeometryBase shapeA = null;
  GeometryBase shapeB = null;
  Operation operation = Operation.UNION;
  public static boolean debugPrint = false;

  public CompoundGeometry() {}

  public CompoundGeometry(GeometryBase shapeA_, GeometryBase shapeB_, Operation operation_) {
    setShapeA(shapeA_);
    setShapeB(shapeB_);
    setOperation(operation_);
  }

  public void setShapeA(GeometryBase shapeA_) {
    shapeA = shapeA_;
    shapeA.setParent(this);
  }

  public void setShapeB(GeometryBase shapeB_) {
    shapeB = shapeB_;
    shapeB.setParent(this);
  }

  public void setOperation(Operation operation_) {
    operation = operation_;
  }

  public void setup(GeometryBase shapeA_, GeometryBase shapeB_, Operation operation_) {
    setShapeA(shapeA_);
    setShapeB(shapeB_);
    setOperation(operation_);
  }

  public enum Operation {
    UNION, INTERSECTION, SUBTRACTION,
  }

  public int intersectRay(Ray ray,
                          int offsetOut,
                          ArrayPtr.Double intervalOut,
                          ArrayPtr.Vector3 pointOut,
                          ArrayPtr.Vector3 normalOut,
                          int offsetTmp,
                          ArrayPtr.Double intervalTmp,
                          ArrayPtr.Vector3 pointTmp,
                          ArrayPtr.Vector3 normalTmp) {
    // Shared variable 'hits' for hitting single shape.
    int hits = -1;
    switch (operation) {
      case UNION:
        {
          // ~(~A ^ ~B)
          final int hitsA = shapeA.intersectRay(ray, offsetTmp,
                                                     intervalTmp, pointTmp, normalTmp,
                                                     offsetOut,
                                                     intervalOut, pointOut, normalOut);
          final int offsetB = (hitsA <= 0) ? 0 : hitsA;
          final int hitsB = shapeB.intersectRay(ray, offsetTmp + offsetB,
                                                     intervalTmp, pointTmp, normalTmp,
                                                     offsetOut,
                                                     intervalOut, pointOut, normalOut);
          // Missed both?
          final boolean missedBoth = (hitsA < 0) && (hitsB < 0);
          if (missedBoth)
          {
            return -1;
          }
          // Enumerate possibilities (hit both, hit one, inside both).
          final int state = ((hitsA > 0) ? 2 : 0) + ((hitsB > 0) ? 1 : 0);
          if (debugPrint) {
            System.out.println("hitsA = " + hitsA + ", " +
                               "hitsB = " + hitsB + ", " +
                               "offsetB = " + offsetB + ", " +
                               "state = " + state);
          }
          switch (state) {
            case 3:
              // Hit both. Invert both.
              {
                double[] interval = intervalTmp.get();
                int endIdx = offsetTmp + hitsA + hitsB;
                for (int i = offsetOut; i < endIdx; ++i) {
                  interval[i] = -interval[i];
                }
              }
              final int hitsComplement = intersect(offsetOut,
                                                   intervalOut, pointOut, normalOut,
                                                   offsetTmp, hitsA,
                                                   intervalTmp, pointTmp, normalTmp,
                                                   offsetTmp + hitsA, hitsB,
                                                   intervalTmp, pointTmp, normalTmp);
              if (debugPrint) {
                System.out.println("hitsComplement = " + hitsComplement);
              }
              // If the complement is hit, invert it back and return.
              if (hitsComplement > 0) {
                double[] interval = intervalOut.get();
                int endIdx = offsetOut + hitsComplement;
                for (int i = offsetOut; i < endIdx; ++i) {
                  interval[i] = -interval[i];
                }
              }
              return hitsComplement;
            case 2:
            case 1:
              // Hits shapeA only or shapeB only.
              hits = (2 == state) ? hitsA : hitsB;
            case 0:
            default: break;
          }
        }
        break;
      case INTERSECTION:
        {
          // (A ^ B)
          final int hitsA = shapeA.intersectRay(ray, offsetTmp,
                                                     intervalTmp, pointTmp, normalTmp,
                                                     offsetOut,
                                                     intervalOut, pointOut, normalOut);
          final int offsetB = (hitsA <= 0) ? 0 : hitsA;
          final int hitsB = shapeB.intersectRay(ray, offsetTmp + offsetB,
                                                     intervalTmp, pointTmp, normalTmp,
                                                     offsetOut,
                                                     intervalOut, pointOut, normalOut);
          // Missed one?
          final boolean missedOne = (hitsA < 0) || (hitsB < 0);
          if (missedOne)
          {
            return -1;
          }
          else {
          // Hit both.
          return intersect(offsetOut,
                           intervalOut, pointOut, normalOut,
                           offsetTmp, hitsA,
                           intervalTmp, pointTmp, normalTmp,
                           offsetTmp + hitsA, hitsB,
                           intervalTmp, pointTmp, normalTmp);
          }
        }
      case SUBTRACTION:
        {
          // (A ^ ~B)
          final int hitsA = shapeA.intersectRay(ray, offsetTmp,
                                                     intervalTmp, pointTmp, normalTmp,
                                                     offsetOut,
                                                     intervalOut, pointOut, normalOut);
          final int offsetB = (hitsA <= 0) ? 0 : hitsA;
          final int hitsB = shapeB.intersectRay(ray, offsetTmp + offsetB,
                                                     intervalTmp, pointTmp, normalTmp,
                                                     offsetOut,
                                                     intervalOut, pointOut, normalOut);
          // Not hit A or inside of B?
          final boolean missed = (hitsA < 0) || (0 == hitsB);
          if (missed)
          {
            return -1;
          }
          // Enumerate possibilities (hit A only, hit both).
          final int state = (hitsB > 0) ? 1 : 0;
          if (debugPrint) {
            System.out.println("hitsA = " + hitsA + ", " +
                               "hitsB = " + hitsB + ", " +
                               "offsetB = " + offsetB + ", " +
                               "state = " + state);
          }
          switch (state) {
            case 1:
              // Hit both. Invert B.
              {
                double[] interval = intervalTmp.get();
                int endIdx = offsetTmp + hitsA + hitsB;
                for (int i = offsetB; i < endIdx; ++i) {
                  interval[i] = -interval[i];
                }
              }
              return intersect(offsetOut,
                               intervalOut, pointOut, normalOut,
                               offsetTmp, hitsA,
                               intervalTmp, pointTmp, normalTmp,
                               offsetTmp + hitsA, hitsB,
                               intervalTmp, pointTmp, normalTmp);
            case 0:
              // Hit A only, use A.
              hits = hitsA;
            default: break;
          }
        }
        break;
      default: break;
    }
    // Hit single shape?
    System.arraycopy(intervalTmp.get(), offsetTmp, intervalOut.get(), offsetOut, hits);
    final int dstEndIdx = offsetOut + hits;
    pointOut.grow(dstEndIdx);
    normalOut.grow(dstEndIdx);
    Vector3[] pointSrc = pointTmp.get();
    Vector3[] pointDst = pointOut.get();
    Vector3[] normalSrc = normalTmp.get();
    Vector3[] normalDst = normalOut.get();
    Vector3 tmp;
    for (int srcIdx = offsetTmp, dstIdx = offsetOut;
         dstIdx < dstEndIdx;
         ++srcIdx, ++dstIdx) {
      // Swap the pointers.
      tmp = pointDst[srcIdx];  pointDst[srcIdx]  = pointSrc[dstIdx];  pointSrc[dstIdx]  = tmp;
      tmp = normalDst[srcIdx]; normalDst[srcIdx] = normalSrc[dstIdx]; normalSrc[dstIdx] = tmp;
    }
    return hits;
  }
}

