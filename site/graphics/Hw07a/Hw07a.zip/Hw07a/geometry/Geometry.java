/*
 * Geometry.java
 *
 * First and second order surfaces with a material.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.geometry;

import com.brandonreiss.math.*;
import com.brandonreiss.util.*;
import java.util.ArrayList;
import java.util.Arrays;

public class Geometry extends GeometryBase {
  ArrayList<GeometryBase> baseShapes = new ArrayList<GeometryBase>();
  public static boolean debugPrint = false;

  ///<summary>Intersect a ray with this shape.</summary>
  public int intersectRay(Ray ray,
                          int offsetOut,
                          ArrayPtr.Double intervalOut,
                          ArrayPtr.Vector3 pointOut,
                          ArrayPtr.Vector3 normalOut,
                          int offsetTmp,
                          ArrayPtr.Double intervalTmp,
                          ArrayPtr.Vector3 pointTmp,
                          ArrayPtr.Vector3 normalTmp) {

    // Loop all base shapes and merge.
    int sizeMerge = 0;
    final int baseShapesSize = baseShapes.size();
    for (int hsIdx = 0; hsIdx < baseShapesSize; ++hsIdx) {
      GeometryBase h = baseShapes.get(hsIdx);
      final int offTmpGap = offsetTmp + sizeMerge;
      final int offTmpOut = offsetOut + sizeMerge;
      final int numHits = h.intersectRay(ray, offTmpGap, intervalTmp, pointTmp, normalTmp,
                                              offTmpOut, intervalOut, pointOut, normalOut);
      if (debugPrint) {
        System.out.println("offsetOut = " + offsetOut + ", " +
                           "offsetTmp = " + offsetTmp + ", " +
                           "offTmpGap = " + offTmpGap + ", " +
                           "offTmpGap = " + offTmpOut + ", " +
                           "numHits = " + numHits);
      }
      // When outside always, nothing to do; when inside always, ignore.
      if (numHits < 0) {
        return -1;
      }
      else if (0 == numHits) {
        continue;
      }
      // Grow interval output array and gather pointers.
      final int sizeOutMax = offsetOut + numHits;
      intervalOut.grow(sizeOutMax);
      pointOut.grow(sizeOutMax);
      normalOut.grow(sizeOutMax);
      Vector3[] pointM = pointOut.get();
      Vector3[] pointT = pointTmp.get();
      Vector3[] normalM = normalOut.get();
      Vector3[] normalT = normalTmp.get();
      if (debugPrint) {
        System.out.println("sizeMerge = " + sizeMerge + ", " +
                           "numHits = " + numHits + ", " +
                           "sizeOutMax = " + sizeOutMax);
      }
      // If this is the first time, just copy the temporary list.
      if (0 == sizeMerge) {
        // Perform copying.
        System.arraycopy(intervalTmp.get(), offTmpGap, intervalOut.get(), offsetOut, numHits);
        final int dstIdxEnd = sizeOutMax;
        if (debugPrint) {
          System.out.println("srcIdx = " + offTmpGap + ", " +
                             "dstIdx = " + offsetOut + ", " +
                             "dstIdxEnd = " + dstIdxEnd);
        }
        // Swap the pointers.
        Vector3 tmp;
        for (int srcIdx = offTmpGap, dstIdx = offsetOut; dstIdx < dstIdxEnd; ++srcIdx, ++dstIdx) {
          tmp = pointM[dstIdx];  pointM[dstIdx]  = pointT[srcIdx];  pointT[srcIdx]  = tmp;
          tmp = normalM[dstIdx]; normalM[dstIdx] = normalT[srcIdx]; normalT[srcIdx] = tmp;
        }
        sizeMerge = numHits;
      }
      else {
        // Merge interval lists using concatenated array
        //   | ************* | **** | <=> intervalTmp
        //   ^- Merged head  ^- Next shape head
        // and merging to the output list.
        System.arraycopy(intervalOut.get(), offsetOut, intervalTmp.get(), offsetTmp, sizeMerge);
        final int dstIdxEnd = offsetTmp + sizeMerge;
        if (debugPrint) {
          System.out.println("srcIdx = " + offsetOut + ", " +
                             "dstIdx = " + offsetTmp + ", " +
                             "dstIdxEnd = " + dstIdxEnd);
        }
        // Swap the pointers.
        Vector3 tmp;
        for (int srcIdx = offsetOut, dstIdx = offsetTmp; dstIdx < dstIdxEnd; ++srcIdx, ++dstIdx) {
          tmp = pointT[dstIdx];  pointT[dstIdx]  = pointM[srcIdx];  pointM[srcIdx]  = tmp;
          tmp = normalT[dstIdx]; normalT[dstIdx] = normalM[srcIdx]; normalM[srcIdx] = tmp;
        }
        sizeMerge = intersect(offsetOut, intervalOut, pointOut, normalOut,
                              offsetTmp, sizeMerge, intervalTmp, pointTmp, normalTmp,
                              dstIdxEnd, numHits, intervalTmp, pointTmp, normalTmp);
      }
      if (debugPrint) {
        System.out.println("sizeMerge = " + sizeMerge);
      }
      // If we have no merged intersections, then we missed.
      if (0 == sizeMerge) {
        return -1;
      }
    }
    return sizeMerge;
  }

  public class Plane extends GeometryBase {
    private Vector4 plane = new Vector4(0, 0, 1, 0);
    private Vector4 planeTform = new Vector4();
    private Matrix4x4 transformInvT = new Matrix4x4();

    public void onTransformUpdated() {
      //planeTform.set(plane).transformNormal(transform).normalize();
      transformInvT.set(transform).inverse().transpose();
      planeTform.set(plane).mul(transformInvT);
      double normalLengthSq  = (planeTform.x * planeTform.x) +
                               (planeTform.y * planeTform.y) +
                               (planeTform.z * planeTform.z);
      planeTform.mul(1.0 / Math.sqrt(normalLengthSq));
    }
    
    public int intersectRay(Ray ray,
                            int offsetOut,
                            ArrayPtr.Double intervalOut,
                            ArrayPtr.Vector3 pointOut,
                            ArrayPtr.Vector3 normalOut,
                            int offsetTmp,
                            ArrayPtr.Double intervalTmp,
                            ArrayPtr.Vector3 pointTmp,
                            ArrayPtr.Vector3 normalTmp) {
      if (debugPrint) {
        System.out.println("Plane::intersectRay()");
      }
      // Grow arrays.
      final int numRoots = 1;
      final int maxPtIdx = offsetOut + numRoots;
      intervalOut.grow(maxPtIdx);
      pointOut.grow(maxPtIdx);
      normalOut.grow(maxPtIdx);
      double[] interval = intervalOut.get();
      Vector3[] point = pointOut.get();
      Vector3[] normal = normalOut.get();
      // Get ray-plane distance. Positive interval is entering the suface.
      double ptDotPlane  = planeTform.dot(ray.pt);
      double dirDotPlane = planeTform.dot(ray.dir);
      double dist = ptDotPlane + planeTform.w;
      // Initialize return for no intersection.
      boolean inside = dist < 0;
      int noIntersectionRes = inside ? 0 : -1;
      // Are we not facing the plane and not inside?
      if ((dirDotPlane >= 0) && !inside) {
        return noIntersectionRes;
      }
      double t = -dist / dirDotPlane;
      // Are we not hitting the plane?
      if (t < 0) {
        return noIntersectionRes;
      }
      int sign = inside ? -1 : 1;
      interval[offsetOut] = sign * t;
      // Save point, normal only for reachable hit.
      point[offsetOut].set(ray.dir).mul(Math.abs(interval[offsetOut])).add(ray.pt);
      normal[offsetOut].set(planeTform);
      return 1;
    }
  }

  public class Quadratic extends GeometryBase {
    private Matrix4x4 transformInv = new Matrix4x4();
    private Matrix4x4 q = Matrix4x4.createMatrixIdentity();
    private Matrix4x4 qTform = new Matrix4x4();
    private Matrix4x4 qTform_p = new Matrix4x4();

    public Quadratic(double a, double b, double c, double d, double e,
                     double f, double g, double h, double i, double j) {
      // Assign upper-triagular matrix of quadratic coefficients.
      double[][] qm = q.m;
      qm[0][0] = a; qm[0][1] = f; qm[0][2] = e; qm[0][3] = g;
                    qm[1][1] = b; qm[1][2] = d; qm[1][3] = h;
                                  qm[2][2] = c; qm[2][3] = i;
                                                qm[3][3] = j;
    }

    public void onTransformUpdated() {
      transformInv.set(transform).inverse();
      // Setup qTform.
      qTform.set(transformInv).transpose().mul(q).mul(transformInv);
      {
        double[][] m = qTform.m;
        /*        */ m[0][1] *= 2; m[0][2] *= 2; m[0][3] *= 2;
        m[1][0] = 0; /*         */ m[1][2] *= 2; m[1][3] *= 2;
        m[2][0] = 0; m[2][1]  = 0; /*         */ m[2][3] *= 2;
        m[3][0] = 0; m[3][1]  = 0; m[3][2]  = 0; /*         */
      }
      // Setup gradient.
      qTform_p.set(qTform);
      // Scale diagonal.
      qTform_p.m[0][0] *= 2; qTform_p.m[1][1] *= 2; qTform_p.m[2][2] *= 2;
      qTform_p.m[3][3] = 0;
      // Reflect entries.
      qTform_p.m[1][0] = qTform_p.m[0][1];
      qTform_p.m[2][0] = qTform_p.m[0][2];
      qTform_p.m[2][1] = qTform_p.m[1][2];
    }
    
    public int intersectRay(Ray ray,
                            int offsetOut,
                            ArrayPtr.Double intervalOut,
                            ArrayPtr.Vector3 pointOut,
                            ArrayPtr.Vector3 normalOut,
                            int offsetTmp,
                            ArrayPtr.Double intervalTmp,
                            ArrayPtr.Vector3 pointTmp,
                            ArrayPtr.Vector3 normalTmp) {
      if (debugPrint) {
        System.out.println("Quadratic::intersectRay()");
      }
      // Grow arrays.
      final int numRoots = 2;
      final int maxPtIdx = offsetOut + numRoots + 1;
      intervalOut.grow(maxPtIdx);
      pointOut.grow(maxPtIdx);
      normalOut.grow(maxPtIdx);
      double[] interval = intervalOut.get();
      Vector3[] point = pointOut.get();
      Vector3[] normal = normalOut.get();
      // Compute quadratic coefficients.
      double c_1, c_2, c_3;
      double a, b, c, d, e, f, g, h, i, j;
      {
        // Load coefficients.
        double[][] qm = qTform.m;
        a = qm[0][0]; f = qm[0][1]; e = qm[0][2]; g = qm[0][3];
                      b = qm[1][1]; d = qm[1][2]; h = qm[1][3];
                                    c = qm[2][2]; i = qm[2][3];
                                                  j = qm[3][3];
        // t^2((a * d_x^2) + (b * d_y^2) + (c * d_z^2) +
        //     (e * d_x * d_z) + (f * d_y * d_z) + (g * d_x * d_y))
        c_1 = (a * ray.dir.x * ray.dir.x) +
              (b * ray.dir.y * ray.dir.y) +
              (c * ray.dir.z * ray.dir.z) +
              (d * ray.dir.y * ray.dir.z) +
              (e * ray.dir.x * ray.dir.z) +
              (f * ray.dir.x * ray.dir.y);
        // t((a * 2 * p_x * d_x) + (b * 2 * p_y * d_y) + (c * 2 * p_z * d_z) +
        //   (d * ((p_z * d_y) + (p_y * d_z))) +
        //   (e * ((p_x * d_z) + (p_z * d_x))) +
        //   (f * ((p_x * d_y) + (p_y * d_x))) +
        //   (g * d_x) + (h * d_y) + (i * d_z))
        c_2 = (a * 2 * ray.dir.x * ray.pt.x) +
              (b * 2 * ray.dir.y * ray.pt.y) +
              (c * 2 * ray.dir.z * ray.pt.z) +
              (d * ((ray.pt.z * ray.dir.y) + (ray.pt.y * ray.dir.z))) +
              (e * ((ray.pt.x * ray.dir.z) + (ray.pt.z * ray.dir.x))) +
              (f * ((ray.pt.x * ray.dir.y) + (ray.pt.y * ray.dir.x))) +
              (g * ray.dir.x) +
              (h * ray.dir.y) +
              (i * ray.dir.z);
        // Standard point xT Q x multiply.
        // (a * p_x^2) + (b * p_y^2) + (c * p_z^2) +
        // (d * p_y * p_z) + (e * p_x * p_z) + (f * p_x * p_y) +
        // (g * p_x) + (h * p_y) + (i * p_z) + j
        c_3 = normal[offsetOut].set(ray.pt).transform(qTform).dot(ray.pt) + j;
      }
      // Solve quadratic equation.
      // t = (-c_2 +/- sqrt(c_2^2 - (4 * c_1 * c_3))) / (2 * c_1)
      final double discriminant = (c_2 * c_2) - (4 * c_1 * c_3);
      if (debugPrint) {
        System.out.println("c_1 = " + c_1 + ", " +
                           "c_2 = " + c_2 + ", " +
                           "c_3 = " + c_3 + ", " +
                           "discriminant = " + discriminant);
      }
      // Check no intersection possible.
      if (discriminant < 0) {
        return -1;
      }
      final int halfSpaceRes = (c_3 <= 0) ? 0 : -1;
      if (0 == c_1) {
        return halfSpaceRes;
      }
      final double twoC1 = (2 * c_1);
      final double offset = Math.sqrt(discriminant) / twoC1;
      final double negC2DivTwoC1 = -c_2 / twoC1;
      final double t_enter = negC2DivTwoC1 - offset;
      final double t_exit  = negC2DivTwoC1 + offset;
      if (debugPrint) {
        System.out.println("t_enter = " + t_enter + ", " +
                           "t_exit = " + t_exit);
      }
      // Either outside and hit twice or inside and hit once.
      final double sign = (c_3 < 0) ? -1 : 1;
      final int state = ((t_enter > 0) ? 2 : 0) + ((t_exit > 0) ? 1 : 0);
      // Set points, intervals, normals.
      int ptIdx = offsetOut;
      switch (state) {
        case 3:
          interval[ptIdx] =  sign * t_enter;
          point[ptIdx].set(ray.dir).mul(t_enter).add(ray.pt);
          normal[ptIdx].set(point[ptIdx]).transform(qTform_p).normalize();
          ++ptIdx;
        case 2:
        case 1:
          final double signInvert = (1 == state) ? -1 : 1;
          interval[ptIdx] = signInvert * -sign * t_exit;
          point[ptIdx].set(ray.dir).mul(t_exit).add(ray.pt);
          normal[ptIdx].set(point[ptIdx]).transform(qTform_p).normalize();
          ++ptIdx;
          break;
        case 0: // Ray not in proper direction; use half space calculation.
        default: return halfSpaceRes;
      }
      return ptIdx;
    }
  }
  
  public Plane addPlane() {
    Plane p = new Plane();
    baseShapes.add(p);
    p.setParent(this);
    return p;
  }

  public Quadratic addQuadratic(double a, double b, double c, double d, double e,
                                double f, double g, double h, double i, double j) {
    Quadratic q = new Quadratic(a, b, c, d, e, f, g, h, i, j);
    baseShapes.add(q);
    q.setParent(this);
    return q;
  }

  /*
   * Static creation methods.
   */

  ///<summary>Create a new infinte plane.</summary>
  public static Geometry newPlane() {
    Geometry g = new Geometry();
    g.addPlane();
    return g;
  }

  ///<summary>Create a new unit cube.</summary>
  public static Geometry newCube() {
    Geometry g = new Geometry();
    // X
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.rotateY( Math.PI * 0.5);
      p.transformLocal.translate(0, 0, 1);
    }
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.rotateY(-Math.PI * 0.5);
      p.transformLocal.translate(0, 0, 1);
    }
    // Y
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.rotateX( Math.PI * 0.5);
      p.transformLocal.translate(0, 0, 1);
    }
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.rotateX(-Math.PI * 0.5);
      p.transformLocal.translate(0, 0, 1);
    }
    // Z
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.translate(0, 0, 1);
    }
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.rotateY(Math.PI);
      p.transformLocal.translate(0, 0, 1);
    }
    return g;
  }

  ///<summary>Create a new unit sphere.</summary>
  public static Geometry newSphere() {
    Geometry g = new Geometry();
    g.addQuadratic(1, 1, 1, 0, 0, 0, 0, 0, 0,-1);
    return g;
  }

  ///<summary>Create a new unit cylinder.</summary>
  public static Geometry newCylinder() {
    Geometry g = new Geometry();
    int hsIdx = 0;
    {
      g.addQuadratic(1, 1, 0, 0, 0, 0, 0, 0, 0,-1);
    }
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.translate(0, 0, 1);
    }
    {
      Geometry.Plane p = g.addPlane();
      p.transformLocal.rotateY(Math.PI);
      p.transformLocal.translate(0, 0, 1);
    }
    return g;
  }
}

