/*
 * GeometryBase.java
 *
 * Basic shape interface.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.geometry;

import com.brandonreiss.math.*;
import com.brandonreiss.util.*;
import java.util.Arrays;

public abstract class GeometryBase extends SceneObject {
  Material material = null;
  static boolean debugPrint = false;

  public Material newMaterial() {
    material = new Material();
    return material;
  }

  public Material getMaterial() {
    return material;
  }

  public Material getMaterialFallbackDefault() {
    return (null == material) ? Material.defaultMaterial : material;
  }

  public void setMaterial(Material material_) {
    material = material_;
  }

  ///<summary>Intersect a ray with this shape.</summary>
  public abstract int intersectRay(Ray ray,
                                   int offsetOut,
                                   ArrayPtr.Double intervalOut,
                                   ArrayPtr.Vector3 pointOut,
                                   ArrayPtr.Vector3 normalOut,
                                   int offsetTmp,
                                   ArrayPtr.Double intervalTmp,
                                   ArrayPtr.Vector3 pointTmp,
                                   ArrayPtr.Vector3 normalTmp);

  ///<summary>Perform boolean intersection shape Out = A AND B.</summary>
  public static int intersect(int offsetOut,
                              ArrayPtr.Double intervalOut,
                              ArrayPtr.Vector3 pointOut,
                              ArrayPtr.Vector3 normalOut,
                              int offsetAPtr, int sizeA,
                              ArrayPtr.Double intervalAPtr,
                              ArrayPtr.Vector3 pointAPtr,
                              ArrayPtr.Vector3 normalAPtr,
                              int offsetBPtr, int sizeB,
                              ArrayPtr.Double intervalBPtr,
                              ArrayPtr.Vector3 pointBPtr,
                              ArrayPtr.Vector3 normalBPtr) {
    final int sizeOutMax = sizeA + sizeB;
    intervalOut.grow(sizeOutMax);
    pointOut.grow(sizeOutMax);
    normalOut.grow(sizeOutMax);
    double[] intervalM = intervalOut.get();
    double[] intervalA = intervalAPtr.get();
    double[] intervalB = intervalBPtr.get();
    Vector3[] pointM = pointOut.get();
    Vector3[] pointA = pointAPtr.get();
    Vector3[] pointB = pointBPtr.get();
    Vector3[] normalM = normalOut.get();
    Vector3[] normalA = normalAPtr.get();
    Vector3[] normalB = normalBPtr.get();
    Vector3 tmp;
    // Initialize merge head, shape head, output index, and merge state.
    int aIdx = offsetAPtr;
    final int aEnd = offsetAPtr + sizeA;
    int bIdx = offsetBPtr;
    final int bEnd = offsetBPtr + sizeB;
    int oIdx = offsetOut;
    int state = ((aIdx < aEnd) ? 1 : 0) + ((bIdx < bEnd) ? 2 : 0);
    double lastTest = -1;
    while (state > 0) {
      if (debugPrint) {
        System.out.println("*** ITER BEGIN ***");
        System.out.println("state = " + state + ", " +
                           "aIdx = " + aIdx + ", " +
                           "bIdx = " + bIdx);
      }
      switch (state) {
        case 3:
          // See which hit comes next.
          final double tA = intervalA[aIdx];
          final double tB = intervalB[bIdx];
          final boolean equal = Math.abs(tA) == Math.abs(tB);
          final boolean opposite = (tA * tB) < 0;
          if (debugPrint) {
            System.out.println("tA = " + tA + ", " +
                               "tB = " + tB + ", " +
                               "equal = " + equal + ", " +
                               "opposite = " + opposite);
          }
          // Toss both if equal and opposite. This is rare.
          if (equal && opposite) {
            // Increment both lists and update state.
            state = ((++aIdx < aEnd) ? 1 : 0) + ((++bIdx < bEnd) ? 2 : 0);
          }
          else {
            final boolean mergeA = Math.abs(tA) <= Math.abs(tB);
            if (debugPrint) {
              System.out.println("mergeA = " + mergeA);
            }
            if (mergeA) {
              // Append when this is "in" and other is "in" or when
              // this is "out" and other is "in" or when equal.
              final boolean append = ((tA >= 0) && (tB < 0)) ||
                                     ((tA <  0) && (tB < 0)) || equal;
              lastTest = intervalA[aIdx];
              // Copy interval, point, normal.
              if (append) {
                intervalM[oIdx] = lastTest;
                tmp = pointM[oIdx];  pointM[oIdx]  = pointA[aIdx];  pointA[aIdx]  = tmp;
                tmp = normalM[oIdx]; normalM[oIdx] = normalA[aIdx]; normalA[aIdx] = tmp;
                ++oIdx;
              }
              // Increment list and update state.
              if (equal) {
                state = ((++aIdx < aEnd) ? 1 : 0) + ((++bIdx < bEnd) ? 2 : 0);
              }
              else {
                state -= (++aIdx < aEnd) ? 0 : 1;
              }
            }
            else {
              // Append when this is "in" and other is "in" or when
              // this is "out" and other is "in".
              final boolean append = ((tB >= 0) && (tA < 0)) ||
                                     ((tB <  0) && (tA < 0));
              lastTest = intervalB[bIdx];
              // Copy interval, point, normal.
              if (append) {
                intervalM[oIdx] = lastTest;
                tmp = pointM[oIdx];  pointM[oIdx]  = pointB[bIdx];  pointB[bIdx]  = tmp;
                tmp = normalM[oIdx]; normalM[oIdx] = normalB[bIdx]; normalB[bIdx] = tmp;
                ++oIdx;
              }
              // Increment list and update state.
              state -= (++bIdx < bEnd) ? 0 : 2;
            }
            if (debugPrint) {
              System.out.println("oIdx = " + oIdx + ", " +
                                 "lastTest = " + lastTest);
            }
          }
          break;
        case 2:
        case 1:
          // See if there is a final point to add.
          final boolean inLast = (lastTest >= 0);
          final boolean stateA = (1 == state);
          int idxTest = stateA ? aIdx : bIdx;
          double[] interval = stateA ? intervalA : intervalB;
          final boolean entering = interval[idxTest] >= 0;
          if (debugPrint) {
            System.out.println("lastTest = " + lastTest + ", " +
                               "inLast = " + inLast + ", " +
                               "idxTest = " + idxTest + ", " +
                               "entering = " + entering);
          }
          if (inLast) {
            // Copy interval, point, normal.
            final int idxEnd = stateA ? aEnd : bEnd;
            Vector3[] point = stateA ? pointA : pointB;
            Vector3[] normal = stateA ? normalA : normalB;
            for (; idxTest < idxEnd; ++idxTest) {
              intervalM[oIdx] = interval[idxTest];
              tmp = pointM[oIdx];  pointM[oIdx]  = point[idxTest];  point[idxTest]  = tmp;
              tmp = normalM[oIdx]; normalM[oIdx] = normal[idxTest]; normal[idxTest] = tmp;
              ++oIdx;
            }
          }
          // No more merging.
          state = 0;
          break;
        case 0:
        default: break;
      }
      if (debugPrint) {
        System.out.println("offsetOut = " + offsetOut + ", " +
                           "oIdx = " + oIdx);
        System.out.println("intervalOut[] = " + Arrays.toString(intervalOut.get()));
        System.out.println("*** ITER END ***");
      }
    }
    final int sizeOut = oIdx - offsetOut;
    return sizeOut;
  }
}

