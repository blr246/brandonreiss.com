/*
 * RayTester.java
 *
 * Test ray-shape intersection using pre-allocated memory.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.geometry;

import com.brandonreiss.math.*;
import com.brandonreiss.util.*;

///<summary>Helper to test ray intersection.</summary>
public class RayTester {
  public ArrayPtr.Double[] intervals = null;
  public ArrayPtr.Vector3[] points = null;
  public ArrayPtr.Vector3[] normals = null;
  public int hitIdx = -1;
  public int hits = -1;

  public RayTester() {
    intervals = new ArrayPtr.Double[0];
    points = new ArrayPtr.Vector3[0];
    normals = new ArrayPtr.Vector3[0];
  }

  ///<summary>Grow data storage arrays used for intersection testing.</summary>
  private void growArrays(int length) {
    // Resize arrays for number of shapes.
    final int shapesLengthOld = intervals.length;
    if (shapesLengthOld < length) {
      ArrayPtr.Double[] newIntervals = new ArrayPtr.Double[length];
      ArrayPtr.Vector3[] newPoints = new ArrayPtr.Vector3[length];
      ArrayPtr.Vector3[] newNormals = new ArrayPtr.Vector3[length];
      System.arraycopy(intervals, 0, newIntervals, 0, shapesLengthOld);
      System.arraycopy(points, 0, newPoints, 0, shapesLengthOld);
      System.arraycopy(normals, 0, newNormals, 0, shapesLengthOld);
      intervals = newIntervals;
      points = newPoints;
      normals = newNormals;
      for (int i = shapesLengthOld; i < length; ++i) {
        intervals[i] = new ArrayPtr.Double();
        points[i] = new ArrayPtr.Vector3();
        normals[i] = new ArrayPtr.Vector3();
      }
    }
  }

  ///<summary>Run intersection test with all geometry.</summary>
  public void run(Ray ray, GeometryBase[] shapes) {
    final int sl = shapes.length;
    growArrays(sl + 1);
    // Find closest shape to ray.
    double d = Double.POSITIVE_INFINITY;
    hitIdx = -1;
    hits = -1;
    for (int i = 0; i < sl; ++i) {
      GeometryBase s = shapes[i];
      final int sHits = s.intersectRay(ray,
                                       0, intervals[i],  points[i],  normals[i],
                                       0, intervals[sl], points[sl], normals[sl]);
      if ((sHits > 0) && (intervals[i].get()[0] < d)) {
        hitIdx = i;
        d = intervals[i].get()[0];
        hits = sHits;
      }
    }
  }

  ///<summary>Run intersection test with a specific shape.</summary>
  public void run(Ray ray, GeometryBase g) {
    growArrays(2);
    hitIdx = 0;
    hits = g.intersectRay(ray, 0, intervals[0], points[0], normals[0],
                               0, intervals[1], points[1], normals[1]);
  }
}

