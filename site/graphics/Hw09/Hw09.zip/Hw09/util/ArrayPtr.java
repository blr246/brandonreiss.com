/*
 * ArrayPtr.java
 *
 * An array pointer. Can be grown from within a function.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.util;

public class ArrayPtr {
  /*
  public static class ARRAY_T {
    private ARRAY_T[] arr = null;

    public ARRAY_T() {
      arr = new PACKAGE.ARRAY_T[0];
    }

    public ARRAY_T(int length) {
      arr = new PACKAGE.ARRAY_T[length];
    }

    public ARRAY_T(PACKAGE.ARRAY_T[] arr_) {
      arr = arr_;
    }

    public PACKAGE.ARRAY_T[] get() {
      return arr;
    }

    public PACKAGE.ARRAY_T[] grow(int length) {
      if (length > arr.length) {
        PACKAGE.ARRAY_T[] newArr = new PACKAGE.ARRAY_T[length];
        final int numCopy = Math.min(length, arr.length);
        System.arraycopy(arr, 0, newArr, 0, numCopy);
        arr = newArr;
      }
      return arr;
    }
  }
  */

  public static class Double {
    private double[] arr = null;

    public Double() {
      arr = new double[0];
    }

    public Double(int length) {
      arr = new double[length];
    }

    public Double(double[] arr_) {
      arr = arr_;
    }

    public double[] get() {
      return arr;
    }

    public double[] grow(int length) {
      if (length > arr.length) {
        double[] newArr = new double[length];
        final int numCopy = Math.min(length, arr.length);
        System.arraycopy(arr, 0, newArr, 0, numCopy);
        arr = newArr;
      }
      return arr;
    }
  }

  public static class Vector3 {
    private com.brandonreiss.math.Vector3[] arr = null;

    public Vector3() {
      arr = new com.brandonreiss.math.Vector3[0];
    }

    public Vector3(int length) {
      arr = new com.brandonreiss.math.Vector3[length];
    }

    public Vector3(com.brandonreiss.math.Vector3[] arr_) {
      arr = arr_;
    }

    public com.brandonreiss.math.Vector3[] get() {
      return arr;
    }

    public com.brandonreiss.math.Vector3[] grow(int length) {
      if (length > arr.length) {
        com.brandonreiss.math.Vector3[] newArr = new com.brandonreiss.math.Vector3[length];
        final int numCopy = Math.min(length, arr.length);
        System.arraycopy(arr, 0, newArr, 0, numCopy);
        arr = newArr;
        for (int i = numCopy; i < length; ++i) {
          arr[i] = new com.brandonreiss.math.Vector3();
        }
      }
      return arr;
    }
  }

  public static class Ray {
    private com.brandonreiss.math.Ray[] arr = null;

    public Ray() {
      arr = new com.brandonreiss.math.Ray[0];
    }

    public Ray(int length) {
      arr = new com.brandonreiss.math.Ray[length];
    }

    public Ray(com.brandonreiss.math.Ray[] arr_) {
      arr = arr_;
    }

    public com.brandonreiss.math.Ray[] get() {
      return arr;
    }

    public com.brandonreiss.math.Ray[] grow(int length) {
      if (length > arr.length) {
        com.brandonreiss.math.Ray[] newArr = new com.brandonreiss.math.Ray[length];
        final int numCopy = Math.min(length, arr.length);
        System.arraycopy(arr, 0, newArr, 0, numCopy);
        arr = newArr;
      }
      return arr;
    }
  }
}

