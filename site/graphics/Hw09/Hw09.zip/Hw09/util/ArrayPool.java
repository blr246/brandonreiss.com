/*
 * ArrayPool.java
 *
 * A simple memory pool.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.util;

import com.brandonreiss.math.*;

///<summary>A simple pool container using an array.</summary>
///<remarks>
///<para>This class is not threadsafe.</para>
///</remarks>
public class ArrayPool {
  /*
  public static class POOL_T extends ArrayPtr.POOL_T {
    private int curAllocIdx = 0;

    public int alloc(int length) {
      final int oldLength = get().length;
      final int newLength = curAllocIdx + length;
      grow(newLength);
      for (int i = oldLength; i < newLength; ++i) {
        get()[i] = new PACKAGE.POOL_T();
      }
      final int allocIdx = curAllocIdx;
      curAllocIdx = newLength;
      return allocIdx;
    }

    public void free(int length) {
      curAllocIdx -= length;
    }
  }
  */

  public static class Vector3 extends ArrayPtr.Vector3 {
    private int curAllocIdx = 0;

    public int alloc(int length) {
      final int oldLength = get().length;
      final int newLength = curAllocIdx + length;
      grow(newLength);
      for (int i = oldLength; i < newLength; ++i) {
        get()[i] = new com.brandonreiss.math.Vector3();
      }
      final int allocIdx = curAllocIdx;
      curAllocIdx = newLength;
      return allocIdx;
    }

    public void free(int length) {
      curAllocIdx -= length;
    }
  }

  public static class Ray extends ArrayPtr.Ray {
    private int curAllocIdx = 0;

    public int alloc(int length) {
      final int oldLength = get().length;
      final int newLength = curAllocIdx + length;
      grow(newLength);
      for (int i = oldLength; i < newLength; ++i) {
        get()[i] = com.brandonreiss.math.Ray.createEmpty();
      }
      final int allocIdx = curAllocIdx;
      curAllocIdx = newLength;
      return allocIdx;
    }

    public void free(int length) {
      curAllocIdx -= length;
    }
  }
}

