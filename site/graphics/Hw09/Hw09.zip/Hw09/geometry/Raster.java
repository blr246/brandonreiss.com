package com.brandonreiss.geometry;

import com.brandonreiss.math.*;
import com.brandonreiss.util.*;

public class Raster {

  public static class Interpolants {
    // Red.
    double r, drDx, drDy;
    // Green.
    double g, dgDx, dgDy;
    // Blue.
    double b, dbDx, dbDy;
    // Z.
    double z, dzDx, dzDy;

    public void init(int x0, int y0, int x1, int y1, int x2, int y2,
                     double z0, double z1, double z2,
                     double prestepX, double prestepY,
                     Vector3 c0, Vector3 c1, Vector3 c2) {
      final double sign = (x2 < x0) ? -1 : 1;
      final double dy = (double)(((x0 - x1) * (y1 - y2)) - ((x1 - x2) * (y0 - y1)));
      final double dx = sign * dy;
      // Compute gradients for red.
      drDx = (((c1.x - c2.x) * (y0 - y1)) - ((c1.x - c0.x) * (y1 - y2))) / dx;
      drDy = (((c1.x - c2.x) * (x0 - x1)) - ((c1.x - c0.x) * (x1 - x2))) / dy;
      r = c0.x;// + (prestepY * drDy) + (prestepX * drDx);
      // Compute gradients for green.
      dgDx = (((c1.y - c2.y) * (y0 - y1)) - ((c1.y - c0.y) * (y1 - y2))) / dx;
      dgDy = (((c1.y - c2.y) * (x0 - x1)) - ((c1.y - c0.y) * (x1 - x2))) / dy;
      g = c0.y;// + (prestepY * dgDy) + (prestepX * dgDx);
      // Compute gradients for blue.
      dbDx = (((c1.z - c2.z) * (y0 - y1)) - ((c1.z - c0.z) * (y1 - y2))) / dx;
      dbDy = (((c1.z - c2.z) * (x0 - x1)) - ((c1.z - c0.z) * (x1 - x2))) / dy;
      b = c0.z;// + (prestepY * dbDy) + (prestepX * dbDx);
      // Compute gradients for z.
      dzDx = (((z1 - z2) * (y0 - y1)) - ((z1 - z0) * (y1 - y2))) / dx;
      dzDy = (((z1 - z2) * (x0 - x1)) - ((z1 - z0) * (x1 - x2))) / dy;
      z = z0;// + (prestepY * dzDy) + (prestepX * dzDx);
//      System.out.println("c0 = " + c0 + ", " +
//                         "dx = " + dx + ", " +
//                         "dy = " + dy + ",\n" +
//                         "drDx = " + drDx + ", " +
//                         "drDy = " + drDy + ",\n" +
//                         "dgDx = " + drDx + ", " +
//                         "dgDy = " + drDy + ",\n" +
//                         "dbDx = " + drDx + ", " +
//                         "dbDy = " + drDy + ",\n" +
//                         "dzDx = " + drDx + ", " +
//                         "dzDy = " + drDy);
    }

    public void step(int xSteps) {
      // Step red.
      r += drDy;
      r += drDx * xSteps;
      // Step green.
      g += dgDy;
      g += dgDx * xSteps;
      // Step blue.
      b += dbDy;
      b += dbDx * xSteps;
      // Step z.
      z += dzDy;
      z += dzDx * xSteps;
    }
  }

  final static double kViewEps = 0.0001;

  ///<summary>Raster edge data structure.</summary>
  ///<remarks>
  ///<para>When splitting triangles into trapezoids, this class simplifies the
  ///otherwise tedious problem of rasterizing continually through the top and
  ///bottom triangle parts.</para>
  ///</remarks>
  public static class Edge {
    Vector3 v0, v1;
    double prestepY, prestepX;
    // Y.
    int y0, y1, y, height;
    // X.
    int x0, x1, x, width, ddaErrorTerm, xStep, ddaNumerator, ddaDenominator;

    public void init(Vector3 t, Vector3 b, int w, int h) {
      v0 = t;
      v1 = b;

      // Setup y values.
      final double y0Raw = ((1.0 + t.y) * (h - kViewEps)) / 2.0;
      final double y1Raw = ((1.0 + b.y) * (h - kViewEps)) / 2.0;
      y0 = (int)y0Raw;
      y1 = (int)y1Raw;
      y = y0;
      prestepY = (double)y - y0Raw;
      ddaDenominator = height = y1 - y0;
      assert height >= 0 : "invalid height = " + height + ", y0 = " + y0 + ", y1 = " + y1;

      if (0 == height) {
        y0 = y1 = y = 0;
        prestepY = 0;
        height = 0;
        prestepX = 0;
        x0 = x1 = x = 0; width = 0;
        ddaErrorTerm = 0; xStep = 0; ddaNumerator = 0; ddaDenominator = 1;
        return;
      }

//      System.out.println("y0Raw = " + y0Raw + ", " +
//                         "y1Raw = " + y1Raw + ", " +
//                         "prestepY = " + prestepY + ",\n" +
//                         "y0 = " + y0 + ", " +
//                         "y1 = " + y1 + ", " +
//                         "height = " + height);

      // Setup x values.
      final double x0Raw = ((t.x + 1.0) * (w - kViewEps)) / 2.0;
      final double x1Raw = ((b.x + 1.0) * (w - kViewEps)) / 2.0;
      x0 = (int)x0Raw;
      x1 = (int)x1Raw;
      width = x1 - x0;
      x = x0;
      prestepX = (double)x - x0Raw;
      ddaErrorTerm = 0;
      {
        final long fd = floorDiv(width, ddaDenominator);
        xStep = (int)(fd >> 32);
        ddaNumerator = (int)fd & 0xFFFF;
      }

//      System.out.println("x0Raw = " + x0Raw + ", " +
//                         "x1Raw = " + x1Raw + ",\n" +
//                         "x0 = " + x0 + ", " +
//                         "x1 = " + x1 + ", " +
//                         "width = " + width + ", " +
//                         "x = " + x + ",\n" +
//                         "xStep = " + xStep + ", " +
//                         "ddaErrorTerm = " + ddaErrorTerm + ", " +
//                         "ddaNumerator = " + ddaNumerator);

      assert width == (height * xStep) +
                      ((height * ddaNumerator) / ddaDenominator) :
                      "width = " + width + " != " +
                      "(height * xStep) {" + (height * xStep) + "} +\n" +
                      "((height * ddaNumerator) / ddaDenominator) {" +
                      ((height * ddaNumerator) / ddaDenominator) + "}";
      assert x1 == (x + (height * xStep) +
                        ((ddaErrorTerm + (height * ddaNumerator)) / ddaDenominator));
    }

    public int step() {
      ++y;
      --height;
      x += xStep;
      width -= xStep;
      ddaErrorTerm += ddaNumerator;
      if (ddaErrorTerm >= ddaDenominator) {
        ddaErrorTerm -= ddaDenominator;
        ++x;
        --width;
        return xStep + 1;
      }
      return xStep;
    }
  }

  // Static storage for edges.
  private static Edge[] edges = new Edge[] { new Edge(), new Edge(), new Edge(), };
//  private static Interpolants interpolants = new Interpolants();

  ///<summary>Takes a list of triangles and rasterizes them.<summary>
  ///<remarks>
  ///<para>The triangles are of the form [v0, c0, v1, c1, v2, c2, ...] where
  ///the nth triangle starts at index 6n and each pair vi, ci is the vertex
  ///in clip space followed by the vertex color.
  ///</remarks>
  public static void rasterizeTriangles(int numTriangles, Vector3[] triangles,
                                        Vector3 cTmp,
                                        int w, int h, int[] frameBuffer, int[] zBuffer) {

//    System.out.println("rasterizeTriangles");

    // Determine top, middle, bottom vertices.
    final int trianglesLength = numTriangles * 6;
    for (int i = 0; i < trianglesLength; i += 6) {
      // Determine where to split the top and bottom trapezpoids.
      Vector3 v0 = triangles[i];     Vector3 c0 = triangles[i + 1];
      Vector3 v1 = triangles[i + 2]; Vector3 c1 = triangles[i + 3];
      Vector3 v2 = triangles[i + 4]; Vector3 c2 = triangles[i + 5];
      int state = ((v0.y < v1.y) ? 4 : 0) +
                  ((v1.y < v2.y) ? 2 : 0) +
                  ((v0.y < v2.y) ? 1 : 0);
      switch (state) {
        case 7: break;
        case 6:
        case 4:
          // v2 < v0 < v1 ==> rotateLeft(v2, v0, v1)
          { Vector3 tmp = v0; v0 = v2; v2 = v1; v1 = tmp; }
          { Vector3 tmp = c0; c0 = c2; c2 = c1; c1 = tmp; }
          break;
        case 3:
          // v1 < v0 < v2 ==> swap(v1, v0)
          { Vector3 tmp = v1; v1 = v0; v0 = tmp; }
          { Vector3 tmp = c1; c1 = c0; c0 = tmp; }
          break;
        case 2:
          // v1 < v2 < v0 ==> rotateRight(v1, v2, v0)
          { Vector3 tmp = v0; v0 = v1; v1 = v2; v2 = tmp; }
          { Vector3 tmp = c0; c0 = c1; c1 = c2; c2 = tmp; }
          break;
        case 5:
        case 1:
          // v0 < v2 < v1 ==> swap(v2, v1)
          { Vector3 tmp = v2; v2 = v1; v1 = tmp; }
          { Vector3 tmp = c2; c2 = c1; c1 = tmp; }
          break;
        case 0:
          // v2 < v1 < v0 ==> swap(v2, v0)
          { Vector3 tmp = v2; v2 = v0; v0 = tmp; }
          { Vector3 tmp = c2; c2 = c0; c0 = tmp; }
        default: break;
      }
      assert (v0.y <= v1.y) && (v1.y <= v2.y) && (v2.y <= v2.y)  :
             "sort error : v0.y = " + v0.y +
                        ", v1.y = " + v1.y + ", v2.y = " + v2.y;

      // Setup triangle edges and rasterize.
      edges[0].init(v0, v1, w, h);
      edges[1].init(v0, v2, w, h);
      edges[2].init(v1, v2, w, h);
      // Interpolate temporary color.
      final double t = (double)(edges[0].y1 - edges[0].y0) /
                       (double)(edges[1].y1 - edges[1].y0);
//      final double t = (v1.y - v0.y) / (v2.y - v0.y);
      cTmp.x = c0.x + (t * (c2.x - c0.x));
      cTmp.y = c0.y + (t * (c2.y - c0.y));
      cTmp.z = c0.z + (t * (c2.z - c0.z));

//      System.out.println("rasterizeTriangles, i = " + i);

//      System.out.println("edges[0].xStep = " + edges[0].xStep + ", " +
//                         "edges[0].ddaNumerator = " + edges[0].ddaNumerator + ",\n" +
//                         "edges[1].xStep = " + edges[1].xStep + ", " +
//                         "edges[1].ddaNumerator = " + edges[1].ddaNumerator + ",\n" +
//                         "edges[2].xStep = " + edges[2].xStep + ", " +
//                         "edges[2].ddaNumerator = " + edges[2].ddaNumerator);
      final int v1MidX = edges[1].x +
                         (edges[0].height * edges[1].xStep) +
                         ((edges[1].ddaErrorTerm + (edges[0].height * edges[1].ddaNumerator)) /
                          edges[1].ddaDenominator);
//      System.out.println("edges[0].x  = " + edges[0].x + ",  " +
//                         "edges[0].y  = " + edges[0].y + ",\n" +
//                         "edges[0].x1 = " + edges[0].x1 + ", " +
//                         "edges[0].y1 = " + edges[0].y1 + ",\n" +
//                         "edges[1].x  = " + edges[1].x + ",  " +
//                         "edges[1].y  = " + edges[1].y + ",\n" +
//                         "edges[1].x1 = " + edges[1].x1 + ", " +
//                         "edges[1].y1 = " + edges[1].y1 + ",\n" +
//                         "edges[2].x  = " + edges[2].x + ",  " +
//                         "edges[2].y  = " + edges[2].y + ",\n" +
//                         "edges[2].x1 = " + edges[2].x1 + ", " +
//                         "edges[2].y1 = " + edges[2].y1 + ",\n" +
//                         "v1MidX = " + v1MidX);
//      assert (edges[0].y  == edges[1].y)  &&
//             (edges[0].y1 == edges[2].y)  &&
//             (edges[1].y1 == edges[2].y1) &&
//             (edges[1].x1 == edges[2].x1) &&
//             (edges[0].x  == edges[1].x);

      if (v1MidX > edges[0].x1) {
        assert (0 == edges[0].height) || 
               (edges[0].x <= edges[1].x) : "edges out of order\n" +
                                            "edges[0].x = " + edges[0].x + " <= " +
                                            "edges[1].x = " + edges[1].x;
        Raster.rasterizeTrapezoid(edges[0], edges[1],
                                  c0, c0, c1, c2,
                                  w, h, frameBuffer, zBuffer);
      }
      else {
        assert (0 == edges[0].height) ||
               (edges[1].x <= edges[0].x) : "edges out of order\n" + 
                                            "edges[1].x = " + edges[1].x + " <= " +
                                            "edges[0].x = " + edges[0].x;
        Raster.rasterizeTrapezoid(edges[1], edges[0],
                                  c0, c0, c2, c1,
                                  w, h, frameBuffer, zBuffer);
      }
      assert v1MidX == edges[1].x;
      if (edges[1].x < edges[2].x) {
        Raster.rasterizeTrapezoid(edges[1], edges[2],
                                  c0, c1, c2, c2,
                                  w, h, frameBuffer, zBuffer);
      }
      else {
        Raster.rasterizeTrapezoid(edges[2], edges[1],
                                  c1, c0, c2, c2,
                                  w, h, frameBuffer, zBuffer);
      }
    }
  }

  // Scale all pixels to facilitate iterative interpolation.
  final static int PX_SCALE_SHIFT = 19;
  final static int PX_SCALE = 1 << PX_SCALE_SHIFT;
  // Scale all colors to facilitate iterative interpolation.
  final static int COLOR_SCALE_SHIFT = 22;
  final static int COLOR_SCALE = 1 << COLOR_SCALE_SHIFT;
  final static int COLOR_SCALE_HALF = COLOR_SCALE >> 1;
  final static double SQRT_255 = Math.sqrt(255);

  ///<summary>Perform mathematically correct floor div and mod.</summary>
  ///<remarks>
  ///<para>This function is essential for keeping track of the discrete error
  ///term while stepping between scanlines. Each time the error term rolls
  ///over, the current scanline will shift right one pixel.</para>
  ///</remarks>
  static long floorDiv(int a, int b) {
    int div, mod;
    if (a >= 0) {
      div = a / b;
      mod = a % b;
    }
    else {
      div = -(-a / b);
      mod = -a % b;
      if (mod > 0) {
        --div;
        mod = b - mod;
      }
    }
    assert (div * b) + mod == a : "floordiv invalid";
    return (long)div << 32 | mod;
  }

  ///<summary>Discrete difference analyzer rasterization method.</summary>
  ///<remarks>
  ///<para>In order to prevent drawing pixels multiple times and to eliminate
  ///poor quality rasterization artifacts such as dropouts, this implementation
  ///uses DDA stepping to create a smooth raster image.</para>
  ///<para>This method was studied intensely from an article by Chris Hecker
  ///available at http://chrishecker.com/images/9/97/Gdmtex2.pdf</para>
  ///</remarks>
  public static void rasterizeTrapezoid(Edge edgeL, Edge edgeR,
                                        Vector3 tlC, Vector3 trC, Vector3 blC, Vector3 brC,
                                        int w, int h, int[] frameBuffer, int[] zBuffer) {

    final int scanlines = Math.min(edgeL.height, edgeR.height);
    if (0 == scanlines)
    {
      return;
    }

    // Compute integer color values for all vertex locations.
    // tl
    final int tlVz = (int)(PX_SCALE * edgeL.v0.z);
    final int tlCr = (int)(COLOR_SCALE * tlC.x * 255.0);
    final int tlCg = (int)(COLOR_SCALE * tlC.y * 255.0);
    final int tlCb = (int)(COLOR_SCALE * tlC.z * 255.0);
    // tr
    final int trVz = (int)(PX_SCALE * edgeR.v0.z);
    final int trCr = (int)(COLOR_SCALE * trC.x * 255.0);
    final int trCg = (int)(COLOR_SCALE * trC.y * 255.0);
    final int trCb = (int)(COLOR_SCALE * trC.z * 255.0);
    // bl
    final int blVz = (int)(PX_SCALE * edgeL.v1.z);
    final int blCr = (int)(COLOR_SCALE * blC.x * 255.0);
    final int blCg = (int)(COLOR_SCALE * blC.y * 255.0);
    final int blCb = (int)(COLOR_SCALE * blC.z * 255.0);
    // br
    final int brVz = (int)(PX_SCALE * edgeR.v1.z);
    final int brCr = (int)(COLOR_SCALE * brC.x * 255.0);
    final int brCg = (int)(COLOR_SCALE * brC.y * 255.0);
    final int brCb = (int)(COLOR_SCALE * brC.z * 255.0);
    // Compute interpolation steps for L edge.
    final int edgeLTotalHeight = edgeL.y1 - edgeL.y0;
    final int zStepL = (blVz - tlVz) / edgeLTotalHeight;
    final int rStepL = (blCr - tlCr) / edgeLTotalHeight;
    final int gStepL = (blCg - tlCg) / edgeLTotalHeight;
    final int bStepL = (blCb - tlCb) / edgeLTotalHeight;
    // Compute interpolation steps for R edge.
    final int edgeRTotalHeight = edgeR.y1 - edgeR.y0;
    final int zStepR = (brVz - trVz) / edgeRTotalHeight;
    final int rStepR = (brCr - trCr) / edgeRTotalHeight;
    final int gStepR = (brCg - trCg) / edgeRTotalHeight;
    final int bStepR = (brCb - trCb) / edgeRTotalHeight;
    // Initialize all interpolation values.
    final int yOffsetL = edgeL.y - edgeL.y0;
    final int yOffsetR = edgeR.y - edgeR.y0;
    int z0 = tlVz + (yOffsetL * zStepL);
    int r0 = tlCr + (yOffsetL * rStepL);
    int g0 = tlCg + (yOffsetL * gStepL);
    int b0 = tlCb + (yOffsetL * bStepL);
    int z1 = trVz + (yOffsetR * zStepR);
    int r1 = trCr + (yOffsetR * rStepR);
    int g1 = trCg + (yOffsetR * gStepR);
    int b1 = trCb + (yOffsetR * bStepR);

    for (int yStep = 0, pxIdxY = edgeL.y * w;
         yStep < scanlines;
         ++yStep, pxIdxY += w, edgeL.step(), edgeR.step(),
         // Update L, R interpolation edges.
         z0 += zStepL, z1 += zStepR,
         r0 += rStepL, r1 += rStepR,
         g0 += gStepL, g1 += gStepR,
         b0 += bStepL, b1 += bStepR) {

      assert edgeL.y == edgeR.y : "scalines not synced on y\n" +
                                  "edgeL.y = " + edgeL.y + " != edgeR.y = " + edgeR.y;

      // Compute steps for this scanline.
      final int xSteps = 1 + edgeR.x - edgeL.x;
      if (xSteps <= 0) {
        continue;
      }
      final int zStep = (z1 - z0) / xSteps;
      final int rStep = (r1 - r0) / xSteps;
      final int gStep = (g1 - g0) / xSteps;
      final int bStep = (b1 - b0) / xSteps;
      int z = z0;
      int rScaled = r0 + COLOR_SCALE_HALF;
      int gScaled = g0 + COLOR_SCALE_HALF;
      int bScaled = b0 + COLOR_SCALE_HALF;

      int pxIdx = pxIdxY + edgeL.x;
      for (int x = edgeL.x;
           x <= edgeR.x;
           ++x, ++pxIdx,
           z += zStep,
           rScaled += rStep,
           gScaled += gStep,
           bScaled += bStep) {
        if (z < zBuffer[pxIdx]) {
          assert (rScaled >= 0) && (gScaled >= 0) && (bScaled >= 0) :
                 "bad pixel interpolation values";
          zBuffer[pxIdx] = z;
          // Gamma correction.
          final int rp = (int)(Math.sqrt((rScaled >> COLOR_SCALE_SHIFT) & 255) * SQRT_255);
          final int gp = (int)(Math.sqrt((gScaled >> COLOR_SCALE_SHIFT) & 255) * SQRT_255);
          final int bp = (int)(Math.sqrt((bScaled >> COLOR_SCALE_SHIFT) & 255) * SQRT_255);
          frameBuffer[pxIdx] =       255  << 24 | // No alpha.
                               (rp & 255) << 16 |
                               (gp & 255) <<  8 |
                               (bp & 255)       ;
        }
      }
    }
  }
}

