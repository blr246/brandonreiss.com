/*
 * Material.java
 *
 * Basic phong shading material.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.geometry;

import com.brandonreiss.math.*;

///<summary>Phong shading material.</summary>
public class Material {
  ///<summary>Ambient constants.</summary>
  public Vector3 kA = new Vector3(1, 1, 1);
  ///<summary>Diffuse constants.</summary>
  public Vector3 kD = new Vector3(1, 1, 1);
  ///<summary>Specular constants.</summary>
  public Vector3 kS = new Vector3(1, 1, 1);
  ///<summary>Specular exponent.</summary>
  public double alphaS = 5.0;

  public static Material defaultMaterial = new Material();
}

