/*
 * SpotLight.java
 *
 * Point light with exponential attenuation about the negative Z-axis direction.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.geometry;
import com.brandonreiss.math.*;

///<summary>A simulated light.</summary>
public class SpotLight extends Light {
  public double exp = 1.0;
  public Vector3 i = new Vector3(1, 1, 1);

  public double getDirectionAtPoint(Vector3 p, Vector3 dir) {
    dir.set(transform.m[0][3], transform.m[1][3], transform.m[2][3]).sub(p);
    final double lightDistSq = dir.lengthSq();
    dir.normalize();
    return lightDistSq;
  }
  public void getIntensity(Vector3 p, Vector3 dir, Vector3 iPt) {
    final double lambertian = (dir.x * transform.m[0][2]) +
                              (dir.y * transform.m[1][2]) +
                              (dir.z * transform.m[2][2]);
    final double attenuation = Math.pow(lambertian, exp);
    if (attenuation > 0) {
      iPt.set(i).mul(attenuation);
    }
    else {
      iPt.zero();
    }
  }
  @Override
  public void render(Renderer r) {}
}

