/*
 * Renderer.java
 *
 * A scene renderer. Transforms vertices and may apply a special vertex
 * transformation program.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.geometry;

import com.brandonreiss.math.*;
import com.brandonreiss.util.*;
import java.awt.*;
import java.util.EnumSet;
import java.util.ArrayList;
import java.util.Arrays;

///<summary>A z-buffer renderer.</summary>
public class Renderer { 

  ///<summary>Ambient light intensity.</summary>
  public Vector3 iA = new Vector3(0.07, 0.07, 0.07);
  ///<summary>Scene lighting.</summary>
  public Light[] lights = new Light[0];

  ///<summary>The default vertex shader.</summary>
  private VertexProgram defaultVertexProgram = new ModelViewTransform();

  ///<summary>The view matrix inverse.</summary>
  public Matrix4x4 viewMat = Matrix4x4.newMatrixIdentity();
  ///<summary>The view matrix inverse.</summary>
  public Matrix4x4 viewMatInv = Matrix4x4.newMatrixIdentity();
  ///<symmary>The projection matrix.</summary>
  public Matrix4x4 projMat = Matrix4x4.newMatrixIdentity();
  ///<summary>Temporary for model transform inverse transpose.</summary>
  private Matrix4x4 tformInvTMat = new Matrix4x4();
  ///<summary>Width of target screen.</summary>
  public int w = 640;
  ///<summary>Height of target screen.</summary>
  public int h = 480;
  ///<summary>Set of render flags.</summary>
  public EnumSet<Flags> flags = EnumSet.noneOf(Flags.class);
  ///<summary>Vertex shader program.</summary>
  public VertexProgram vertexProgram = defaultVertexProgram;

  ///<summary>Projected vertices.</summary>
  private ArrayPtr.Vector3 projVertexColorsPtr = new ArrayPtr.Vector3();
  ///<summary>AABB minimums.</summary>
  private Vector3 aabbMins = new Vector3();
  ///<summary>AABB maximums.</summary>
  private Vector3 aabbMaxs = new Vector3();
  ///<summary>Face projection coordinates swap A.</summary>
  private ArrayPtr.Vector3 faceVerticesAPtr = new ArrayPtr.Vector3();
  ///<summary>Face projection coordinates swap B.</summary>
  private ArrayPtr.Vector3 faceVerticesBPtr = new ArrayPtr.Vector3();
  ///<summary>Tempraries used during phong shading.</summary>
  private ArrayPool.Vector3 shadingPool = new ArrayPool.Vector3();

  ///<summary>Copy of the eye space z-coordinate.</summary>
  ///<remarks>
  ///<para>Due to the nonlinear nature of the homogeneous divide during
  ///projection, it is not possible to render properly geometry that extends
  ///beyond the zero crossing of camera depth. We need to remember the
  ///z-coordinates in eye space for each vertex so that we may discard any
  ///face that is behind the camera plane.</para>
  ///</remarks>
  private ArrayPtr.Double eyeVertexZPtr = new ArrayPtr.Double();

  ///<summary>The framebuffer pointer.</summary>
  public int[] renderTarget = null;
  ///<summary>The zBuffer pointer.</summary>
  public int[] zBuffer = null;
  ///<summary>Transformed triangles.</summary>
  private Vector3[] triangles = new Vector3[0];
  ///<summary>Temporary for rasterization.</summary>
  private Vector3 cTmp = new Vector3();

  // Culling temporaries.
  private Vector3 cullEdge0 = new Vector3();
  private Vector3 cullEdge1 = new Vector3();
  private Vector3 cullNormal = new Vector3();

  ///<summary>Set of render states.</summary>
  public enum Flags {
    CULL_BACKFACE,
//    WIRE_TRIANGLES,
//    ALPHA_BLEND,
//    SHADOW_MAP,
  }

  ///<summary>Vertex processing to occur just before rasterization.</summary>
  public interface VertexProgram {
    public void run(Matrix4x4 tformMat, Matrix4x4 tformInvTMat, Material m,
                    Vector3[] vertexNormals, Vector3[] tformColor);
  }

  ///<summary>The standard modelview vertex program.</summary>
  private class ModelViewTransform implements VertexProgram {
    @Override
    public void run(Matrix4x4 tformMat, Matrix4x4 tformInvTMat, Material m,
                    Vector3[] vertexNormals, Vector3[] tformColor) {
      // TODO(reissb) -- Compute lighting.
      final int vertexNormalsLength = vertexNormals.length;
      assert(vertexNormalsLength <= tformColor.length);
      for (int i = 0; i < vertexNormalsLength; i += 2) {
        Vector3 v = tformColor[i];
        Vector3 n = tformColor[i + 1];
        Vector3 c = tformColor[i + 1];
        v.set(vertexNormals[i    ]).transformCoord(tformMat);
        n.set(vertexNormals[i + 1]).transformNormal(tformInvTMat).normalize();
        phongShade(v, n, m, lights, iA, shadingPool, c);
//        System.out.println("vOrig = " + vertexNormals[i    ] + ",\n" +
//                           "vTfrm = " + v);
      }
    }
  }

  ///<summary>Compute Phong shading at surface point V.</summary>
  public void phongShade(Vector3 V, Vector3 N, Material m,
                         Light[] lights, Vector3 iA,
                         ArrayPool.Vector3 vector3Pool, Vector3 color) {

    // Allocate from pooled memory.
    final int VECTOR3_ALLOC_COUNT = 6;
    Vector3 viewDir, diffuse, specular, lightDir, reflectDir, iTmp;
    {
      int poolIdx = vector3Pool.alloc(VECTOR3_ALLOC_COUNT);
      Vector3[] pool = vector3Pool.get();
      viewDir = pool[poolIdx++].zero();
      diffuse = pool[poolIdx++].zero();
      specular = pool[poolIdx++].zero();
      lightDir = pool[poolIdx++];
      reflectDir = pool[poolIdx++];
      iTmp = pool[poolIdx++];
    }
    // Camera is at the origin, so we are viewing along the direction
    // to the point.
    viewDir.set(V).normalize();

    // Compute diffuse, specular color.
    for (Light l : lights) {
      final double lightDistSq = l.getDirectionAtPoint(V, lightDir);
      // Light is visible?
      final double lightDirDotN = lightDir.dot(N);
      if (lightDirDotN > 0) {
        // Diffuse part.
        l.getIntensity(V, lightDir, iTmp);
        iTmp.mul(lightDirDotN).mul(m.kD);
        diffuse.add(iTmp);
        // Specular part.
        reflectDir.set(N).mul(lightDirDotN).mul(2).sub(lightDir);
        final double reflectDirDotV = -reflectDir.dot(viewDir);
        if (reflectDirDotV > 0) {
          final double specularAttenuation = Math.pow(reflectDirDotV, m.alphaS);
          l.getIntensity(V, lightDir, iTmp);
          iTmp.mul(specularAttenuation).mul(m.kS);
          specular.add(iTmp);
        }
      }
    }
    // Compute final color.
    color.set(iA).mul(m.kA);
    color.add(specular);
    color.add(diffuse);
    color.clip(0, 1);

    // Return pooled variables.
    vector3Pool.free(VECTOR3_ALLOC_COUNT);
  }

  ///<summary>Restore the default vertex program.</summary>
  public void resetVertexProgram() {
    vertexProgram = defaultVertexProgram;
  }

  ///<summary>Render the mesh.</summary>
  public void render(Mesh mesh) {
    // Transform and light vertices.
    Vector3[] vertexNormals = mesh.vertexNormals;
    assert(null != vertexNormals);
    final int vertexNormalsLength = vertexNormals.length;
    final int verticesLength = vertexNormalsLength >> 1;
    Vector3[] projVertexColors = projVertexColorsPtr.grow(vertexNormalsLength);
    // Compute model view projection matrix for this mesh depending on parent.
    Matrix4x4 tformMat = mesh.hasParent() ? mesh.transform : mesh.transformLocal;
    tformInvTMat.set(tformMat).inverse().transpose();
    vertexProgram.run(tformMat, tformInvTMat, mesh.getMaterialFallbackDefault(),
                      vertexNormals, projVertexColors);
    // Project the vertices and check mesh clip.
    aabbMins.set( 2, 2, 2);
    aabbMaxs.set(-2,-2,-2);
    double[] eyeVertexZ = eyeVertexZPtr.grow(verticesLength);
    for (int vIdx = 0; vIdx < vertexNormalsLength; vIdx += 2) {
      Vector3 vProj = projVertexColors[vIdx];
      eyeVertexZ[vIdx >> 1] = vProj.z;
      vProj.transformCoord(projMat);
//      vProj.y *= -1;
//      System.out.println("vProj = " + vProj);
      // Check vertex clip in NDC.
      aabbMins.x = Math.min(vProj.x, aabbMins.x);
      aabbMins.y = Math.min(vProj.y, aabbMins.y);
      aabbMins.z = Math.min(vProj.z, aabbMins.z);
      aabbMaxs.x = Math.max(vProj.x, aabbMaxs.x);
      aabbMaxs.y = Math.max(vProj.y, aabbMaxs.y);
      aabbMaxs.z = Math.max(vProj.z, aabbMaxs.z);
    }
    if ((aabbMaxs.min() < -1) || (aabbMins.max() > 1)) {
//      System.out.println("mesh tossed\n" +
//                         "aabbMaxs = " + aabbMaxs + ",\n" +
//                         "aabbMins = " + aabbMins);
      return;
    }

    // Draw the faces.
    int[][] faces = mesh.faces;
    assert(null != faces);
    for (int[] face : faces) {
      assert(null != face);
      final int faceLength = face.length;
      final int faceVerticesLength = 2 * faceLength;
      assert(faceVerticesLength >= 6);
      // Check projection buffer length.
      Vector3[] faceVertices = faceVerticesAPtr.grow(faceVerticesLength);
      faceVerticesBPtr.grow(faceVerticesLength);

      // Get projected face and check clipping.
      aabbMins.set( 2, 2, 2);
      aabbMaxs.set(-2,-2,-2);
      int behindCamCount = 0;
      for (int fIdx = 0; fIdx < faceLength; ++fIdx) {
        if (eyeVertexZ[face[fIdx] >> 1] > 0) {
          ++behindCamCount;
        }
        final int vfidx = 2 * fIdx;
        final int cfidx = vfidx + 1;
        Vector3 v = faceVertices[vfidx];
        Vector3 c = faceVertices[cfidx];
        v.set(projVertexColors[face[fIdx]    ]);
        c.set(projVertexColors[face[fIdx] + 1]);
        // Check vertex clip in NDC.
        aabbMins.x = Math.min(v.x, aabbMins.x);
        aabbMins.y = Math.min(v.y, aabbMins.y);
        aabbMins.z = Math.min(v.z, aabbMins.z);
        aabbMaxs.x = Math.max(v.x, aabbMaxs.x);
        aabbMaxs.y = Math.max(v.y, aabbMaxs.y);
        aabbMaxs.z = Math.max(v.z, aabbMaxs.z);
      }
      if ((aabbMaxs.min() < -1) || (aabbMins.max() > 1) || (behindCamCount > 0)) {
//        System.out.println("face tossed\n" +
//                           "aabbMaxs = " + aabbMaxs + ",\n" +
//                           "aabbMins = " + aabbMins + ",\n" +
//                           "behindCamCount = " + behindCamCount);
        continue;
      }

      // Clip when needed.
      int clippedFaceLength = faceLength;
      if ((aabbMaxs.max() > 1) || (aabbMins.min() < -1)) {
        // Clip to projection NDC cuboid (will result to B).
        clippedFaceLength = clipSutherlandHodgman(faceVerticesAPtr, faceLength,
                                                  faceVerticesBPtr);
        faceVertices = faceVerticesBPtr.get();
      }
      if (0 == clippedFaceLength) {
        continue;
      }

//      for (int i = 0; i < clippedFaceLength; ++i) {
//        final int vIdx = 2 * i;
//        System.out.println("vClip = " + faceVertices[vIdx]);
//      }

      // Culling.
      if (flags.contains(Flags.CULL_BACKFACE)) {
        // Assume convex and compute normal.
        cullEdge0.set(faceVertices[2]).sub(faceVertices[0]);
        cullEdge0.z = 0;
        cullEdge1.set(faceVertices[4]).sub(faceVertices[0]);
        cullEdge1.z = 0;
        // Cross to get face normal.
        cullNormal.set(cullEdge1).cross(cullEdge0).normalize();
        // Backfaces point in same direction as camera.
//        System.out.println("cullEdge0 = " + cullEdge0 + ",\n" +
//                           "cullEdge1 = " + cullEdge1 + ",\n" +
//                           "cullNormal = " + cullNormal);
        if (cullNormal.z > 1.0e-8) {
//          System.out.println("culled backface");
          continue;
        }
      }

      // Triangulate mesh.
      final int numTriangles = (clippedFaceLength - 3) + 1;
      final int trianglesLength = numTriangles * 6;
      if (triangles.length < trianglesLength) {
        triangles = new Vector3[trianglesLength];
      }
      {
        Vector3 v0 = faceVertices[0];
        Vector3 c0  = faceVertices[1];
        int v1Idx = 2;
        int v2Idx = 4;
        for (int i = 0; i < trianglesLength; i += 6, v1Idx +=2, v2Idx += 2) {
          triangles[i    ] = v0;                  triangles[i + 1] = c0;
          triangles[i + 2] = faceVertices[v1Idx]; triangles[i + 3] = faceVertices[v1Idx + 1];
          triangles[i + 4] = faceVertices[v2Idx]; triangles[i + 5] = faceVertices[v2Idx + 1];
        }
      }
//      System.out.println("clippedFaceLength = " + clippedFaceLength + ", " +
//                         "numTriangles = " + numTriangles + ", " +
//                         "trianglesLength = " + trianglesLength);
      // Rasterize triangles.
      Raster.rasterizeTriangles(numTriangles, triangles, cTmp,
                                w, h, renderTarget, zBuffer);
    }
  }

  ///<summary>Temporary used for clipping.</summary>
  private Vector3 clipProjDirTmp = new Vector3();
  ///<summary>Projection cuboid clipped using unit cube.</summary>
  private Vector4[] clipPlanes = {new Vector4( 1, 0, 0,-1),
                                  new Vector4(-1, 0, 0,-1),
                                  new Vector4( 0, 1, 0,-1),
                                  new Vector4( 0,-1, 0,-1),
                                  new Vector4( 0, 0, 1,-1),
                                  new Vector4( 0, 0,-1,-1)};

  ///<summary>Sutherland-Hodgman clip algorithm.</summary>
  ///<remarks>
  ///<para>See
  ///http://en.wikipedia.org/wiki/Sutherland%E2%80%93Hodgman_algorithm
  ///for more information.
  ///</para>
  ///</remarks>
  private int clipSutherlandHodgman(ArrayPtr.Vector3 inputListPtr, int faceLength,
                                    ArrayPtr.Vector3 outputListPtr) {
    int clippedFaceLength = faceLength * 2;
    Vector3[] inputList = inputListPtr.get();
    Vector3[] outputList = outputListPtr.get();
    // Copy input to output.
    for (int i = 0; i < clippedFaceLength; ++i) {
      outputList[i].set(inputList[i]);
    }
    // Loop over clip polygons (X-axis, Y-axis, Z-axis).
    final int clipPlanesLength = clipPlanes.length;
    for (int clipPlaneIdx = 0;
         (clipPlaneIdx < clipPlanesLength) &&
         (clippedFaceLength > 0); ++clipPlaneIdx) {
      Vector4 clipPlane = clipPlanes[clipPlaneIdx];
      // Copy output to input.
      for (int i = 0; i < clippedFaceLength; ++i) {
        inputList[i].set(outputList[i]);
      }
      // Initialize list sizes, point, inside test.
      final int listSize = inputList.length;
      int outputListSize = 0;
      Vector3 s = inputList[clippedFaceLength - 2];
      Vector3 sColor = inputList[clippedFaceLength - 1];
      boolean sInside = Util.PointPlaneDistance(s, clipPlane) <= 0;
      // Test all points in polygon.
      for (int vIdx = 0; vIdx < clippedFaceLength; vIdx += 2) {
        Vector3 e = inputList[vIdx];
        Vector3 eColor = inputList[vIdx + 1];
        final boolean eInside = Util.PointPlaneDistance(e, clipPlane) <= 0;
        if (eInside) {
          if (!sInside) {
            // Project to clip plane.
            outputList = outputListPtr.grow(outputListSize + 2);
            final double l = clipProjDirTmp.set(e).sub(s).length();
            clipProjDirTmp.normalize();
            Vector3 clipS = outputList[outputListSize].set(s);
            final double d = Util.PointProjectPlaneAlongDir(clipS, clipPlane, clipProjDirTmp);
            // Interpolate colors: A + t(B - A)
            outputList[outputListSize + 1].set(eColor).sub(sColor).mul(d / l).add(sColor);
            outputListSize += 2;
          }
          // Add original point.
          outputList = outputListPtr.grow(outputListSize + 2);
          outputList[outputListSize    ].set(e);
          outputList[outputListSize + 1].set(eColor);
          outputListSize += 2;
        }
        else if (sInside) {
          // Project to clip plane.
          outputList = outputListPtr.grow(outputListSize + 2);
          final double l = clipProjDirTmp.set(s).sub(e).length();
          clipProjDirTmp.normalize();
          Vector3 clipE = outputList[outputListSize].set(e);
          final double d = Util.PointProjectPlaneAlongDir(clipE, clipPlane,
                                                          clipProjDirTmp);
          // Interpolate colors: A + t(B - A)
          outputList[outputListSize + 1].set(sColor).sub(eColor).mul(d / l).add(eColor);
          outputListSize += 2;
        }
        s = e;
        sColor = eColor;
        sInside = eInside;
      }
      // Sync input list size.
      final int numToAdd = outputListSize - listSize;
      inputList = inputListPtr.grow(outputListSize);
      clippedFaceLength = outputListSize;
    }
    // Return length of result.
    return clippedFaceLength >> 1;
  }
}

