/*
 * Hw09.java
 *
 * Renderer with rasterization.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
import com.brandonreiss.math.*;
import com.brandonreiss.geometry.*;
import com.brandonreiss.util.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Hw09 extends BufferedApplet implements KeyListener {

  private Renderer renderer = new Renderer();
  ///<summary>View matrix (WORLD ==> CAMERA).</summary>
  private Matrix4x4 viewMat = renderer.viewMat;
  ///<summary>View matrix inverse (CAMERA ==> WORLD).</summary>
  private Matrix4x4 viewMatInv = renderer.viewMatInv;
  ///<summary>Projection matrix (CAMERA ==> CLIP).</summary>
  private Matrix4x4 projMat = renderer.projMat;

  // Scene elements.
  private Geometry[] shapes = new Geometry[0];
  private Dummy[] shapeControllers = new Dummy[0];
  private SceneGraph scene = new SceneGraph();
  private int[] zBuffer = new int[0];

  // Profiling variables.
  double fpsInterval = 3.0;
  double fpsTimerBegin = 0;
  int fpsCounter = 0;
  double fpsLastInterval = 0;

  // Robot items.
  Robot robot = new Robot();
  Vector3 robotPosTmp = new Vector3(0, 0, 0);
  Vector3 robotPosLast = new Vector3(0, 0, 0);
  Vector3 robotDisplaceTmp = new Vector3(0, 0, 0);
  double robotTimeLast = 0;

  // Keyboard handlers.
  public void keyPressed(KeyEvent e) { }
  public void keyReleased(KeyEvent e) { }
  public void keyTyped(KeyEvent e) {
    final char c = e.getKeyChar();
    switch (c) {
      default:
        break;
    }
  }

  public Hw09() {
    addKeyListener(this);
    // Make camera scene root.
    scene.root = viewMat;
    // Geometry and materials.
    shapes = new Geometry[ShapeId.count()];
    shapeControllers = new Dummy[ShapeId.count()];
    for (int i = 0; i < shapeControllers.length; ++i) {
      shapeControllers[i] = new Dummy();
    }
    {
      int idx = ShapeId.PLATFORM.idx();
      Geometry g = Geometry.newCube(20, 20, 1);
      Material m = g.newMaterial();
      m.kA.set(0.35, 0.7, 0.25);
      m.kD.set(0.35, 0.7, 0.25);
      m.kS.set(0.45, 0.7, 0.25);
      m.alphaS = 3.0;
      shapes[idx] = g;
      // Model.
      g.transformLocal.scale(12, 12, 0.06);
//      g.transformLocal.scale(30, 30, 1.0);
      g.transformLocal.translate(0, 0,-1);
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }
    {
      int idx = ShapeId.GROUND.idx();
      Geometry g = Geometry.newCube(30, 15, 1);
//      Geometry g = Geometry.newPlane(20, 20);
      Material m = g.newMaterial();
      m.kA.set(0.2, 0.6, 0.2);
      m.kD.set(0.2, 0.6, 0.2);
      m.kS.set(0.2, 0.6, 0.2);
      m.alphaS = 3.0;
      shapes[idx] = g;
      // Model.
      g.transformLocal.translate(0, 0,-0.17);
      g.transformLocal.scale(100, 8, 0.05);
//      g.transformLocal.scale(30, 30, 1.0);
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }
    {
      int idx = ShapeId.SPHERE_0.idx();
      Geometry g = Geometry.newSphere(8, 8, 8);
      Material m = g.newMaterial();
      m.kA.set(0.2, 0.6, 0.2);
      m.kD.set(0.2, 0.6, 0.2);
      m.kS.set(0.2, 0.6, 0.2);
      m.alphaS = 2.0;
      shapes[idx] = g;
      // Model.
      g.transformLocal.scale(1.0, 0.5, 0.75);
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }
    {
      int idx = ShapeId.SPHERE_1.idx();
      Geometry g = Geometry.newSphere(16, 10);
      Material m = g.newMaterial();
      m.kA.set(0.5, 0.5, 0.5);
      m.kD.set(0.5, 0.5, 0.5);
      m.kS.set(0.8, 0.8, 0.8);
      m.alphaS = 5.0;
      shapes[idx] = g;
      // Model.
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }
    {
      int idx = ShapeId.CUBE.idx();
      Geometry g = Geometry.newCube(3, 3, 3);
      //Geometry g = Geometry.newCube();
      Material m = g.newMaterial();
      m.kA.set(0.3, 0.3, 1.0);
      m.kD.set(0.4, 0.4, 0.9);
      m.kS.set(0.8, 0.8, 0.8);
      m.alphaS = 1.0;
      shapes[idx] = g;
      // Model.
      g.transformLocal.scale(0.2, 0.6, 1.0);
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }
    {
      int idx = ShapeId.TORUS.idx();
      Geometry g = Geometry.newTorus(16, 10, 0.25);
      Material m = g.newMaterial();
      m.kA.set(1.0, 0.8, 0.4);
      m.kD.set(0.6, 0.4, 0.2);
      m.kS.set(0.7, 0.5, 0.25);
      m.alphaS = 3.0;
      shapes[idx] = g;
      // Model.
      g.transformLocal.scale(1, 1, 1.28);
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }
    {
      int idx = ShapeId.CYLINDER.idx();
      Geometry g = Geometry.newCylinder(16, 10);
      Material m = g.newMaterial();
      m.kA.set(1.0, 0.3, 0.3);
      m.kD.set(0.9, 0.4, 0.4);
      m.kS.set(0.8, 0.8, 0.8);
      m.alphaS = 50.0;
      shapes[idx] = g;
      // Model.
      g.transformLocal.scale(0.6, 0.6, 1.0);
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }
    {
      int idx = ShapeId.CONE.idx();
      Geometry g = Geometry.newCone(16, 10);
      Material m = g.newMaterial();
      m.kA.set(0.3, 0.3, 1.0);
      m.kD.set(0.4, 0.4, 0.9);
      m.kS.set(0.8, 0.8, 0.8);
      m.alphaS = 50.0;
      shapes[idx] = g;
      // Model.
      g.transformLocal.translate(0.0, 0.0, 0.5);
      g.transformLocal.scale(1.0, 1.0, 1.5);
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }
    {
      int idx = ShapeId.PLANE.idx();
      Geometry g = Geometry.newPlane(2, 2);
      Material m = g.newMaterial();
      m.kA.set(0.2, 0.9, 0.2);
      m.kD.set(0.2, 0.9, 0.2);
      m.kS.set(0.9, 0.9, 0.9);
      m.alphaS = 10.0;
      shapes[idx] = g;
      // Model.
      shapeControllers[idx].addChild(g);
      scene.addChild(shapeControllers[idx]);
    }
    {
      int idx = ShapeId.ROBOT.idx();
      shapeControllers[idx].addChild(robot);
      scene.addChild(shapeControllers[idx]);
    }
    // Setup lighting.
    renderer.iA.set(0.1, 0.1, 0.1);
    renderer.lights = new Light[2];
    {
      PointLight l = new PointLight();
      l.transformLocal.translate(0,-5, 3);
      l.i.set(0.5, 0.5, 0.5);
      renderer.lights[0] = l;
      scene.addChild(l);
    }
    {
      PointLight l = new PointLight();
      l.transformLocal.translate(0, 5, 3);
      l.i.set(0.5, 0.5, 0.5);
      renderer.lights[1] = l;
      scene.addChild(l);
    }
    // Set render states.
    renderer.flags.add(Renderer.Flags.CULL_BACKFACE);
  }

  // Rendering variables.
  private int[] bgColor = new int[] {179, 195, 255};

  ///<summary>Convenient shape index manager.</summary>
  public enum ShapeId {
    PLATFORM,
    GROUND,
    SPHERE_0,
    SPHERE_1,
    CUBE,
    TORUS,
    CYLINDER,
    PLANE,
    CONE,
    ROBOT,
    ;

    private int idx;
    ShapeId() { this.idx = Count.next(); }
    public int idx() { return idx; }
    public static int count() { return Count.count; }
    private static class Count {
      private static int count = 0;
      public static int next() { return count++; }
    }
  }

  ///<summary>Initialization after applet is setup.</summary>
  public void initialize() {}

  ///<summary>Perform robot path and character animation.</summary>
  private void animateRobot(double t) {
    // Drive the robot around the spline.
    {
      Dummy controller = shapeControllers[ShapeId.ROBOT.idx()];
      controller.transformLocal.identity();
      final double robotTheta = 0.2 * t;
      final double ax = Math.cos(robotTheta);
      final double ay = Math.sin(robotTheta);
      robotPosTmp.set(9.0 * ax, 9.0 * ay, 0);
      controller.transformLocal.translate(robotPosTmp.x, robotPosTmp.y, robotPosTmp.z);
      controller.transformLocal.rotateZ(robotTheta);
      // Compute positional offset and animate.
      final double dt = t - robotTimeLast;
      robotDisplaceTmp.set(robotPosTmp).sub(robotPosLast);
      robot.animate(dt, robotDisplaceTmp);
      robotPosLast.set(robotPosTmp);
      robotTimeLast = t;
    }
    // Bobble robot head.
    {
      final double ax = Math.cos(t * 2);
      final double ay = Math.sin(t * 2);
      robot.headControl.transformLocal.identity();
      robot.headControl.transformLocal.rotateX(0.2 * ax);
      robot.headControl.transformLocal.rotateY(0.2 * ay);
    }
    // Move arms.
    {
      final double ax = Math.cos(t);
      final double ax2 = Math.cos(4 * t);
      final double ay = Math.cos(t);
      final double ay2 = Math.cos(2 * t);
      robot.upperArmControlL.transformLocal.identity();
      robot.upperArmControlL.transformLocal.rotateX( 0.5 * ax * ax);
      robot.upperArmControlL.transformLocal.rotateY(ax);
        robot.lowerArmControlL.transformLocal.identity();
        robot.lowerArmControlL.transformLocal.rotateY(ay);
        robot.lowerArmControlL.transformLocal.rotateX(ay2);
      robot.upperArmControlR.transformLocal.identity();
      robot.upperArmControlR.transformLocal.rotateX( 0.5 * ax * ax);
      robot.upperArmControlR.transformLocal.rotateY(ay);
        robot.lowerArmControlR.transformLocal.identity();
        robot.lowerArmControlR.transformLocal.rotateY(ay);
        robot.lowerArmControlR.transformLocal.rotateX(ay2);
    }
  }


  ///<summary>Perform animation updates.</summary>
  public void animate(double t) {
    // Setup camera matrix.
    {
      final double cameraTheta = -t * 0.17;
//      final double cameraTheta = 0.3;
      final double ax = Math.cos(cameraTheta);
      final double ay = Math.sin(cameraTheta);
      viewMatInv.identity();
      viewMatInv.rotateZ(-cameraTheta);
      viewMatInv.translate(0, -5 * ay * ay, 0);
      viewMatInv.rotateX(-(Math.PI * 0.30) - (0.5 * ax));
      viewMatInv.translate(0, 0, 25);
    }
    // Compute view matrix.
    viewMat.set(viewMatInv).inverse();
    // Setup projection.
    final double aspect = (double)width / (double)height;
    projMat.projectionFovH(Math.PI * 0.3, aspect, 2, 120.0);

    // Animate shapes.
    {
      {
        Dummy controller = shapeControllers[ShapeId.CUBE.idx()];
        controller.transformLocal.identity();
        controller.transformLocal.translate(0, 0, 1.25);
        controller.transformLocal.rotateZ(t);
      }
      {
        Dummy controller = shapeControllers[ShapeId.SPHERE_0.idx()];
        controller.transformLocal.identity();
        controller.transformLocal.translate(-3, 0, 1.25);
        controller.transformLocal.rotateZ(t);
      }
      {
        Dummy controller = shapeControllers[ShapeId.SPHERE_1.idx()];
        controller.transformLocal.identity();
        controller.transformLocal.translate( 3, 0, 1.25);
        controller.transformLocal.rotateZ(t);
      }
      {
        Dummy controller = shapeControllers[ShapeId.TORUS.idx()];
        controller.transformLocal.identity();
        controller.transformLocal.translate( 6, 0, 1.25);
        controller.transformLocal.rotateZ(t);
      }
      {
        Dummy controller = shapeControllers[ShapeId.CYLINDER.idx()];
        controller.transformLocal.identity();
        controller.transformLocal.translate(-6, 0, 1.25);
        controller.transformLocal.rotateZ(t);
      }
      {
        Dummy controller = shapeControllers[ShapeId.PLANE.idx()];
        controller.transformLocal.identity();
        controller.transformLocal.translate( 12, 0, 1.25);
        controller.transformLocal.rotateZ(t);
      }
      {
        Dummy controller = shapeControllers[ShapeId.CONE.idx()];
        controller.transformLocal.identity();
        controller.transformLocal.translate(-12, 0, 1.25);
        controller.transformLocal.rotateZ(t);
      }
      {
        animateRobot(t);
      }
    }

    // Update shape transformations.
    scene.updateTransform();
  }

  ///<summary>Render the scene.</summary>
  public void computeImage(double t, int[] pixels) {

    final int pixelsLength = pixels.length;
    if (zBuffer.length != pixelsLength) {
      zBuffer = new int[pixels.length];
    }
    // Set current screen dimensions.
    renderer.w = width;
    renderer.h = height;
    // Setup render target.
    renderer.renderTarget = pixels;
    renderer.zBuffer = zBuffer;
    // Clear zBuffer, frame buffer.
    Arrays.fill(zBuffer, Integer.MAX_VALUE);
    Arrays.fill(pixels, pack(bgColor[0], bgColor[1], bgColor[2]));

    scene.render(renderer);

    // Update profiling.
    ++fpsCounter;
    final double tElapsed = t - fpsTimerBegin;
    if (tElapsed > fpsInterval) {
      fpsLastInterval = fpsCounter / tElapsed;
      fpsTimerBegin = t;
      fpsCounter = 0;
    }
  }
}

