/*
 * Ray.java
 *
 * A 3d ray.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.math;

public class Ray {
  ///<summary>Create a ray using a reference to the given data.</summary>
  public static Ray createWithNoCopy(Vector3 pt, Vector3 dir) {
    Ray r = new Ray();
    r.pt = pt;
    r.dir = dir;
    return r;
  }
  ///<summary>Create a ray using copy of the given data.</summary>
  public static Ray createWithCopy(Vector3 pt, Vector3 dir) {
    Ray r = new Ray();
    r.pt = new Vector3(pt);
    r.dir = new Vector3(dir);
    return r;
  }
  ///<summary>Create an empty ray with null data.</summary>
  public static Ray createEmpty() {
    Ray r = new Ray();
    return r;
  }
  ///<summary>Create a ray with valid data all zeros.</summary>
  public static Ray createZero() {
    Ray r = new Ray();
    r.pt = Vector3.vectorZero();
    r.dir = Vector3.vectorZero();
    return r;
  }

  private Ray() {};
  public Vector3 pt = null;
  public Vector3 dir = null;
}

