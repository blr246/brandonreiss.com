/*
 * Edge.java
 *
 * Edge detection helper functions.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.math;

public class Edge
{
  ///<summary>Detect a depth edge along a line.</summary>
  public static boolean depthEdge(double a, double b, double thresh) {
    final boolean aInf = Double.POSITIVE_INFINITY == a;
    final boolean bInf = Double.POSITIVE_INFINITY == b;
    if ((aInf && !bInf) || (!aInf && bInf)) {
      return true;
    }
    else {
      final double d = a - b;
      return (d * d) > (thresh * thresh);
    }
  }

  ///<summary>Detect a depth edge in a box pattern.</summary>
  public static boolean depthEdgeBox(double a, double b,
                              double c, double d, double thresh) {
    return depthEdge(a, d, thresh) || depthEdge(b, c, thresh) ||
           depthEdge(a, b, thresh) || depthEdge(c, d, thresh) ||
           depthEdge(a, c, thresh) || depthEdge(b, d, thresh);
  }

  ///<summary>Detect a depth edge in a cross pattern.</summary>
  public static boolean depthEdgeCross(double a, double b,
                                double c, double d, double thresh) {
    return depthEdge(a, b, thresh) || depthEdge(c, d, thresh) ||
           depthEdge(a, c, thresh) || depthEdge(d, b, thresh) ||
           depthEdge(a, d, thresh) || depthEdge(c, b, thresh);
  }

  ///<summary>Detect an edge between two points.</summary>
  public static boolean edge(Vector3 a, Vector3 b, double thresh) {
    final double dxR = a.x - b.x;
    final double dxG = a.y - b.y;
    final double dxB = a.z - b.z;
    final double dist = (dxR * dxR) + (dxG * dxG) + (dxB * dxB);
    return dist > (thresh * thresh);
  }

  ///<summary>Detect an edge in a box pattern.</summary>
  public static boolean edgeBox(Vector3 a, Vector3 b,
                                Vector3 c, Vector3 d, double thresh) {
    return edge(a, d, thresh) || edge(b, c, thresh) ||
           edge(a, b, thresh) || edge(c, d, thresh) ||
           edge(a, c, thresh) || edge(b, d, thresh);
  }

  ///<summary>Detect an edge in a cross pattern.</summary>
  public static boolean edgeCross(Vector3 a, Vector3 b,
                                  Vector3 c, Vector3 d, double thresh) {
    return edge(a, b, thresh) || edge(c, d, thresh) ||
           edge(a, c, thresh) || edge(d, b, thresh) ||
           edge(a, d, thresh) || edge(c, b, thresh);
  }
}

