/*
 * Util.java
 *
 * Math utilities.
 *
 * 2012 Brandon Reiss. All Rights Reserved. Do not duplicate or distribute
 * without the author's consent.
*/
package com.brandonreiss.math;

import com.brandonreiss.math.*;

public class Util {
  ///<summaryGet the distance from the point to the plane.</summary>
  ///<remarks>
  ///<para> A positive distance indicates that the point is above the
  ///plane while a negative one indicates that it is below.
  ///</para>
  ///</remarks>
  public static double pointPlaneDistance(Vector3 pt, Vector4 plane) {
    return pt.dot(plane) + plane.w;
  }

  ///<summaryProject the point to the given plane.</summary>
  public static Vector3 pointProjectPlane(Vector3 pt, Vector4 plane) {
    final double d = -pointPlaneDistance(pt, plane);
    pt.x += plane.x * d; pt.y += plane.y * d; pt.z += plane.z * d;
    return pt;
  }

  ///<summaryProject the point to the given plane.</summary>
  public static Vector3 pointProjectPlane(Vector3 pt, Vector4 plane, Vector3 res) {
    return pointProjectPlane(res.set(pt), plane);
  }

  ///<summaryProject a point to a plane along the given direction.</summary>
  public static double pointPlaneDistanceAlongDir(Vector3 pt, Vector4 plane, Vector3 dir) {
    final double nDotDir = dir.dot(plane);
    if (0 != Math.abs(nDotDir)) {
      // Get parametric step along light direction to plane.
      final double ptPlaneDist = pointPlaneDistance(pt, plane);
      if ((ptPlaneDist * nDotDir) <= 0) {
        if (nDotDir > 0) {
          return  ptPlaneDist / nDotDir;
        }
        else {
          return -ptPlaneDist / nDotDir;
        }
      }
    }
    return Double.NEGATIVE_INFINITY;
  }

  ///<summaryProject a point to a plane along the given direction.</summary>
  public static boolean pointProjectPlaneAlongDir(Vector3 pt, Vector4 plane, Vector3 dir) {
    final double t = pointPlaneDistanceAlongDir(pt, plane, dir);
    if (t >= 0) {
      // Add distance along light ray to projection.
      pt.x += dir.x * t; pt.y += dir.y * t; pt.z += dir.z * t;
      return true;
    }
    return false;
  }

  ///<summary>Bilinear interpolation in a box pattern.</summary>
  ///<remarks>
  ///<para>This may get infinity values as depth.</para>
  ///</remarks>
  public static double blerpBox(double tl, double tr,
                                double bl, double br, double x, double y) {
    double maxNotInf = Double.NEGATIVE_INFINITY;
    boolean lerp = false;
    double vl = 0, vr = 0, ht = 0, hb = 0;
    if (Double.POSITIVE_INFINITY != tl) {
      maxNotInf = Math.max(maxNotInf, tl);
      if (Double.POSITIVE_INFINITY != tr) {
        maxNotInf = Math.max(maxNotInf, tr);
        ht += tl + (x * (tr - tl));
        lerp = true;
      }
      if (Double.POSITIVE_INFINITY != bl) {
        maxNotInf = Math.max(maxNotInf, bl);
        vl += tl + (y * (bl - tl));
        lerp = true;
      }
    }
    if (Double.POSITIVE_INFINITY != tr) {
      maxNotInf = Math.max(maxNotInf, tr);
      if (Double.POSITIVE_INFINITY != br) {
        maxNotInf = Math.max(maxNotInf, br);
        vr += tr + (y * (br - tr));
        lerp = true;
      }
    }
    if (Double.POSITIVE_INFINITY != bl) {
      maxNotInf = Math.max(maxNotInf, bl);
      if (Double.POSITIVE_INFINITY != br) {
        maxNotInf = Math.max(maxNotInf, br);
        hb += bl + (y * (br - bl));
        lerp = true;
      }
    }
    if (Double.POSITIVE_INFINITY != br) {
      maxNotInf = Math.max(maxNotInf, br);
    }
    if (lerp) {
      final int hState = ((ht > 0) ? 1 : 0) + ((hb > 0) ? 2 : 0);
      final int vState = ((vl > 0) ? 1 : 0) + ((vr > 0) ? 2 : 0);
      final double wh = ((vState > 0) && (hState > 0)) ? 0.5 : 0;
      final double wv = 1.0 - wh;
      double resAccum = 0;
      switch (hState) {
        case 1: resAccum += wh * ht; break;
        case 2: resAccum += wh * hb; break;
        case 3: resAccum += wh * (ht + (y * (hb - ht))); break;
        default: break;
      }
      switch (vState) {
        case 1: resAccum += wv * vl; break;
        case 2: resAccum += wv * vr; break;
        case 3: resAccum += wv * (vl + (x * (vr - bl)));
        default: break;
      }
      return resAccum;
    }
    else if (maxNotInf != Double.NEGATIVE_INFINITY) {
      return maxNotInf;
    }
    else {
      return Double.POSITIVE_INFINITY;
    }
  }

  ///<summary>Bilinear interpolation in a cross pattern.</summary>
  ///<remarks>
  ///<para>This may get infinity values as depth.</para>
  ///</remarks>
  public static double blerpCross(double l, double r,
                                  double t, double b, double x, double y) {
    double maxNotInf = Double.NEGATIVE_INFINITY;
    boolean lerp = false;
    double v = 0, h = 0;
    if (Double.POSITIVE_INFINITY != l) {
      maxNotInf = Math.max(maxNotInf, l);
      if (Double.POSITIVE_INFINITY != r) {
        maxNotInf = Math.max(maxNotInf, r);
        h = l + (x * (r - l));
        lerp = true;
      }
    }
    if (Double.POSITIVE_INFINITY != t) {
      maxNotInf = Math.max(maxNotInf, t);
      if (Double.POSITIVE_INFINITY != b) {
        maxNotInf = Math.max(maxNotInf, b);
        v = t + (y * (b - t));
        lerp = true;
      }
    }
    if (lerp) {
      double res = 0;
      final int state = ((v > 0) ? 1 : 0) + ((h > 0) ? 2 : 0);
      switch (state) {
        case 1: res = v;
        case 2: res = h;
        case 3: res = (0.5 * v) + (0.5 * h);
        default: break;
      }
      return res;
    }
    else if (maxNotInf != Double.NEGATIVE_INFINITY) {
      return maxNotInf;
    }
    else {
      return Double.POSITIVE_INFINITY;
    }
  }

  ///<summary>Linear interpolation accumulate.</summary>
  public static void lerpAccum(double w, Vector3 a, Vector3 b, double t, Vector3 v) {
    v.x += w * (a.x + (t * (b.x - a.x)));
    v.y += w * (a.y + (t * (b.y - a.y)));
    v.z += w * (a.z + (t * (b.z - a.z)));
  }

  ///<summary>Bilinear interpolation in a box pattern.</summary>
  public static void blerpBox(Vector3 tl, Vector3 tr, Vector3 bl, Vector3 br,
                              double x, double y, Vector3 v) {
    v.zero();
    final double xInv = 1.0 - x;
    final double yInv = 1.0 - y;
    lerpAccum(0.5 * y,    tl, tr, x, v);
    lerpAccum(0.5 * yInv, bl, br, x, v);
    lerpAccum(0.5 * x,    tl, bl, y, v);
    lerpAccum(0.5 * xInv, tr, br, y, v);
  }

  ///<summary>Bilinear interpolation in a cross pattern.</summary>
  public static void blerpCross(Vector3 l, Vector3 r, Vector3 t, Vector3 b,
                                double x, double y, Vector3 v) {
    v.zero();
    lerpAccum(0.5, l, r, x, v);
    lerpAccum(0.5, t, b, y, v);
  }
}

